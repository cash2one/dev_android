OkHttp Apache HttpClient Implementation
=======================================

This module is an implementation of the Apache `HttpClient` interface that is backed by OkHttp.

**Warning**: Many core features of Apache HTTP client are not implemented by this API. This includes
the keep-alive strategy, cookie store, credentials provider, route planner and others.
