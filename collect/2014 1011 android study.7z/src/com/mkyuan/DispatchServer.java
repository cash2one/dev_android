package com.mkyuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;

public class DispatchServer {

    public String javaHttpRequestDispatchInfo(){
	   // ˢ�� dispatch server ��Ϣ
    	// ��׼ java ����
    	// http://dispatch.mknote.org/disp
    	String result = "";
    	HttpURLConnection connection = null;
        InputStreamReader in = null;
        try {
        	// android.permission.INTERNET
        	URL url = new URL("http://dispatch.mknote.org/disp/");
        	connection = (HttpURLConnection) url.openConnection();
            int nRC = connection.getResponseCode();
            if (nRC == HttpURLConnection.HTTP_OK) {
                in = new InputStreamReader(connection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(in);
                StringBuffer strBuffer = new StringBuffer();
                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    strBuffer.append(line);
                }
                result = strBuffer.toString();
            } else {
            }            	
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    	return result;
    }
    
   public String parseReturnInfo(String retData){
	   String result = "";
       try {  
		   JSONTokener jsonParser = new JSONTokener(retData);  
		   JSONObject jobj = (JSONObject) jsonParser.nextValue();  
		   // �������ľ���JSON����Ĳ�����  
		   result =  jobj.getString("serverTime");
		   JSONObject jconfig = jobj.getJSONObject("config");
		   JSONObject jpassport = jconfig.getJSONObject("Passport");
		   result =  result + "\n" + jpassport.getString("Address");
		} catch (JSONException ex) {  
		    // �쳣��������  
		}  
	  return result; 
   }   
   
   public void Refresh(){
   	  Thread thread = new Thread( new Runnable() {
   			@Override
   			public void run() {
   			// TODO Auto-generated method stub
   				String retValue = javaHttpRequestDispatchInfo();
   				if (retValue == ""){
   				} else {
   				}    					
   			}
 		  });
   	  thread.start();
   }  

}
