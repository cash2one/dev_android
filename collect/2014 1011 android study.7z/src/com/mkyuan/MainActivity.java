package com.mkyuan;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.base.HD_RomMobile.sys_device;

import android.support.v7.app.ActionBarActivity;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

	Context mcontext;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mcontext = this;
		initEvent1();
		//buttonClickEvent2(mcontext);
	}

	public void initEvent1(){
		Button btn1 = (Button) findViewById(R.id.button1);
		btn1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				buttonClickEvent2(mcontext);
			}
		});
	}

	public void buttonClickEvent2(Context context){
		/*//
		new Thread() {   
          @Override   
          public void run() {  
      		DispatchServer dispsrv = new DispatchServer();
    		String txtValue = "";
    		TextView txtview = (TextView) findViewById(R.id.textView1);
    		txtview.setText(txtValue);
        	}
        }.start();  
        //*/
		//dispsrv.Refresh(context);
		//txtValue = dispsrv.javaHttpRequestDispatchInfo();
		new refreshDispatchServerInfoTask().execute();   
	}
	class refreshDispatchServerInfoTask extends AsyncTask<String, Integer, String> {   
	       @Override   
	       protected String doInBackground(String... params) {   
	      		DispatchServer dispsrv = new DispatchServer();	  
	           return dispsrv.parseReturnInfo(dispsrv.javaHttpRequestDispatchInfo());   
	       }   
	  
	       protected void onPostExecute(String result) {   
	           //��doInBackground�����Ľ�� ��������Ϣ��ʾ��title��
	    		TextView txtview = (TextView) findViewById(R.id.textView1);
	    		txtview.setText(result);
	       }   
	    }
	
	public void buttonClickEvent3(Context context){
		DispatchServer dispsrv = new DispatchServer();
		TextView txtview = (TextView) findViewById(R.id.textView1);
		String txtValue = "";
		//dispsrv.Refresh(context);
		//txtValue = dispsrv.javaHttpRequestDispatchInfo();
		txtview.setText(txtValue);
	}
	
	public void buttonClickEvent1(Context context){
		TextView txtview = (TextView) findViewById(R.id.textView1);
		txtview.setSingleLine(false);
		sys_device dev = new sys_device();
		String txtValue = "id:"+ dev.getAndroid_id(context);
		txtValue = txtValue + "\n";		
		txtValue = txtValue + "imei:"+ dev.getIMEI(context);
		txtValue = txtValue + "\n";		
		txtValue = txtValue + "phone:"+ dev.getPhoneNo(context);		
		txtValue = txtValue + "\n";		
		txtValue = txtValue + "info:"+ dev.getDeviceInfo(context);		
		txtview.setText(txtValue);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
