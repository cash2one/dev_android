package com.mknote.libs;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import com.mknote.dragonvein.AppDragon;

import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;

public class DeviceInfo {

	 //ANDROID_ID是设备第一次启动时产生和存储的64bit的一个数，
	 //缺点：当设备被wipe后该数改变, 不适用
	public static String getAndroid_id(){
	      return  Secure.getString(AppDragon.mApp.getContentResolver(), Secure.ANDROID_ID);
	}

	   //获取智能设备唯一编号
    public static String getIMEI(){
		  TelephonyManager tm = (TelephonyManager) AppDragon.mApp.getSystemService(AppDragon.mApp.TELEPHONY_SERVICE);
		  if (tm != null) {
			   return tm.getDeviceId();
		  } else {
			   return "";
		  }
	}
	   //获取手机SIM卡的序列号
    public static String getSimSerialNumber(){
		  TelephonyManager tm = (TelephonyManager) AppDragon.mApp.getSystemService(AppDragon.mApp.TELEPHONY_SERVICE);
		  if (tm != null) {
			   return tm.getSimSerialNumber();
		  } else {
			   return "";
		  }
	}

    // 得到用户Id
    public static String getIMSI(){
	      TelephonyManager tm = (TelephonyManager) AppDragon.mApp.getSystemService(AppDragon.mApp.TELEPHONY_SERVICE);
	      if (tm != null) {
		       return tm.getSubscriberId();
	      } else {
		       return "";
	      }
    }

    // 得到 Wifi 的 mac 地址 需要权限 android.permission.ACCESS_WIFI_STATE
    public static String getWifiMacAddress(){
		   //String result = "";
		   //Enumeration<NetworkInterface> intfs = NetworkInterface.getNetworkInterfaces();
		   //<uses-permission android:name="android.permission.ACCESS_WIFI_STATE"></uses-permission>
		   WifiManager wifi = (WifiManager) AppDragon.mApp.getSystemService(AppDragon.mApp.WIFI_SERVICE);
		   WifiInfo info = wifi.getConnectionInfo();
		   return info.getMacAddress();
	}
	
   // 手机型号
    public static String getDeviceTypeInfo(){
	     return "model:" + Build.MODEL + ";" + // MT15i
	    		      "manufacture:" + Build.MANUFACTURER; // Sony Ericsson HUAWEI
    }  
    
    /*//
    public static DataInputStream Terminal(String command) throws Exception  
    {  
        Process process = Runtime.getRuntime().exec("su");  
        //执行到这，Superuser会跳出来，选择是否允许获取最高权限
        // 如果 已经 root 的手机 会跳出对话框 没有 root 的手机 没有任何反应
        OutputStream outstream = process.getOutputStream();  
        DataOutputStream DOPS = new DataOutputStream(outstream);  
        InputStream instream = process.getInputStream();  
        DataInputStream DIPS = new DataInputStream(instream);  
        String temp = command + "\n";  
        //加回车  
        DOPS.writeBytes(temp);  
        //执行  
        DOPS.flush();  
        //刷新，确保都发送到outputstream  
        DOPS.writeBytes("exit\n");  
        //退出  
        DOPS.flush();  
        process.waitFor();  
        return DIPS;  
    }  
    
    public static boolean isRooted() {  
        //检测是否ROOT过  
        DataInputStream stream;  
        boolean flag=false;  
        try {  
            stream = Terminal("ls /data/");  
            //目录哪都行，不一定要需要ROOT权限的  
            if(stream.readLine()!=null)
            	flag=true;  
            //根据是否有返回来判断是否有root权限  
        } catch (Exception e1) {  
            // TODO Auto-generated catch block  
            e1.printStackTrace();  
        }  
        return flag;  
    }  
   //*/
}
