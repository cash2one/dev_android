package com.mknote.libs;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mknote.dragonvein.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.FontMetrics;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.TextView;

public class ChaoticUtil {

	public static String time2PastNow(long time) {
		if (time < 60) {
			return time+"秒前";
		} else if (time < 1*60*60){
			return time/60 + "分钟前";
		} else if (time < 1*24*60*60) {
			return time/(1*60*60)+"小时前"; 
		} else if (time < 7*24*60*60){
			return time/(24*60*60)+"天前";
		} else if (time < 30*24*60*60) {
			return time/(7*24*60*60)+"周前";
		} else if (time < 365*24*60*60) {
			return time/(30*24*60*60)+"月前";
		} else if (time > 365*24*60*60) {
			return time/(365*24*60*60)+"年前";
		}
		return "-- --";
	}
	
	public static TextView getIconTextView(String name, Context context) {
		String name1 = "";
		String name2 = "";
		String nameShow = "无";
		if (!TextUtils.isEmpty(name)) {
			if (name.length()>0) {
				name1 = name.substring((name.length()-1));
			}
		   if (name.length()>1) {
			   name2 = name.substring((name.length()-2),(name.length()-1));
		   }
			if (isChineseChar(name1) ) {
				nameShow = name1;
			} else if (isChineseChar(name2)) {
				nameShow = name2;
			} else {
				nameShow = name2+name1;
			}
		}
		
		TextView textView = new TextView(context);
		textView.setTextSize((float) 46.0);
		textView.setText(nameShow);
		textView.setTextColor(Color.WHITE);
		textView.setSingleLine();
		//textView.setAlpha((float) 0.4);
		textView.setGravity(Gravity.CENTER);
		return textView;
	}
	
	public static void setTextAvatar(ImageView avatarView, String name) {
		String name1 = "";
		String name2 = "";
		String nameShow = "无";
		if (!TextUtils.isEmpty(name)) {
			if (name.length()>0) {
				name1 = name.substring((name.length()-1));
			}
		   if (name.length()>1) {
			   name2 = name.substring((name.length()-2),(name.length()-1));
		   }
			if (isChineseChar(name1) ) {
				nameShow = name1;
			} else if (isChineseChar(name2)) {
				nameShow = name2;
			} else {
				nameShow = name2+name1;
			}
		}
//		int viewWidth = avatarView.getMeasuredWidth();
//		int viewHeight = avatarView.getMeasuredHeight();
		int viewWidth = 120;
		int viewHeight = 120;
		Bitmap bitmap = Bitmap.createBitmap(viewWidth,viewHeight, Config.ARGB_8888);//创建一个宽度和高度都是400、32位ARGB图
		Canvas canvas =new Canvas(bitmap);//初始化画布绘制的图像到icon上
		canvas.drawColor(avatarView.getContext().getResources().getColor(R.color.bg_light_gray));//图层的背景色
		Paint paint =new Paint(Paint.ANTI_ALIAS_FLAG|Paint.DEV_KERN_TEXT_FLAG);//创建画笔
		final float threshold = 0.5f;
		float preferredTextSize = 100.0f;
		float minTextSize = 20.0f;
		int targetWidth = viewWidth - 10;
		while ((preferredTextSize - minTextSize) > threshold)
		{
			float size = (preferredTextSize + minTextSize) / 2;
			paint.setTextSize(size);
			if (paint.measureText(nameShow) >= targetWidth)
				preferredTextSize = size; // too big
			else
				minTextSize = size; // too small
		}
		paint.setTextSize(minTextSize);//设置文字的大小
		paint.setColor(avatarView.getContext().getResources().getColor(R.color.font_gray));//文字的颜色
		float tX = (viewWidth - getFontlength(paint, nameShow))/2;  
        float tY = (viewHeight - getFontHeight(paint))/2+getFontLeading(paint); 
		canvas.drawText(nameShow,tX, tY, paint);//将文字写入。这里面的（120，130）代表着文字在图层上的初始位置
		canvas.save(canvas.ALL_SAVE_FLAG);//保存所有图层
		canvas.restore();
		avatarView.setImageBitmap(bitmap);
	}
	public static boolean isChineseChar(String str) {
        boolean temp = false;
        Pattern p=Pattern.compile("[\u4e00-\u9fa5]"); 
        Matcher m=p.matcher(str); 
        if(m.find()){ 
            temp =  true;
        }
        return temp;
    }
	
	/**  
     * @return 返回指定笔和指定字符串的长度  
     */  
    public static float getFontlength(Paint paint, String str) {  
        return paint.measureText(str);  
    }  
    /**  
     * @return 返回指定笔的文字高度  
     */  
    public static float getFontHeight(Paint paint)  {    
        FontMetrics fm = paint.getFontMetrics();   
        return fm.descent - fm.ascent;    
    }   
    /**  
     * @return 返回指定笔离文字顶部的基准距离  
     */  
    public static float getFontLeading(Paint paint)  {    
        FontMetrics fm = paint.getFontMetrics();   
        return fm.leading- fm.ascent;    
    }   
}
