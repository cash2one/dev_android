package com.mknote.libs;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;



public class UnicodePingyin {
	
	private final static String pingyinResName = "/assets/pinyin/unicode2pinyin.txt";
	private static String [] mPingyinTable;
	
	private static UnicodePingyin mInstance;

    public static UnicodePingyin getInstance(){
    	if (mInstance == null)
    		mInstance = new UnicodePingyin();
     	return mInstance;
    }
    
    public String pingyin(char c){
    	if(c>=0x4E00 && c<=0x9FA5){
    		return mPingyinTable[c-0x4E00];
    	}
    	else
    		return null;
    }
    

    private	UnicodePingyin(){ 	
    	initialize();
    	
	}

	private static void initialize() {
		// Log.logLevel = Log.INFO;
		Log.i("pingyinTable", "pingyinTable load start ");
		try {
			InputStream in = UnicodePingyin.class.getResourceAsStream(pingyinResName);
			try {
				// BufferedInputStream in = new
				// BufferedInputStream(ContactUtils.class.getResourceAsStream(pingyinResName));
				byte[] list = new byte[in.available()];
				in.read(list);
				Log.i("pingyinTable", "pingyinTable String Load " + in.available());
				mPingyinTable = (new String(list, "US-ASCII")).split("\n");
				Log.i("pingyinTable", "pingyinTable count " + mPingyinTable.length);

				Log.i("pingyinTable", "pingyinTable load end ");

				// OutputStream out = new FileOutputStream(Environment.getExternalStorageDirectory().getPath()
				// + "/.renmai/pinyin.txt");
				// BufferedOutputStream out = new BufferedOutputStream()
				// pingyinTable.save(out,"pingyin");
				// mPingyinTable.load(in);
			} finally {
				in.close();
			}
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
