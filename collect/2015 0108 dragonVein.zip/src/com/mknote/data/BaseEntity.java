package com.mknote.data;

import android.content.ContentValues;
import android.database.Cursor;

public class BaseEntity {

	public ContentValues toContentValues(){
		return null;
	}
	
	public void putContentValues(ContentValues values){
	}
	
	public boolean loadFromCursor(Cursor cs) {
		return false;
	}
	
	public boolean reloadFromDb() {
		return false;
	}

    public BaseEntity clone() {
    	return null;
    }
    
    public void clear(){    	
    }
}
