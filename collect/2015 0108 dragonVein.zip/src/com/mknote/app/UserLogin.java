package com.mknote.app;

import org.apache.thrift.TException;

import android.text.TextUtils;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.core.NetManager;
import com.mknote.net.RenmaiClient;
import com.mknote.net.thrift.MKConstants;
import com.mknote.net.thrift.MobileLoginResp;
import com.mknote.net.thrift.ServerError;

public class UserLogin {
	
	public class LoginResult {
		public boolean isSuccess = false;
		public String errorMsg = null;
		public int errorCode = 0;
		public UserAccount account = null;
		
		public void clear() {
	    	isSuccess = false;
	    	errorCode = 0;
	    	errorMsg = null;
			account = null;
		}
	}
	
    public LoginResult doLogin(String phonenum, String password, UserAccount account) {
    	LoginResult result = new LoginResult();
    	result.clear();
 		RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient(true);
 		try {
 			MobileLoginResp loginret = client.Login(phonenum, password);
 			if (!TextUtils.isEmpty(loginret.Token)) {
 				result.isSuccess = true;
 				result.account = account;
 				if (null == result.account) {
 					result.account = AppDragon.core.getUserManager().newAccount(); 
 					account = result.account;
 				};
 				result.account.setLoginAccount(phonenum);
 				result.account.setToken(loginret.getToken());
 				result.account.setChatPasswd(loginret.getUserInfo().getChatPasswd());
 				result.account.setUserId(loginret.UserInfo.getUserID());
 				result.account.setAvatarId(loginret.UserInfo.getAvatarID());
 				result.account.setDisplayName(loginret.UserInfo.getUserName());
 				result.account.setGender(loginret.UserInfo.getGender());
 			}
		} catch (ServerError e) {
			//Log.d(TAG + " login srverr:" +e.toString());
			result.errorMsg = e.Msg;
			result.errorCode = e.Code;
			if (e.Code >= MKConstants.CODE_40000_BAD_REQUEST){
				// 400 密码错误 等等
				if (MKConstants.CODE_40003_LOGIN_ERROR == e.Code) {
					//return BaseApp.mInstance.getResources().getString(R.string.err_warning_loginfail_password);
				}
				if (MKConstants.CODE_40005_VERIFYCODE == e.Code) {
					//return BaseApp.mInstance.getResources().getString(R.string.err_warning_error_smscode);					
				}
			}
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		}
 		return result;
    }
}
