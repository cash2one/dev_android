package com.mknote.app;

import org.apache.thrift.TException;

import android.text.TextUtils;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.core.NetManager;
import com.mknote.net.RenmaiClient;
import com.mknote.net.thrift.ServerError;

public class UserPwdReset {

	private static String LOGTAG = UserPwdReset.class.getSimpleName();
	
    public void doRequestSmsCode(String mobilenum){
    	try {
        	RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient();
    		client.SendForgetCode(mobilenum);
		} catch (ServerError e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		}
    }    

    public String doResetPwd(String mobilenum, String password, String smsCode)
    {
	    String errmsg = null;
	    RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient(true);
	    try {
		    client.ResetPassword(
				mobilenum, // MobileNumber 姓名,长度45个字节,汉字算3个字节,不能包含空格
				password, 
				smsCode
				);
		    // recall login immediately after reset password  
		    UserAccount account = AppDragon.core.getUserManager().newAccount();
		    UserLogin login = new UserLogin();
		    UserLogin.LoginResult loginret = login.doLogin(mobilenum, password, account);
		    if (null != loginret) {
		    	if (loginret.isSuccess) {
		    		
		    	} else {
		    		
		    	}
		    }
	    } catch (ServerError e) {
		    errmsg = e.Msg;
		    e.printStackTrace();
	    } catch (TException e) {
		    e.printStackTrace();
	    }
		if (!TextUtils.isEmpty(errmsg)) {
			return errmsg;
		}
	    return null;
    }    	
}
