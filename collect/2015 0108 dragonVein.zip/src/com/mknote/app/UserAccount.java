package com.mknote.app;

import com.mknote.dragonvein.core.AppUserManager;

public class UserAccount {
	
    private String mSource = null;
    private String mToken = null;
    private long mUserId = 0;
    private String mUserId2 = null;
    private String mName = null;
    private String mDisplayName = null;
    private String mLoginAccount = null;
    private short mGender = AppUserManager.USER_GENDER_UNKNOWN;
    private short mAge = 0;
    private String mChatPasswd = null;
    
    public String getChatPasswd() {
		return mChatPasswd;
	}

	public void setChatPasswd(String mChatPasswd) {
		this.mChatPasswd = mChatPasswd;
	}

	private String mAvatarId = null;
    
    public void clear() {
        mSource = null;
        mToken = null;
        mUserId = 0;
        mUserId2 = null;
        mName = null;
        mDisplayName = null;
        mLoginAccount = null;
        mGender = AppUserManager.USER_GENDER_UNKNOWN;
        mAge = 0;
    }
    
    public void setSource(String source) {    	
    	mSource = source;
    }
    
    public String getSource() {
    	return mSource;
    }
    
    public void setToken(String token) {    	
    	mToken = token;
    }
    
    public String getToken() {
    	return mToken;
    }
    
    public void setUserId(long userid) {    	
    	mUserId = userid;
    }
    
    public long getUserId() {
    	return mUserId;
    }
    
    public void setUserId2(String userid) {    	
    	mUserId2 = userid;
    }
    
    public String getUserId2() {
    	return mUserId2;
    }

    public void setName(String name) {    	
    	mName = name;
    }
    
    public String getName() {
    	return mName;
    }

    public void setDisplayName(String displayname) {    	
    	mDisplayName = displayname;
    }
    
    public String getDisplayName() {
    	return mDisplayName;
    }

    public void setLoginAccount(String account) {    	
    	mLoginAccount = account;
    }
    
    public String getLoginAccount() {
    	return mLoginAccount;
    }

    public void setGender(short gender) {
    	mGender = gender;
    }
    
    public short getGender() {
    	return mGender;
    }

    public void setAvatarId(String AvatarId) {
    	mAvatarId = AvatarId;
    }
    
    public String getAvatarId() {
    	return mAvatarId;
    }
    
    
}
