package com.mknote.app;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;

import com.mknote.dragonvein.AppDragon;
import com.mknote.libs.Log;

public class AppVersion {

	// [主版本号] + [.] +[子版本号] + [.] + [指令版本号] + [.] + [渠道版本号] + [_] + [开发发布标示]+ [svn开发版本号]
	private String mMainVersion = null;
	private String mMinorVersion = null;
	private String mCommand = null;
	private String mChannel = null;
	private String mVersionName = null;
	private int mVersionCode = 0;

    //r 标示 Release 发布的版本号
	//d 标示 Debug 发给用户的调试版本号
	//t 标示 Test 平时内部测试的版本号
	private String mReleaseFlag = null;	
	private String mSvnVersion = null;
	
	public boolean isDebugVersion () {
		if (!TextUtils.isEmpty(mVersionName)) {
			if (mVersionName.indexOf("d") > 0)
				return true;
		} 
		if (!TextUtils.isEmpty(mReleaseFlag)) {
			if (mReleaseFlag.indexOf("d") > 0)
				return true;
		}
		return false;
	}
	
	public String getVersionName (){
		return mVersionName;
	}

	public void setVersionName(String versionName) {
		mVersionName = versionName;
	}
	
	public int getVersionCode() {
		return mVersionCode;
	}
	
	public void setVersionCode(int versionCode) {
		mVersionCode = versionCode;
	}
	
	public AppVersion() {
		PackageManager packageMgr =AppDragon.mApp.getPackageManager();
		String packageName = AppDragon.mApp.getPackageName();			
		PackageInfo pkgInfo = null;
		try {
			pkgInfo = packageMgr.getPackageInfo(packageName, PackageManager.GET_CONFIGURATIONS);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		mVersionName = pkgInfo.versionName;
		mVersionCode = pkgInfo.versionCode;
		packageName = null;
		//ApplicationInfo appInfo = packageMgr.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
		pkgInfo = null;
		//appInfo = null;
		packageMgr = null;
	}

	public AppVersion(String version) {
		ApplyVersion(version);
	}
	
	public void ApplyVersion(String version) {
		StringBuilder string = new StringBuilder(version);
		Log.d(version);
		String[] sArray1 = version.split("\\.");
		if (sArray1.length >=1)
			mMainVersion = sArray1[0];
		if (sArray1.length >=2)
			mMinorVersion = sArray1[1];
		if (sArray1.length >=3)
			mCommand = sArray1[2];
		if (sArray1.length >=4) {
			String[] sArray2 = sArray1[3].split("_");
			if (sArray2.length == 2) {
				mChannel = sArray2[0];
				mReleaseFlag = sArray2[1].substring(0, 1);
				mSvnVersion = sArray2[1].substring(1);
			} else if (sArray1.length == 0) {
				mChannel = sArray1[3];
			}
		}
	}

	public String getMainVersion() {
		return mMainVersion;
	};
	public String getMinorVersion(){
		return mMinorVersion;
	};
	public String getCommand() {
		return mCommand;
	};
	public String getChannel(){
		return mChannel;
	};
	public String getReleaseFlag() {
		return mReleaseFlag;
	};
	public String getSvnVersion(){
		return mSvnVersion;
	};
}
