package com.mknote.app;

import org.apache.thrift.TException;

import android.text.TextUtils;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.core.NetManager;
import com.mknote.libs.Log;
import com.mknote.net.RenmaiClient;
import com.mknote.net.thrift.MobileRegResp;
import com.mknote.net.thrift.SendRegCodeResp;
import com.mknote.net.thrift.ServerError;

public class UserRegister {

	private static String LOGTAG = UserRegister.class.getSimpleName();
	
	public static final short REGISTER_RESULT_SUCCESS = 0;
	public static final short REGISTER_RESULT_FAIL_UNKNOWN = 1;
	public static final short REGISTER_RESULT_FAIL_DUPLICATE = 3;
	public static final short REGISTER_RESULT_FAIL_SERVERBASE = 100;

	public class RegisterResult {
		public boolean isSuccess = false;
		public String errorMsg = null;
		public int errorCode = 0;
		public UserAccount account = null;
	}
	
    public RegisterResult doRequestSmsCode(String mobilenum){
    	RegisterResult result = new RegisterResult();
    	result.isSuccess = false;
    	try {
        	RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient();
        	Log.d(LOGTAG + " " + "doRequestSmsCode");
    		SendRegCodeResp smsret = client.SendRegCode(mobilenum);
    		if (null != smsret) {
        		if (smsret.IsExisted) {
        			// 该账号已经注册过了
        			Log.d(LOGTAG + " " + "doRequestSmsCode existed ");
        			result.errorCode = REGISTER_RESULT_FAIL_DUPLICATE;
        		} else {
        			Log.d(LOGTAG + " " + "doRequestSmsCode success ");
        			result.errorCode = REGISTER_RESULT_SUCCESS;
        		}
    		}
		} catch (ServerError e) {
			e.printStackTrace();
			result.errorCode = REGISTER_RESULT_FAIL_SERVERBASE + e.Code;
			result.errorMsg = e.Msg;
		} catch (TException e) {
			e.printStackTrace();
			result.errorCode = REGISTER_RESULT_FAIL_UNKNOWN;
			result.errorMsg = e.getMessage();
		}
    	return result;
    }    

    public RegisterResult doRegister(String phonenum, String password, String smsCode, String nickName, UserAccount account)
    {
    	RegisterResult result = new RegisterResult();
    	result.isSuccess = false;
    	
    	RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient(true);
    	try {
    		String regNickName = nickName;
    		if (TextUtils.isEmpty(regNickName)) {
    			regNickName = "";
    		} 
    		MobileRegResp regret = client.Reg(
    				phonenum, // UserName 姓名,长度45个字节,汉字算3个字节,不能包含空格
    				password, 
    				smsCode,  // SmsCode 注册验证码,6位数字字符串
    				// this value can not be null
    				regNickName, // UserName 姓名,长度45个字节,汉字算3个字节,不能包含空格
    				"",  // AnonymousName 匿名昵称, 如果没有上传， 会自动产生一个
    				"0", // AvatarId 头像编号,http://{ImageServer}/avatar/{AvatarID},格式.jpg
    				(short)1 // Gender 性别,1-男 2-女
    				);
    		
    		if (!TextUtils.isEmpty(regret.Token)) {
    			result.isSuccess = true;
 				result.account = account;
 				if (null == result.account) {
 					result.account = AppDragon.core.getUserManager().newAccount(); 
 					account = result.account;
 				};
 				result.account.setLoginAccount(phonenum);
 				result.account.setChatPasswd(regret.getUserInfo().getChatPasswd());
 				result.account.setToken(regret.getToken());
 				result.account.setUserId(regret.UserInfo.getUserID());
 				result.account.setAvatarId(regret.UserInfo.getAvatarID());
 				result.account.setDisplayName(regret.UserInfo.getUserName());
 				result.account.setGender(regret.UserInfo.getGender()); 				
    		}
		} catch (ServerError e) {
			e.printStackTrace();
			result.errorCode = REGISTER_RESULT_FAIL_SERVERBASE + e.Code;
			result.errorMsg = e.Msg;
		} catch (TException e) {
			e.printStackTrace();
			result.errorCode = REGISTER_RESULT_FAIL_UNKNOWN;
			result.errorMsg = e.getMessage();
		}
 		return result;
    }

}
