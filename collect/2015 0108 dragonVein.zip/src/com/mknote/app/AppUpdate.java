package com.mknote.app;

import java.io.File;

import org.apache.thrift.TException;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.core.AppConfigManager;
import com.mknote.dragonvein.core.NetManager;
import com.mknote.libs.Log;
import com.mknote.net.RenmaiClient;
import com.mknote.net.thrift.KeyResp;
import com.mknote.net.thrift.ServerError;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;

public class AppUpdate {

	private static final String LOGTAG = AppUpdate.class.getSimpleName();
	public static final int FLAG_UPDATE_NORMAL = 1;
	public static final int FLAG_UPDATE_FORCEUPDATE = 2;
	public static final int FLAG_UPDATE_NOUPDATE_OLD = 3;
	public static final int FLAG_UPDATE_NOUPDATE = 4;
	
	//public static final int STEP_UPDATE_CHECKING = 1;
	//public static final int STEP_UPDATE_DOWNLOAD = 2;
	//public static final int STEP_UPDATE_WAITINSTALL = 3;
	//public static final int STEP_UPDATE_FINISH = 4;
	
	public class UpdateSession {
		public String lastestDownloadUrl = null;
		public String lastestVersionName = null;
		public long lastestVersionCode = 0;	
		public String lastestVersionBrief = null;
		public long sessionStartTime = 0;
		public int updateStep = 0;
		
		private UpdateSession() {
			sessionStartTime = System.currentTimeMillis();
			//sessionStartTime = android.os.SystemClock.uptimeMillis();
		}
		
		public void clear() {
			lastestDownloadUrl = null;
			lastestVersionName = null;
			lastestVersionCode = 0;	
			lastestVersionBrief = null;
			sessionStartTime = 0;			
		}
	}

	private static UpdateSession mUpdateSession = null;
	public UpdateSession getCurrentUpdateSession () {
		return mUpdateSession;
	}
	
	public void setCurrentUpdateSession (UpdateSession updatesession) {
		mUpdateSession = updatesession;
	}
	
	public void checkUpdate() {
		if (null !=mUpdateSession)
			return;
		mUpdateSession = new UpdateSession();
		(new Thread() {
			@Override
			public void run() {
				internalUpdate(mUpdateSession);
			}
		}).start();
	}
	
	private void internalUpdate(UpdateSession updatesession) {
		AppVersion selfversion = new AppVersion();
		Log.d("AppUpdate self version:" + selfversion.getVersionName());
		getLastestVersionInfoFromServer(updatesession);

		if (TextUtils.isEmpty(updatesession.lastestVersionName)) {
			updatesession.lastestVersionName = selfversion.getVersionName();
		}
		int versionCompare = compareVersion(selfversion.getVersionName(), updatesession.lastestVersionName);
		Log.d("AppUpdate update version:" + updatesession.lastestVersionName);
		Log.d("AppUpdate update version:" + updatesession.lastestDownloadUrl);
		// 这里检查 是否是忽略的 更新的版本 强制更新版本 不应保存忽略信息
		String ignoreVersion = null;
		AppConfigManager.AppConfig config = AppDragon.mApp.getConfig();
		if (null != config) {
			ignoreVersion = config.appUpdateIgnore;
		}		
		if (!TextUtils.isEmpty(updatesession.lastestDownloadUrl))
		{
 		    if ((FLAG_UPDATE_NORMAL == versionCompare) ||  (FLAG_UPDATE_FORCEUPDATE == versionCompare)) {
	     		// 1 有新版 需要更新但是非强制 先下载完成以后 再提示有更新
 		        // 2 有新版 强制更新	先下载完成以后 再提示有更新
     		    String localfileurl = getUpdateLocalSaveFileUrl(updatesession);
     		    if (TextUtils.isEmpty(localfileurl))
     		    	return;
          		File file=new File(localfileurl);
     				// 下载更新文件
     				// 1. 从尽量从各电子市场升级
     				// 2. 当无法从电子市场下载 则从麦库默认服务器下载
     				// 3. 下载地址 由 dispatch server 发布
     				// http://download.note.sdo.com/res/4ccd17f8-5bbc-496c-97cc-bdfb82790756
                if (!file.exists()){
                	Log.d("AppUpdate download update file:" + updatesession.lastestDownloadUrl);
                	File destDir = new File(getUpdateLocalSavePath(updatesession));
                	if (!destDir.exists()) {
                	     destDir.mkdirs();
                	}         
                	AppDragon.core.getNet().downloadFile(updatesession.lastestDownloadUrl, localfileurl, true);
                }
                if(file.exists()){
                	Log.d("AppUpdate check local update file:" + localfileurl);
             		if (!TextUtils.isEmpty(ignoreVersion)) {
        			    if (ignoreVersion.equals(updatesession.lastestVersionName)) {
        			    	return;
        			    }                 			
             		}
             		notifyUpdateInstallFilePrepared(updatesession);
                }
 		    }
		}		
	}
	
	private void notifyUpdateInstallFilePrepared(UpdateSession updatesession) {
		AppDragon.mApp.sendBroadcast(GlobleConsts.BROADCAST_APP_UPDATE_PREPARED, null);
	}
	
	private String getUpdateLocalSaveFileName(UpdateSession updatesession){
		if (TextUtils.isEmpty(updatesession.lastestVersionName)) { 
			return null;
		}  else {
			return "renmai" + AppDragon.getProductID() + "_" + updatesession.lastestVersionName + ".apk";
		}
	}
	
	private String getUpdateLocalSavePath(UpdateSession updatesession){
		String status = Environment.getExternalStorageState();
	    if (status.equals(Environment.MEDIA_MOUNTED)) {
	    	// 如果 SD 卡存在
			return Environment.getExternalStorageDirectory() +"/" +".renmai" +"/";
	    } else {
			return Environment.getExternalStorageDirectory() +"/" +".renmai" +"/";
	    }
	}
	
	public String getUpdateLocalSaveFileUrl(UpdateSession updatesession){
		if (TextUtils.isEmpty(updatesession.lastestVersionName)) { 
			return null;
		}  else {
			String path = getUpdateLocalSavePath(updatesession);
			if (TextUtils.isEmpty(path))
				return null;
			String filename = getUpdateLocalSaveFileName(updatesession);
			if (TextUtils.isEmpty(filename))
				return null;
        	return path + filename;//文件存储路径
		}
	}

	public void runUpdateIntallPackage(Context context, String fileurl){
		File file=new File(fileurl);
		if (!file.exists())
			return;
	    Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  
		intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
		context.startActivity(intent); 
	}
	
	//  检查 最新版本
    //  获取 最新版本
	private void getLastestVersionInfoFromServer(RenmaiClient client, UpdateSession updatesession){
		if (client == null) 
			return;
		String productid = AppDragon.getProductID();
		try {
			// 版本 key
			KeyResp keyversion = null;
			boolean isdebug = true;
			//isDebugVersion();
			if (isdebug) {
	        	keyversion = client.GetKey(
	        			productid, //String ProductID,
	        			 "/application/version", //String PathName,
	        			 "debug" // String KeyName
	        			 );
			} else {
	        	keyversion = client.GetKey(
	        			productid, //String ProductID,
	        			 "/application/version", //String PathName,
	        			 "release" // String KeyName
	        			 );
		    }
		    if ((keyversion != null) && (keyversion.IsExisted)) {
				 // 下载地址的 key
	            KeyResp keydownurl = client.GetKey(
	            		productid, //String ProductID,
		        			 "/application/download", //String PathName,
		        			 keyversion.Key.Value // String KeyName
		        			 );
		        if ((keydownurl != null) && (keydownurl.IsExisted)) {
		        	updatesession.lastestDownloadUrl = keydownurl.Key.Value;
		        }
		        try{
			        KeyResp keyversionbrief = client.GetKey(
			        		productid, //String ProductID,
			        			 "/application/brief", //String PathName,
			        			 keyversion.Key.Value // String KeyName
			        			 );
			        if ((keyversionbrief != null) && (keyversionbrief.IsExisted)) {
			        	updatesession.lastestVersionBrief = keyversionbrief.Key.Value;
			        }
			    } catch (ServerError e) {
					e.printStackTrace();
				} catch (TException e){
					e.printStackTrace();
				}
		        updatesession.lastestVersionName = keyversion.Key.Value;
			 }
	    } catch (ServerError e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		}
	}
	
	private void getLastestVersionInfoFromServer(UpdateSession updatesession){
		// 从麦库 服务器 获取最新版本 ???
		// 通过 thrift 协议获取 更新版本信息
		// 从电子市场 获取版本信息 ???
		RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient();
		getLastestVersionInfoFromServer(client, updatesession);	
	}

	// 主版本号 + 子版本号 + 指令版本号 + 渠道号 + 发布开发标示 + svn版本号
	// -1 版本数据错误
	// 0 版本相同 不需要更新 
	// 1 有新版 需要更新但是非强制 
	// 2 有新版 强制更新
	// 3 没有新版本 切替换 主版本比当前版本更旧
	// 4 没有新版本 切替换 子版本比当前版本更旧
	public int compareVersion(String oldVersion, String newVersion){
		Log.d(LOGTAG +" compareVersion:[" + oldVersion + " vs " + newVersion + "]");
		if (TextUtils.isEmpty(oldVersion)) {
			return -1;
		}
		if (TextUtils.isEmpty(newVersion)) {
			return -1;
		}

		AppVersion versionOld = new AppVersion(oldVersion);
		if (TextUtils.isEmpty(versionOld.getMainVersion())){
			return -1;
		}
		AppVersion versionNew = new AppVersion(newVersion);
		if (TextUtils.isEmpty(versionNew.getMainVersion())){
			return -1;
		}
		int intVold = Integer.parseInt(versionOld.getMainVersion());
		int intVnew = Integer.parseInt(versionNew.getMainVersion());
		//服务器主版本小于当前版本
		if(intVnew < intVold)
			return FLAG_UPDATE_NOUPDATE_OLD;
		if(intVnew > intVold)
		{
			String cmd = versionNew.getCommand();
			String cmd1 = cmd.substring(0, 1);
			if (cmd1.equals("3")){
				//强制升级
			    return FLAG_UPDATE_FORCEUPDATE;
			}
			return FLAG_UPDATE_NORMAL;
		}		
		//主版本一样，比较子版本 
		intVold = Integer.parseInt(versionOld.getMinorVersion());
		intVnew = Integer.parseInt(versionNew.getMinorVersion());
		
		//服务器子版本 小于当前子版本 
		if(intVnew < intVold)
			return FLAG_UPDATE_NOUPDATE_OLD;
		
		if(intVnew > intVold)
		{
			String cmd = versionNew.getCommand();
			String cmd1 = cmd.substring(0, 1);
			if (cmd1.equals("2")){
				//强制升级
			    return FLAG_UPDATE_FORCEUPDATE;
			}
			return FLAG_UPDATE_NORMAL;
		}
		
		//主版本和子版本一样，比较SVN版本号 
		intVold = Integer.parseInt(versionOld.getSvnVersion());
		intVnew = Integer.parseInt(versionNew.getSvnVersion());
		//服务器SVN版本小于当前SVN版本
		if(intVnew < intVold)
			return FLAG_UPDATE_NOUPDATE_OLD;
		if(intVnew > intVold)
		{
			String cmd = versionNew.getCommand();
			String cmd1 = cmd.substring(0, 1);
			if (cmd1.equals("1")){
				//强制升级
			    return FLAG_UPDATE_FORCEUPDATE;
			}
			return FLAG_UPDATE_NORMAL;
		}		
		//SVN版本号一致， 不需要升级
		return FLAG_UPDATE_NOUPDATE;
	}
	
}
