package com.mknote.app.activity;

public class AppDialogActivity extends BaseAppActivity {

}
