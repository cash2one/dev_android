package com.mknote.app.activity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;

import com.mknote.app.UserAccount;
import com.mknote.app.UserLogin;
import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.MainActivity;
import com.mknote.dragonvein.R;
import com.mknote.dragonvein.core.AppUserManager;
import com.mknote.dragonvein.libs.TextViewUtils;
import com.mknote.libs.Log;

public class UserLoginActivity extends BaseAppActivity {

	private static String LOGTAG = UserLoginActivity.class.getSimpleName();
	private static final int MSG_SHOW_ERROR = 3001;	
	
	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_userlogin);
        createMessageLoopHandler();
        mHelper = new UserLoginActivityHelper();
        mHelper.start(this);
	}
	
	@Override
	protected void onDestroy() {
		Log.d("UserLoginActivity onDestroy begin");
		clear();
		super.onDestroy();
		System.gc();
	}

	private void clear() {
		if (null != mHelper) {
			mHelper.clear();
			mHelper = null;
		}
	}
	
	@Override
	protected boolean handleActivityMessage(Message msg){
		super.handleActivityMessage(msg);
    	switch (msg.what) {
 	        case MSG_SHOW_ERROR:
 	    	    try {
 	        	    if (null != mHelper.mProgressDialog)
 	        	    	mHelper.mProgressDialog.cancel();
 	    	    } catch (Exception e) {    		
 	    	    }
 	    	   mHelper.showError((String) msg.obj);
 		       break;    	   
    	}   
		return false;
	}
	
	private void createBroadcastReceiver(){
        //注册广播接收器
		mActivityBroadcastReceiver =new BroadcastReceiver() {
		    @Override
		  	public void onReceive(Context context, Intent intent) {
		  		if (intent.getAction().equals(GlobleConsts.BROADCAST_USER_LOGIN)) {
					android.content.Intent mainintent = new android.content.Intent(android.content.Intent.ACTION_MAIN);  
					mainintent.setClass(getApplication(), MainActivity.class);  
					mainintent.setFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);  
		            //intent.setFlags(android.content.Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
		            //intent.setFlags(android.content.Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY);
		            startActivity(mainintent);
		            AppDragon.mApp.sendBroadcast(GlobleConsts.BROADCAST_USER_ENTER, null);
		            UserLoginActivity.this.clear();
		            UserLoginActivity.this.finish();
		  		}
		  	}
		};
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(GlobleConsts.BROADCAST_USER_LOGIN);
		registerReceiver(mActivityBroadcastReceiver, intentFilter);
	}
	
	private UserLoginActivityHelper mHelper = null;
	
	private class UserLoginViewHolder {
		private EditText editAccount = null;
		private EditText editPassword = null;
		private View buttonAction = null;
		private View buttonDisplayPwd = null;
		private View buttonRegister = null;
		private View buttonForgetPwd =null;
		private View layoutError = null; 
		private TextView textError = null; 
				
		private void initView() {
	        editAccount = (EditText) findViewById(R.id.edUserAccount);
	        editPassword = (EditText) findViewById(R.id.edPassword);
	        buttonAction = (View) findViewById(R.id.btnAction);			
	        buttonDisplayPwd = (View) findViewById(R.id.btnDisplayPwd);
	        buttonRegister = (View) findViewById(R.id.btnCallFunction1);
	        buttonForgetPwd = (View) findViewById(R.id.btnCallFunction2);
	    	layoutError = (View) findViewById(R.id.layoutErrorHint);
			textError = (TextView) findViewById(R.id.txtError);
		}
		
		private void clear() {
			editAccount = null;
			editPassword = null;
			buttonAction = null;
			buttonDisplayPwd = null;
			buttonRegister = null;
			buttonForgetPwd =null;
			layoutError = null; 
			textError = null; 			
		}
	}

	private class UserLoginActivityHelper {

		private UserLoginViewHolder mViewHolder = null;
		   // 返回出错信息 如果成功 则返回空
		private void start(BaseAppActivity loginActivity) {
			mViewHolder = new UserLoginViewHolder();
			mViewHolder.initView();	
			initView();
			createBroadcastReceiver();
		}

		private void initView() {
			if (null == mViewHolder)
				return;
			initAccountInput();
			initDisplayPwdButton();
			initPasswordInput();
			initLoginButton();
			initCallRegisterButton();
			initForgetPwdButton();
		}
		
		private void clear(){
			if (null != mViewHolder) {
				mViewHolder.clear();
				mViewHolder = null;
			}
		}
		
		private void initAccountInput() {
	        if (null == mViewHolder.editAccount) 
	        	return;
	        AppUserManager.HistoryUserAccount lastaccount = AppDragon.core.getUserManager().getLastLoginAccount();
	        if (null != lastaccount) {
		        if (!TextUtils.isEmpty(lastaccount.accountName)){
		           	mViewHolder.editAccount.setText(lastaccount.accountName);
		                // 如果有记住上一次的 登录账号 默认输入位置 设在密码输入框上
		                // 细节
		           	if (null != mViewHolder.editPassword) {
			           	mViewHolder.editPassword.requestFocus();
		           	}
		        }
	        }	        	
	        mViewHolder.editAccount.addTextChangedListener(new TextWatcher(){
	    		@Override
	    		public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
	    		@Override
	    		public void onTextChanged(CharSequence s, int start, int before, int count) {
	    			showError(null);
	    		}
	    		@Override
	    		public void afterTextChanged(Editable s) {}});
		}
		
		private void initDisplayPwdButton() {
	        if (null == mViewHolder.buttonDisplayPwd) 
	        	return;
	        mViewHolder.buttonDisplayPwd.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
			        if (null != mViewHolder.editPassword) {
				        TextViewUtils.switchPasswordShowHide(mViewHolder.editPassword, mViewHolder.buttonDisplayPwd);
			        }
			}});	        	
		}
		
		private void initPasswordInput(){
	        if (null ==mViewHolder.editPassword) 
	        	return;
	        mViewHolder.editPassword.addTextChangedListener(new TextWatcher(){
	  			  @Override
	  			  public void beforeTextChanged(CharSequence s, int start, int count, int after) {
	  			  }
	  			  @Override
	  			  public void onTextChanged(CharSequence s, int start, int before, int count) {
	  				  showError(null);
	  			  }
	  			  @Override
	  			  public void afterTextChanged(Editable s) {
	  		 }});
		}

		private void initLoginButton(){
	        if (null == mViewHolder.buttonAction) 
	        	return;
		    mViewHolder.buttonAction.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
					if (verifyLoginCondition()) 
						sendLoginRequest();
				}
		    });
		}
		
		private void initCallRegisterButton() {
			if (null == mViewHolder.buttonRegister)
				return;
			mViewHolder.buttonRegister.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
					UserLoginActivity.this.redirectToActivity(UserRegisterActivity.class);
					//callSlideRightInLeftOutAnimation();				
				}});
		}
		
		private void initForgetPwdButton() {
			if (null == mViewHolder.buttonForgetPwd)
				return;

			mViewHolder.buttonForgetPwd.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
					UserLoginActivity.this.redirectToActivity(UserPwdForgetActivity.class);					
					//callSlideRightInLeftOutAnimation();
				}});
		}

		private boolean verifyUserAccount(){
	        /*/
	        UserRegister reg = new UserRegister();
	    	if (!reg.verifyMobileNum(ednum.getText().toString())){
	    		// 手机号 错误先提示一下
	    		showError(getResources().getString(R.string.err_warning_inputvalidmobile));
	            ednum.requestFocus();
	    		return false;
	    	}
	    	//*/
	    	return true;
		}
		
		private boolean verifyPassword(){
			/*/
	        EditText edpwd = (EditText) findViewById(R.id.edLoginPassword);
	        UserRegister reg = new UserRegister();
	    	if (!reg.verifyPassword(edpwd.getText().toString())){
	    		showError(getResources().getString(R.string.err_warning_inputpassword));
	            edpwd.requestFocus();
	            return false;
	    	}
	    	//*/
	        return true;
		}

	    // 验证登录参数
	    private boolean verifyLoginCondition(){
	        // 验证手机号
	    	if (!verifyUserAccount()) 
	    		return false;
	    	if (!verifyPassword())
	    		return false;
	    	com.mknote.net.NetState state = new com.mknote.net.NetState();
			if (!state.isNetworkConnected()) {
				//AppManager.getAppManager().showNetConnectErrorToast();
				return false;
			}
	    	return true;
	    }

	    // 显示错误提示
	    private void showError(String errMessage){
	    	if (null == mViewHolder)
	    		return;
	    	if (TextUtils.isEmpty(errMessage)) {
	        	if (null != mViewHolder.layoutError)
	        		mViewHolder.layoutError.setVisibility(View.INVISIBLE);
	    	} else {
	        	if (null != mViewHolder.layoutError)
	        		mViewHolder.layoutError.setVisibility(View.VISIBLE);
	    	}
	    	if (null != mViewHolder.textError) {
		    	mViewHolder.textError.setText(errMessage);
	    	}
	    }
	    
	    private ProgressDialog mProgressDialog = null;	    
	    // 发送登录请求
	    private void sendLoginRequest(){
	    	try {
	        	if (null != mProgressDialog)
	        	    mProgressDialog.cancel();
	    	} catch (Exception e) {    		
	    	}
	    	mProgressDialog = ProgressDialog.show(UserLoginActivity.this, "", idStr(R.string.user_logining), true, false);
	    	
	        (new Thread(){
				@Override  
				public void run(){
					/*/
					try {
						//Thread.sleep(100 * 1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					//*/
					Log.d(" sendLoginRequest ");
					if (null == mViewHolder.editAccount)
						return;
					if (null == mViewHolder.editPassword)
						return;
			        UserLogin action = new UserLogin();
		    	    UserAccount account = AppDragon.core.getUserManager().newAccount();
		    	    UserLogin.LoginResult loginret = action.doLogin(
		    	    		mViewHolder.editAccount.getText().toString(), 
		    	    		mViewHolder.editPassword.getText().toString(), 
		    	    		account);
		    	    if (null != loginret) {
						if (loginret.isSuccess) {
							Log.d(" sendLoginRequest BROADCAST_USER_LOGIN ");
							//登录成功
							if (null != account) {
								AppDragon.core.getUserManager().setLoginedActiveUserAccount(account);
								AppDragon.mApp.sendBroadcast(GlobleConsts.BROADCAST_USER_LOGIN, null);
							}
						} else {
							// 显示错误信息
							if (null != mBaseMsgHandler) {
								android.os.Message msg = new android.os.Message();
								msg.what = MSG_SHOW_ERROR;
								msg.obj = loginret.errorMsg;
								mBaseMsgHandler.sendMessage(msg);
							}
						}
		    	    }
	        	}
	        }).start();    	
	    }
	}
}
