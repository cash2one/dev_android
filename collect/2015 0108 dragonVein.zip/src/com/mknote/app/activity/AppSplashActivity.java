package com.mknote.app.activity;

import android.os.Handler;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.MainActivity;
import com.mknote.dragonvein.R;
import com.mknote.dragonvein.activity.UserInfoActivity;
import com.mknote.dragonvein.core.AppUserManager;
import com.mknote.libs.Log;

public class AppSplashActivity extends BaseAppActivity {
	
	private static String LOGTAG = AppSplashActivity.class.getSimpleName();
	
	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_splash);
        mHelper = new SplashActivityHelper();
        mHelper.start(this);
	}
	
	@Override
	protected void onDestroy() {
		clear();
		super.onDestroy();
		System.gc();
	}
	 // much easier to handle key events  
    @Override  
    public void onBackPressed() {  
    }
    
    private void clear() {
    	mHelper = null;
    }
    
	private SplashActivityHelper mHelper = null;
	private class SplashActivityHelper {
		
		private android.os.Handler mActivityHandler = null;
		private BaseAppActivity mSplashActivity = null;
		
		// 要注意事件
		// 必须在显示Splash的时候禁止BACK，MENU等事件，然后再在Splash结束后把它们重新启用。
		private void start(BaseAppActivity splashActivity) {
			mSplashActivity = splashActivity;
			mActivityHandler = new Handler() { 
				@Override  
			    public void handleMessage(android.os.Message msg) {
					showNextActivity();
				}
			};
			mActivityHandler.sendEmptyMessageDelayed(0, 2000); 
			//showDefaultAnimation();
		}
		
		private void showDefaultAnimation() {			
		}
		
		private void showNextActivity() {
			if (false) {
				// 测试方便跳转页面
				showTestActivity();
				finish();
				return;
			}
			AppUserManager usermgr = AppDragon.core.getUserManager();
			if (null != usermgr) {
				usermgr.checkAutoLoginUserAccount();
				if (usermgr.isLogined()) {
					showMainActivity();
				} else {
					showUserLoginActivity();
				}       
	            mSplashActivity.finish();
	            mSplashActivity = null;
			} else {
				//showMainActivity();       
	            mSplashActivity.finish();
	            mSplashActivity = null;
			}			
		}
		
		private void showUserLoginActivity() {
			redirectToActivity(UserLoginActivity.class);
		}
		
		private void showMainActivity() {
			android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_MAIN);  
            intent.setClass(getApplication(), MainActivity.class);  
            intent.setFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);  
            //intent.setFlags(android.content.Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
            //intent.setFlags(android.content.Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY);
            startActivity(intent);  
            AppDragon.mApp.sendBroadcast(GlobleConsts.BROADCAST_USER_ENTER, null);     
            // overridePendingTransition must be called AFTER finish() or startActivity, or it won't work.  
            //overridePendingTransition(R.anim.activity_in, R.anim.splash_out);  
		}
		
		private void showTestActivity() {
			//redirectToActivity(AppAboutActivity.class);
			//redirectToActivity(UserLoginActivity.class);
			redirectToActivity(UserInfoActivity.class);
			//redirectToActivity(UserRegisterActivity.class);
			//redirectToActivity(UserPwdChangeActivity.class);
			//redirectToActivity(UserPwdForgetActivity.class);
		}
	}
}
