package com.mknote.app.activity;

import android.app.ProgressDialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;

import com.mknote.app.UserAccount;
import com.mknote.app.UserPwdReset;
import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.R;
import com.mknote.dragonvein.core.AppUserManager;
import com.mknote.dragonvein.libs.TextViewUtils;
import com.mknote.libs.Log;
import com.mknote.net.NetState;

public class UserPwdForgetActivity extends BaseAppActivity {

	private static String LOGTAG = UserPwdForgetActivity.class.getSimpleName();
	
	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_userpwd_forget);
        mHelper = new PwdForgetActivityHelper();
        mHelper.start(this);
	}
	
	@Override
	protected void onDestroy() {
		clear();
		super.onDestroy();
		System.gc();
	}

	private void clear() {
		if (null != mHelper) {
			mHelper.clear();
			mHelper = null;
		}		
	}
	
	private PwdForgetActivityHelper mHelper = null;

	private class PwdForgetViewHolder {
		private EditText editAccount = null;
		private EditText editPassword = null;
		private EditText editVerifyCode = null;
		private View buttonDisplayPwd = null;
		private View buttonAction =null;
		private View buttonGetVerifyCode = null;
		private View layoutError = null; 
		private TextView textError = null; 
				
		private void initView() {
	        editAccount = (EditText) findViewById(R.id.edUserAccount);
	        editPassword = (EditText) findViewById(R.id.edPassword);
	        buttonDisplayPwd = (View) findViewById(R.id.btnDisplayPwd);
	        editVerifyCode = (EditText) findViewById(R.id.edVerifyCode);
	        buttonGetVerifyCode =  (View) findViewById(R.id.btnGetVerifyCode);
	        buttonAction = (View) findViewById(R.id.btnAction);
	    	layoutError = (View) findViewById(R.id.layoutErrorHint);
			textError = (TextView) findViewById(R.id.txtError);
		}
		
		private void clear() {
			editAccount = null;
			editPassword = null;
			editVerifyCode = null;
			buttonDisplayPwd = null;
			buttonAction =null;
			buttonGetVerifyCode = null;
			layoutError = null; 
			textError = null; 			
		}
	}

	private class PwdForgetActivityHelper {
		
		private PwdForgetViewHolder mViewHolder = null;
		   // 返回出错信息 如果成功 则返回空
		private void start(BaseAppActivity loginActivity) {
			mViewHolder = new PwdForgetViewHolder();
			mViewHolder.initView();	
			initView();
		}

		private void initView() {
			if (null == mViewHolder)
				return;
			initAccountInput();
			initPasswordInput();
			initDisplayPwdButton();			
			initGetVerifyCodeButton();
			initActionButton();
		}		

		private void clear(){
			if (null != mViewHolder) {
				mViewHolder.clear();
				mViewHolder = null;
			}
		}

		private void initAccountInput() {
	        if (null == mViewHolder.editAccount) 
	        	return;
	        AppUserManager.HistoryUserAccount lastaccount = AppDragon.core.getUserManager().getLastLoginAccount();
	        if (null != lastaccount) {
		        if (!TextUtils.isEmpty(lastaccount.accountName)){
		           	mViewHolder.editAccount.setText(lastaccount.accountName);
		                // 如果有记住上一次的 登录账号 默认输入位置 设在密码输入框上
		                // 细节
		           	if (null != mViewHolder.editPassword) {
			           	mViewHolder.editPassword.requestFocus();
		           	}
		        }
	        }
	        mViewHolder.editAccount.addTextChangedListener(new TextWatcher(){
	    		@Override
	    		public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
	    		@Override
	    		public void onTextChanged(CharSequence s, int start, int before, int count) {
	    			//showError(null);
	    		}
	    		@Override
	    		public void afterTextChanged(Editable s) {}});			
		}
		
		private void initDisplayPwdButton() {
	        if (null == mViewHolder.buttonDisplayPwd) 
	        	return;
	        mViewHolder.buttonDisplayPwd.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
			        if (null != mViewHolder.editPassword) {
				        TextViewUtils.switchPasswordShowHide(mViewHolder.editPassword, mViewHolder.buttonDisplayPwd);
			        }
			}});	        				
		}
		
		private void initPasswordInput() {
	        if (null ==mViewHolder.editPassword) 
	        	return;
	        mViewHolder.editPassword.addTextChangedListener(new TextWatcher(){
	  			  @Override
	  			  public void beforeTextChanged(CharSequence s, int start, int count, int after) {
	  			  }
	  			  @Override
	  			  public void onTextChanged(CharSequence s, int start, int before, int count) {
	  				  //showError(null);
	  			  }
	  			  @Override
	  			  public void afterTextChanged(Editable s) {
	  		 }});			
		}

		private void initGetVerifyCodeButton() {
	        if (null == mViewHolder.buttonGetVerifyCode) 
	        	return;			
	        mViewHolder.buttonGetVerifyCode.setOnClickListener(new OnClickListener() {
	    		@Override
	    		public void onClick(View v) {
					sendGetVerifyCodeRequest();	    			
	    		}	        	
	        });
		}
		
		private void initActionButton() {
	        if (null ==mViewHolder.buttonAction) 
	        	return;
	        mViewHolder.buttonAction.setOnClickListener(new OnClickListener(){
	    		@Override
	    		public void onClick(View v) {
					if (verifyActionParam()) 
						sendActionRequest();
	    		}
	    	});        						
		}

		private boolean verifyUserAccount(){
	        /*/
	        UserRegister reg = new UserRegister();
	    	if (!reg.verifyMobileNum(ednum.getText().toString())){
	    		// 手机号 错误先提示一下
	    		showError(getResources().getString(R.string.err_warning_inputvalidmobile));
	            ednum.requestFocus();
	    		return false;
	    	}
	    	//*/
	    	return true;
		}
		
		private boolean verifyPassword(){
			/*/
	        EditText edpwd = (EditText) findViewById(R.id.edLoginPassword);
	        UserRegister reg = new UserRegister();
	    	if (!reg.verifyPassword(edpwd.getText().toString())){
	    		showError(getResources().getString(R.string.err_warning_inputpassword));
	            edpwd.requestFocus();
	            return false;
	    	}
	    	//*/
	        return true;
		}

		private boolean verifyVerifyCode() {
	        return true;			
		}
		
	    private boolean verifyActionParam(){
	    	if (!verifyUserAccount())
	    		return false;
	    	if (!verifyPassword())
	    		return false;
	    	if (!verifyVerifyCode())
	    		return false;
	    	return true;
	    }

	    private void sendGetVerifyCodeRequest(){
			if (!verifyUserAccount()) {
				return;
			}
			NetState state = new NetState();
			if (!state.isNetworkConnected()) {
				//AppManager.getAppManager().showToast(UserRegisterActivity.this.getResources().getString(R.string.err_warning_netconnect));
				return;
			}
			//startCountDownTimer();
	        (new Thread(){
				@Override  
				public void run(){
					String useraccount = mViewHolder.editAccount.getText().toString();
					UserPwdReset action = new UserPwdReset();
					action.doRequestSmsCode(useraccount);
					action = null;
				}
	        }).start();	    	
	    }

	    private ProgressDialog mProgressDialog = null;	    
	    // 发送登录请求
	    private void sendActionRequest(){
	    	try {
	        	if (null != mProgressDialog)
	        	    mProgressDialog.cancel();
	    	} catch (Exception e) {    		
	    	}
	        (new Thread(){
				@Override  
				public void run(){
					UserPwdReset action = new UserPwdReset();
					UserAccount account = AppDragon.core.getUserManager().newAccount();
					String useraccount = mViewHolder.editAccount.getText().toString();
					String password = mViewHolder.editPassword.getText().toString();
					String verifycode = mViewHolder.editVerifyCode.getText().toString();
					String ret = action.doResetPwd(
							useraccount, 
							password, 
							verifycode);
					if (null != ret) {
						
					} else {
						
					}
				}
	        }).start();
	    }
	}
}
