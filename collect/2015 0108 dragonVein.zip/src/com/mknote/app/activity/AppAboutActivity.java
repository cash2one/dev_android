package com.mknote.app.activity;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.mknote.dragonvein.R;

public class AppAboutActivity extends BaseAppActivity {

	private static String LOGTAG = AppAboutActivity.class.getSimpleName();
	
	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_about);
        //--------------------------------------------------------------------------
        //setBaseTitle(idStr(R.string.action_aboutapp));
        // 初始化 退出动画的参数 没有参数可能无法动画效果
    	//initCloseAnimationParam();
		//initBackButton();  
        //--------------------------------------------------------------------------
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		System.gc();
	}

	private class ActivityHelper {
		
		private void initViews (AppAboutActivity activity) {
			txtAboutVersion = (TextView) activity.findViewById(R.id.txtAboutVersion);			
		}

		private TextView txtAboutVersion = null;
		
		private void initViews() {
			//contentView = (TextView)findViewById(R.id.txtAboutContent);
			//AppConfig config = RenMai.mInstance.getConfig();
			String ver = null; //config.getVersionName();
			//int verCode = config.getVersionCode();
			if (null != txtAboutVersion) {
				if (ver.indexOf("d") > 0) {
					//txtAboutVersion.setText(idStr(R.string.text_currentversion) + " V" + ver + "/" + verCode);
				} else {
					String[] verstrarray = ver.split("_");
					if (verstrarray.length == 2) {
						//txtAboutVersion.setText(idStr(R.string.text_currentversion) + " V" + verstrarray[0]);
					} else {
						//txtAboutVersion.setText(idStr(R.string.text_currentversion) + " V" + ver);
					}
				}
			}
		}
	}	
}
