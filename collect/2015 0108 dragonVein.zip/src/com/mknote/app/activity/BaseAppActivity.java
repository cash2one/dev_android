package com.mknote.app.activity;

import com.mknote.dragonvein.GlobleConsts;
import com.mknote.libs.Log;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Toast;

public class BaseAppActivity extends android.app.Activity {

	private static String LOGTAG = BaseAppActivity.class.getSimpleName();
	
	@Override
	protected void onCreate(android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onDestroy() {
		Log.d(LOGTAG + " " + BaseAppActivity.this.getClass().getSimpleName() + " onDestroy");
		try {
		    if (null != mActivityBroadcastReceiver) {
		    	unregisterReceiver(mActivityBroadcastReceiver);
		    	mActivityBroadcastReceiver = null;
		    }
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (null !=mBaseMsgHandler) {
			mBaseMsgHandler = null;
		}
		super.onDestroy();
	}
	protected android.content.BroadcastReceiver mActivityBroadcastReceiver = null;
	
	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	public void finish() {
		super.finish();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}
	
    @Override
    protected void onSaveInstanceState(android.os.Bundle savedInstanceState){
    	super.onSaveInstanceState(savedInstanceState);
	}
    
    @Override
    protected void onRestoreInstanceState(android.os.Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
    }
    
	// 开启另一个 activity
	public void redirectToActivity (Class destActivityClass) {
		android.content.Intent intent = new android.content.Intent();
		intent.setClass(this, destActivityClass);
		this.startActivity(intent);
	}	

	// 开启另一个 activity
	public void redirectToActivity (Class destActivityClass, int requestCode) {
		android.content.Intent intent = new android.content.Intent();
		intent.setClass(this, destActivityClass);
		this.startActivityForResult(intent, requestCode);
	}	

	protected String idStr(int id) {
		return getResources().getString(id);
	}

	public void callCloseActivity(){
		 if (null != mBaseMsgHandler)
			 mBaseMsgHandler.sendEmptyMessage(GlobleConsts.MSG_ACTIVITY_CLOSE);
	}

	protected Handler mBaseMsgHandler = null;
	
	public Handler getBaseMsgHandler() {
		return mBaseMsgHandler;
	}
	
	protected void createMessageLoopHandler(){
		if (null != mBaseMsgHandler)
			return;
		Looper loop = Looper.getMainLooper();  
		mBaseMsgHandler = new Handler(loop){  
		    @Override  
		    public void handleMessage(Message msg) {  
		        super.handleMessage(msg);  
		        handleActivityMessage(msg);
		    }  
		};  		
	}

	protected boolean handleActivityMessage(Message msg){
        switch (msg.what) {  
        case GlobleConsts.MSG_TOAST:        	  
      	     Toast.makeText(this, (String)msg.obj, Toast.LENGTH_LONG).show();
             break;
         case GlobleConsts.MSG_ACTIVITY_CLOSE:
        	 finish();
             break;
      }
		return false;
	}
}
