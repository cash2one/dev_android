package com.mknote.app.activity;

import java.util.Timer;
import java.util.TimerTask;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mknote.app.UserAccount;
import com.mknote.app.UserRegister;
import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.MainActivity;
import com.mknote.dragonvein.R;
import com.mknote.dragonvein.core.NetManager;
import com.mknote.dragonvein.libs.TextViewUtils;
import com.mknote.libs.Log;
import com.mknote.net.NetState;

public class UserRegisterActivity extends BaseAppActivity {

	private static String LOGTAG = UserRegisterActivity.class.getSimpleName();
	private static final int MSG_SHOW_ERROR = 3001;
	
	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_userreg);
        createMessageLoopHandler();
        mHelper = new UserRegActivityHelper();
        mHelper.start(this);
	}
	
	@Override
	protected void onDestroy() {
		clear();
		super.onDestroy();
		System.gc();
	}

	private void clear() {
		if (null != mHelper) {
			mHelper.clear();
			mHelper = null;
		}
	}

	@Override
	protected boolean handleActivityMessage(Message msg){
		super.handleActivityMessage(msg);
    	switch (msg.what) {
 	        case MSG_SHOW_ERROR:
 	    	    try {
 	        	    if (null != mHelper.mProgressDialog)
 	        	    	mHelper.mProgressDialog.cancel();
 	    	    } catch (Exception e) {    		
 	    	    }
 	    	   mHelper.showError((String) msg.obj);
 		       break;    	   
    	}   
		return false;
	}
	
	private void createBroadcastReceiver(){
        //注册广播接收器
		mActivityBroadcastReceiver =new BroadcastReceiver() {
		    @Override
		  	public void onReceive(Context context, Intent intent) {
		  		if (intent.getAction().equals(GlobleConsts.BROADCAST_USER_LOGIN)) {
		  			UserRegisterActivity.this.clear();
		            UserRegisterActivity.this.finish();
		  		}
		  	}
		};
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(GlobleConsts.BROADCAST_USER_LOGIN);
		registerReceiver(mActivityBroadcastReceiver, intentFilter);
	}
	
	private class CountDownTimer {
		
		private CountDownTimer(UserRegViewHolder viewHolder) {
			mViewHolder = viewHolder;
		}
		
		private int mCountDownCounter = 0;
    	private UserRegViewHolder mViewHolder;
    	private Handler mCountDownHandler;
    	private Timer mCountDownTimer;
    	
    	private void clear() {
        	mViewHolder = null;
        	mCountDownHandler = null;
        	if (null != mCountDownTimer) {
        		mCountDownTimer.cancel();
            	mCountDownTimer = null;
        	}
    	}
    	
		private void start(int counter) {
			mCountDownCounter = counter;
	    	if (null != mViewHolder.buttonGetVerifyCode) {
				mViewHolder.buttonGetVerifyCode.setEnabled(false);	    		
	    	}
	    	mCountDownHandler = new Handler(){
			    @Override  
			    public void handleMessage(Message msg) {  
			        super.handleMessage(msg);  
	            	 if (0 == msg.what){
	            		 if (mCountDownCounter > 0) {
	            		     if (null != mViewHolder.buttonGetVerifyCode) {
	            			     mViewHolder.buttonGetVerifyCode.setText(mCountDownCounter + "秒");
	            		     }
	            		 } else {
	            		     if (null != mViewHolder.buttonGetVerifyCode) {
	            			     mViewHolder.buttonGetVerifyCode.setEnabled(true);
	            			     mViewHolder.buttonGetVerifyCode.setText("再次获取验证码");
	            		     }
	                		 mCountDownTimer.cancel();	            			 
	            		 }
	            	 }
			    }
	    	};
	        mCountDownTimer = new Timer();
	        mCountDownTimer.schedule(new TimerTask() {
	            @Override
	            public void run() {
	           		mCountDownCounter--;
	           		mCountDownHandler.sendEmptyMessage(0);
	            }
	        }, 0, 1000);
		}		
	}
	
	private UserRegActivityHelper mHelper = null;

	private class UserRegViewHolder {
		private EditText editAccount = null;
		private EditText editPassword = null;
		private EditText editVerifyCode = null;
		private View buttonDisplayPwd = null;
		private View buttonAction = null;
		private Button buttonGetVerifyCode = null;
		private View layoutError = null; 
		private TextView textError = null; 		

		private void initView() {
	        editAccount = (EditText) findViewById(R.id.edUserAccount);
	        editPassword = (EditText) findViewById(R.id.edPassword);
	        buttonDisplayPwd = (View) findViewById(R.id.btnDisplayPwd);
	        editVerifyCode = (EditText) findViewById(R.id.edVerifyCode);
	        buttonGetVerifyCode =  (Button) findViewById(R.id.btnGetVerifyCode);
	        buttonAction = (View) findViewById(R.id.btnAction);
	    	layoutError = (View) findViewById(R.id.layoutErrorHint);
			textError = (TextView) findViewById(R.id.txtError);
		}
		
		private void clear() {
			editAccount = null;
			editPassword = null;
			editVerifyCode = null;
			buttonDisplayPwd = null;
			buttonAction = null;
			buttonGetVerifyCode =  null;
			layoutError = null; 
			textError = null; 			
		}
	}
	
	private class UserRegActivityHelper {

		private UserRegViewHolder mViewHolder = null;
		private CountDownTimer mCountDownTimer = null;
		   // 返回出错信息 如果成功 则返回空
		private void start(BaseAppActivity loginActivity) {
			mViewHolder = new UserRegViewHolder();
			mViewHolder.initView();	
			initView();
			createBroadcastReceiver();
		}

		private void initView() {
			if (null == mViewHolder)
				return;
			initAccountInput();
			initPasswordInput();
			initDisplayPwdButton();
			initVerifyCodeInput();
			initGetVerifyCodeButton();
			initActionButton();
		}
		
		private void clear(){
			if (null != mViewHolder) {
				mViewHolder.clear();
				mViewHolder = null;
			}
			if (null != mCountDownTimer) {
				mCountDownTimer.clear();
			}
		}

		private void initAccountInput() {
	        if (null == mViewHolder.editAccount) 
	        	return;
	        mViewHolder.editAccount.addTextChangedListener(new TextWatcher(){
	    		@Override
	    		public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
	    		@Override
	    		public void onTextChanged(CharSequence s, int start, int before, int count) {
	    			showError(null);
	    		}
	    		@Override
	    		public void afterTextChanged(Editable s) {}});
		}
		
		private void initDisplayPwdButton() {
	        if (null == mViewHolder.buttonDisplayPwd) 
	        	return;
	        mViewHolder.buttonDisplayPwd.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
			        if (null != mViewHolder.editPassword) {
				        TextViewUtils.switchPasswordShowHide(mViewHolder.editPassword, mViewHolder.buttonDisplayPwd);
			        }
			}});	        	
		}
		
		private void initPasswordInput(){
	        if (null ==mViewHolder.editPassword) 
	        	return;
	        mViewHolder.editPassword.addTextChangedListener(new TextWatcher(){
	  			  @Override
	  			  public void beforeTextChanged(CharSequence s, int start, int count, int after) {
	  			  }
	  			  @Override
	  			  public void onTextChanged(CharSequence s, int start, int before, int count) {
	  				  showError(null);
	  			  }
	  			  @Override
	  			  public void afterTextChanged(Editable s) {
	  		 }});
		}

		private void initVerifyCodeInput() {
	        if (null ==mViewHolder.editVerifyCode) 
	        	return;
	        mViewHolder.editVerifyCode.addTextChangedListener(new TextWatcher(){
	  			  @Override
	  			  public void beforeTextChanged(CharSequence s, int start, int count, int after) {
	  			  }
	  			  @Override
	  			  public void onTextChanged(CharSequence s, int start, int before, int count) {
	  				  showError(null);
	  			  }
	  			  @Override
	  			  public void afterTextChanged(Editable s) {
	  		 }});			
		}
		
		private void initGetVerifyCodeButton() {
	        if (null == mViewHolder.buttonGetVerifyCode) 
	        	return;			
	        mViewHolder.buttonGetVerifyCode.setOnClickListener(new OnClickListener() {
	    		@Override
	    		public void onClick(View v) {
					sendGetVerifyCodeRequest();	    			
	    		}	        	
	        });
		}
		
		private void initActionButton() {
	        if (null ==mViewHolder.buttonAction) 
	        	return;
	        mViewHolder.buttonAction.setOnClickListener(new OnClickListener(){
	    		@Override
	    		public void onClick(View v) {
					if (verifyActionParam()) 
						sendActionRequest();
	    		}
	    	});        			
		}

		private boolean verifyUserAccount(){
	        /*/
	        UserRegister reg = new UserRegister();
	    	if (!reg.verifyMobileNum(ednum.getText().toString())){
	    		// 手机号 错误先提示一下
	    		showError(getResources().getString(R.string.err_warning_inputvalidmobile));
	            ednum.requestFocus();
	    		return false;
	    	}
	    	//*/
	    	return true;
		}
		
		private boolean verifyPassword(){
	        /*/
	        EditText edpwd = (EditText) findViewById(R.id.edLoginPassword);
	        UserRegister reg = new UserRegister();
	    	if (!reg.verifyPassword(edpwd.getText().toString())){
	    		showError(getResources().getString(R.string.err_warning_inputpassword));
	            edpwd.requestFocus();
	            return false;
	    	}
	    	//*/
	        return true;
		}

		private boolean verifyVerifyCode() {
	        return true;			
		}
		
	    // 验证注册参数
	    private boolean verifyActionParam(){
	        // 验证手机号
	    	if (!verifyUserAccount())
	    		return false;
	    	if (!verifyPassword())
	    		return false;
	    	if (!verifyVerifyCode())
	    		return false;
	    	return true;
	    }

	    // 显示错误提示
	    private void showError(String errMessage){
	    	if (null == mViewHolder)
	    		return;
	    	if (TextUtils.isEmpty(errMessage)) {
	        	if (null != mViewHolder.layoutError)
	        		mViewHolder.layoutError.setVisibility(View.INVISIBLE);
	    	} else {
	        	if (null != mViewHolder.layoutError)
	        		mViewHolder.layoutError.setVisibility(View.VISIBLE);
	    	}
	    	if (null != mViewHolder.textError) {
		    	mViewHolder.textError.setText(errMessage);
	    	} 
	    }

	    private void sendGetVerifyCodeRequest() {
	    	Log.d(LOGTAG + " " + "sendGetVerifyCodeRequest begin");
			if (!verifyUserAccount()) {
				return;
			}
			NetState state = new NetState();
			if (!state.isNetworkConnected()) {
				//AppManager.getAppManager().showToast(UserRegisterActivity.this.getResources().getString(R.string.err_warning_netconnect));
				return;
			}
			CountDownTimer mCountDownTimer = new CountDownTimer(mViewHolder);
			mCountDownTimer.start(60);
			
	        (new Thread(){
				@Override  
				public void run(){
					Log.d(LOGTAG + " " + "sendGetVerifyCodeRequest");
					String useraccount = mViewHolder.editAccount.getText().toString();
					UserRegister action = new UserRegister();
					action.doRequestSmsCode(useraccount);
					action = null;
				}
	        }).start();
	    }
	    
	    private ProgressDialog mProgressDialog = null;	    
	    // 发送登录请求
	    private void sendActionRequest(){
	    	try {
	        	if (null != mProgressDialog)
	        	    mProgressDialog.cancel();
	    	} catch (Exception e) {    		
	    	}
	    	mProgressDialog = ProgressDialog.show(UserRegisterActivity.this, "", idStr(R.string.user_reging), true, false);
	        (new Thread(){
				@Override  
				public void run(){
					Log.d(LOGTAG + " " + "sendActionRequest");
					UserRegister action = new UserRegister();
					UserAccount account = AppDragon.core.getUserManager().newAccount();
					String useraccount = mViewHolder.editAccount.getText().toString();
					String password = mViewHolder.editPassword.getText().toString();
					String verifycode = mViewHolder.editVerifyCode.getText().toString();
					UserRegister.RegisterResult regret = action.doRegister(
							useraccount, 
							password, 
							verifycode, 
							"", 
							account);
					if (null != regret) {
						if (regret.isSuccess) {
							Log.d(LOGTAG + " " + " register success ");
							if (null != account) {
								AppDragon.core.getUserManager().setLoginedActiveUserAccount(account);
								AppDragon.mApp.sendBroadcast(GlobleConsts.BROADCAST_USER_LOGIN, null);
							}
						} else {
							Log.d(LOGTAG + " " + " register fail " + regret.errorMsg);
							if (null != mBaseMsgHandler) {
								android.os.Message msg = new android.os.Message();
								msg.what = MSG_SHOW_ERROR;
								msg.obj = regret.errorMsg;
								mBaseMsgHandler.sendMessage(msg);
							}
						}
					} else {
					}
				}
	        }).start();
	    }
	}
}
