package com.mknote.app.activity;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.R;
import com.mknote.dragonvein.core.AppConfigManager;

import android.content.Intent;
import android.os.Build; 
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.TextView;

public class AppShareDialog extends AppDialogActivity {

	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		Window localWindow = getWindow();
		// 这句话 搞定 贴底
		localWindow.setGravity(Gravity.BOTTOM);
		setContentView(R.layout.activity_dialog_update);
		// 点击activity空白处不消失也可以代码里面设置，在onCreate()方法里面加上
        // API Level >= 11
        if(Build.VERSION.SDK_INT >= 11){
		   this.setFinishOnTouchOutside(false);
        }
		Display display = getWindowManager().getDefaultDisplay();
		Window window = getWindow();  
		LayoutParams windowLayoutParams = window.getAttributes();
		windowLayoutParams.width = (int) (display.getWidth());
		window.setAttributes(windowLayoutParams);
		
		initViews();
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		System.gc();
	}

	private void initViews() {
	}

	private void initDialogTitle(String title){
		this.setTitle(title);
		TextView textview = (TextView)findViewById(R.id.txtDialogTitle);
		if (null != textview)
		    textview.setText(title);
	}		

	private void initDialogMsg(String msg1, String msg2){
		TextView textview = (TextView)findViewById(R.id.txtDialogMessage1);
		if (!TextUtils.isEmpty(msg1)) {
  		  textview.setText(msg1);
  		  textview.setMovementMethod(ScrollingMovementMethod.getInstance());  
		} else {
		  textview.setVisibility(View.GONE);
		}

		textview = (TextView)findViewById(R.id.txtDialogMessage2);
		if (!TextUtils.isEmpty(msg2)) {
  		    textview.setText(msg2);
  		    textview.setMovementMethod(ScrollingMovementMethod.getInstance());
		} else {
		    textview.setVisibility(View.GONE);
		}
	}		
}
