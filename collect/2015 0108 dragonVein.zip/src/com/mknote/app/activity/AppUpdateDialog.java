package com.mknote.app.activity;

import com.mknote.app.AppUpdate;
import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.R;
import com.mknote.dragonvein.core.AppConfigManager;

import android.content.Intent;
import android.os.Build; 
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.TextView;

public class AppUpdateDialog extends AppDialogActivity {

	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		Window localWindow = getWindow();
		// 这句话 搞定 贴底
		localWindow.setGravity(Gravity.BOTTOM);
		setContentView(R.layout.activity_dialog_update);
		// 点击activity空白处不消失也可以代码里面设置，在onCreate()方法里面加上
        // API Level >= 11
        if(Build.VERSION.SDK_INT >= 11){
		   this.setFinishOnTouchOutside(false);
        }
		Display display = getWindowManager().getDefaultDisplay();
		Window window = getWindow();  
		LayoutParams windowLayoutParams = window.getAttributes();
		windowLayoutParams.width = (int) (display.getWidth());
		window.setAttributes(windowLayoutParams);
		
		initViews();
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		System.gc();
	}

	private void initViews() {
		Button btnupdate = (Button) findViewById(R.id.btnDialog1);
		btnupdate.setText(getResources().getString(R.string.app_update));
		btnupdate.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
					AppUpdate updater = new AppUpdate();					
					AppUpdate.UpdateSession updatesession = updater.getCurrentUpdateSession();
					if (null != updatesession) {
						AppConfigManager.AppConfig config = AppDragon.mApp.getConfig();
						if (null != config) {
						    config.appUpdateIgnore = "";
							AppConfigManager.Save(config);
						}
						//AppUpdate.getAppUpdate().doUpdate();	
						updater.runUpdateIntallPackage(AppUpdateDialog.this, updater.getUpdateLocalSaveFileUrl(updatesession));		
					}
		}});

		Button btncancel = (Button) findViewById(R.id.btnDialog2);
		btncancel.setText(getResources().getString(R.string.button_cancel));
		btncancel.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
					// 如果没有不再提醒的 check box 直接设置为 永久忽略该版本
					// 可以再 设置里的 更新 再完成更新
					AppConfigManager.AppConfig config = AppDragon.mApp.getConfig();
					if (null != config) {
						AppUpdate updater = new AppUpdate();
						AppUpdate.UpdateSession updatesession = updater.getCurrentUpdateSession();
						if (null != updatesession) {
						    config.appUpdateIgnore = updatesession.lastestVersionName;
							AppConfigManager.Save(config);
						}
					}
					//buttonCancelOnClick();
					setResult(RESULT_CANCELED);
					finish();  
					overridePendingTransition(R.anim.slide_bottom_in, R.anim.slide_bottom_out);
		}});
		AppUpdate update = new AppUpdate();
		AppUpdate.UpdateSession updatesession = update.getCurrentUpdateSession();
		if (null != updatesession) {
			initDialogTitle(String.format(
					getResources().getString(R.string.dialog_title_update), 
					updatesession.lastestVersionName
					));
			initDialogMsg(updatesession.lastestVersionBrief, null);
		}
	}

	private void initDialogTitle(String title){
		this.setTitle(title);
		TextView textview = (TextView)findViewById(R.id.txtDialogTitle);
		if (null != textview)
		    textview.setText(title);
	}		

	private void initDialogMsg(String msg1, String msg2){
		TextView textview = (TextView)findViewById(R.id.txtDialogMessage1);
		if (!TextUtils.isEmpty(msg1)) {
  		  textview.setText(msg1);
  		  textview.setMovementMethod(ScrollingMovementMethod.getInstance());  
		} else {
		  textview.setVisibility(View.GONE);
		}

		textview = (TextView)findViewById(R.id.txtDialogMessage2);
		if (!TextUtils.isEmpty(msg2)) {
  		    textview.setText(msg2);
  		    textview.setMovementMethod(ScrollingMovementMethod.getInstance());
		} else {
		    textview.setVisibility(View.GONE);
		}
	}		
}
