package com.mknote.app;

import java.io.File;

import org.apache.thrift.TException;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.core.AppConfigManager;
import com.mknote.dragonvein.core.NetManager;
import com.mknote.libs.Log;
import com.mknote.net.RenmaiClient;
import com.mknote.net.thrift.KeyResp;
import com.mknote.net.thrift.ServerError;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;

public class AppShare {

	private static final String LOGTAG = AppShare.class.getSimpleName();
	
	// 如何让自己的应用也加入这个分享列表
	/*/
<intent-filter>  
    <action android:name="android.intent.action.SEND"></action>  
    <category android:name="android.intent.category.DEFAULT"></category>  
    <data android:mimeType="text/plain"></data>  
</intent-filter>

  获取分享列表
  public List<ResolveInfo> getShareTargets(){  
    List<ResolveInfo> mApps = new ArrayList<ResolveInfo>();  
    Intent intent=new Intent(Intent.ACTION_SEND,null);  
    intent.addCategory(Intent.CATEGORY_DEFAULT);  
    intent.setType("text/plain");  
    PackageManager pm=this.getPackageManager();  
    mApps=pm.queryIntentActivities(intent,PackageManager.COMPONENT_ENABLED_STATE_DEFAULT);  
    return mApps;  
  }  
	//*/
	
	public void doShare(Context context, String sharetext) {
		Intent intent=new Intent(Intent.ACTION_SEND); 
		intent.setType("text/plain"); 
		intent.putExtra(Intent.EXTRA_SUBJECT, "分享"); 
		intent.putExtra(Intent.EXTRA_TEXT, sharetext);  
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent = Intent.createChooser(intent, "");
		context.startActivity(intent); 
	}
}
