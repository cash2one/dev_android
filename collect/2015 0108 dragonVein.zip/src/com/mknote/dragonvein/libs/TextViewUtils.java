package com.mknote.dragonvein.libs;

import com.mknote.dragonvein.R;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;

public class TextViewUtils {

	public static void switchPasswordShowHide(EditText edpwd, View btndisplaypwd) {
		if (null == edpwd)
			return;
    	int editCursorPos1 = edpwd.getSelectionStart();
    	int editCursorPos2 = edpwd.getSelectionEnd();
	    if (edpwd.getTransformationMethod().getClass().equals(PasswordTransformationMethod.class)) {
	        //if (edpwd.getInputType() == InputType.TYPE_TEXT_VARIATION_PASSWORD) {
	            //edpwd.setInputType(InputType.TYPE_TEXT_VARIATION_NORMAL);
	            edpwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
	            if (null != btndisplaypwd)
		              btndisplaypwd.setBackgroundResource(R.drawable.btn_see_un);   
	    } else {
	            //edpwd.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
	            edpwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
	            if (null != btndisplaypwd)
		              btndisplaypwd.setBackgroundResource(R.drawable.btn_see);
	    }
        edpwd.setSelection(editCursorPos1, editCursorPos2);
	}
	
}
