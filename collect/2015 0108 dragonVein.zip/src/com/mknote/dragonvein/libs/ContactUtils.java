package com.mknote.dragonvein.libs;

import java.io.UnsupportedEncodingException;
import java.util.Locale;
import java.util.regex.*;

import com.mknote.libs.UnicodePingyin;

public class ContactUtils {

	// 格式化手机号码
	// ip电话 17951,17909,17969,17908,12593

	public static String phoneNumFormat(String phoneNum) {
		String phone = phoneNum;
		phone = phone.replaceAll("[^0-9]+", "");
		phone = phone.replaceAll("^(86)?(17951|17909|17969|17908|12593)?(86)?", "");
		if (phone.length() != 11 || !phone.substring(0, 1).equals("1"))
			phone = null;
		// Log.d("phone " + phoneNum + " -> " + phone);
		return phone;
	}

	public static String parseSortKey(String str) {
		UnicodePingyin py = UnicodePingyin.getInstance();
		StringBuilder s = new StringBuilder();
		StringBuilder yw = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			// 检查是否在中文unicode范围内，是否能返回拼音，不能返回为null
			String pinyin = py.pingyin(c);
			if (pinyin != null) {
				// 先把前面的字符处理掉
				if(yw.length()>0){
					s.append(yw.toString().toUpperCase(Locale.CHINA));
					s.append(" ");
					yw.setLength(0);
				}
				s.append(pinyin);
				s.append(c);
			}
			else {
				if(c>0xFF00 && c<0xFF5F){
					c = (char)(c - 0xFF00 + 0x20);
				}
				yw.append(c);
			}
		}
		if(yw.length()>0){
			s.append(yw.toString().toUpperCase(Locale.CHINA));
			s.append(" ");
			yw.setLength(0);
		}
		return s.toString();
	}

	public static final String full2HalfChange(String QJstr) throws UnsupportedEncodingException {
		StringBuffer outStrBuf = new StringBuffer("");
		String Tstr = "";
		byte[] b = null;
		for (int i = 0; i < QJstr.length(); i++) {
			Tstr = QJstr.substring(i, i + 1);
			// 全角空格转换成半角空格
			if (Tstr.equals("　")) {
				outStrBuf.append(" ");
				continue;
			}
			b = Tstr.getBytes("unicode");
			// 得到 unicode 字节数据
			if (b[2] == -1) {
				// 表示全角？
				b[3] = (byte) (b[3] + 32);
				b[2] = 0;
				outStrBuf.append(new String(b, "unicode"));
			} else {
				outStrBuf.append(Tstr);
			}
		} // end for.
		return outStrBuf.toString();
	}
}
