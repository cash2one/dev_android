package com.mknote.dragonvein.libs;

import java.util.ArrayList;
import java.util.List;

import org.apache.thrift.TException;

import android.text.TextUtils;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.data.DVStorage;
import com.mknote.dragonvein.entity.Contact;
import com.mknote.libs.Log;
import com.mknote.net.RenmaiClient;
import com.mknote.net.thrift.ContactEntity;
import com.mknote.net.thrift.ContactResp;
import com.mknote.net.thrift.FriendEntity;
import com.mknote.net.thrift.FriendListResp;
import com.mknote.net.thrift.ServerError;

public class FriendUtils {

	// 获取一度人脉数据
	public void getFriendsFromServer() {
		Log.d("FriendUtils getFriendsFromServer begin");		
		RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient();
		if (null == client)
			return;
		try {
			int lastTimestamp = 0;
			FriendListResp listret = client.listFriends(lastTimestamp);
			if (null != listret) {
				DVStorage.saveFriendList(listret.friendList, listret.friendCount);
			} else {
				
			}
		} catch (ServerError e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		}
		Log.d("FriendUtils getFriendsFromServer end");
	}
	
	public void uploadContacts (List<Contact> contacts) {
		if (null == contacts)
			return;
		Log.d("FriendUtils uploadContacts begin");		
		RenmaiClient client = AppDragon.core.getNet().CreateRenmaiClient();
		if (null == client)
			return;
		
		List<ContactEntity> tmpcontacts_entity = new ArrayList();
		try {
				for (int i = 0; i < contacts.size(); i++) {
					Contact contact = contacts.get(i);
					ContactEntity tmpcontactentity = new ContactEntity();
					// fill entity load from contact
					tmpcontactentity.DisplayName = contact.getName();
					tmpcontacts_entity.add(tmpcontactentity);
				}
			//*/
			ContactResp uploadret = client.UploadContacts(tmpcontacts_entity);
		} catch (ServerError e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		} finally {
			tmpcontacts_entity.clear();
			tmpcontacts_entity = null;
		}
		Log.d("FriendUtils uploadContacts end");
	} 
}
