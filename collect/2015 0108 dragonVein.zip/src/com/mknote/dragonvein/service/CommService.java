package com.mknote.dragonvein.service;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.R.color;
import com.mknote.libs.Log;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class CommService extends Service {

	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		Log.d("chenchao", "ContactManager start");
		AppDragon.core.getContactManager().importContactsToLocal();
		return START_REDELIVER_INTENT;
	}

	
}
