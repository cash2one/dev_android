package com.mknote.dragonvein.activity;

import java.util.ArrayList;
import java.util.List;

import com.mknote.dragonvein.R;
import com.mknote.dragonvein.adapter.MessageAdapter;
import com.mknote.dragonvein.asmack.AsmackConnectManager;
import com.mknote.dragonvein.asmack.AsmackMessage;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class RoomChatActivity extends Activity {
	
	private EditText message;
	private Button  sendmessage;
	public static String roomid;
	public static String roomname;
	private TextView roomnameTextView;
	private ListView messageListView;
	private List<AsmackMessage> messageList;
	private MessageAdapter adapter;
	public static Handler handler;
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
	     super.onCreate(savedInstanceState);
	     setContentView(R.layout.activity_room_chat);
	     
	     AsmackConnectManager.activity=this;
	     messageList=new ArrayList<AsmackMessage>();
	     
	     roomnameTextView=(TextView)findViewById(R.id.roomname);
	     message=(EditText)findViewById(R.id.room_message);
	     sendmessage=(Button)findViewById(R.id.room_sendmessage);
	     messageListView=(ListView)findViewById(R.id.room_messagebody);
	     
	     roomnameTextView.setText(roomname);
	     
	     
	     handler=new Handler()
	     { 
	        @Override
	        public void handleMessage(android.os.Message msg) {
	        	try {
	        		Bundle bundle=msg.getData();
	            	String name=bundle.getString("name");
	            	String message=bundle.getString("message");
	            	boolean issend=bundle.getBoolean("issend");
	            	addview(name, message, issend);
				} catch (Exception e) {
					e.printStackTrace();
				}
	        	super.handleMessage(msg);
	        	}
	     };
	     
	     
	     AsmackConnectManager.handler=handler;
	     
	     sendmessage.setOnClickListener(new OnClickListener() {
				
			public void onClick(View v) {
				AsmackConnectManager.semdrommessage(message.getText().toString(),roomid);
			}
				
		});
	     
	     
	     messageList=new ArrayList<AsmackMessage>();
	     adapter=new MessageAdapter(messageList, this);
	     messageListView.setAdapter(adapter);
	 }
	 
	 protected void addview(String name, String msg, boolean issend) {

		 AsmackMessage message=new AsmackMessage(name, msg, issend);
		messageList.add(message);
		adapter.notifyDataSetChanged();
		messageListView.setSelection(messageList.size());
	}
	 
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			AsmackConnectManager.QuitRoomChat();
			RoomChatActivity.this.finish();
		}
		return false;
	 }
	 @Override
	 protected void onResume() {
		 AsmackConnectManager.activity=this;
		 AsmackConnectManager.handler=handler;
		super.onResume();

	 }
}
