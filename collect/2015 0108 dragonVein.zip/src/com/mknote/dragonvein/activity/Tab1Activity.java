package com.mknote.dragonvein.activity;

import com.mknote.dragonvein.R;
import com.mknote.dragonvein.R.id;
import com.mknote.dragonvein.R.layout;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Tab1Activity extends Activity{

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.example_activity);
		
		TextView tv = (TextView) findViewById(R.id.example_tv);
		tv.setText("This is Example 1 Activity");
	}
}
