package com.mknote.dragonvein.activity;

import java.util.ArrayList;

import com.mknote.dragonvein.R;
import com.mknote.dragonvein.adapter.CustomList;
import com.mknote.dragonvein.adapter.CustomList.CustomListItem;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class UserInfoActivity extends com.mknote.app.activity.BaseAppActivity {

	private static final String TAG = UserInfoActivity.class.getSimpleName();
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_info);
		initCustomList();
        //setContentView(listView);
		//initViews();
	}

	@Override
	protected void onDestroy() { 
		super.onDestroy();
	}	

	private CustomList mFunctionList = null;
	private void initCustomList() {
		LinearLayout view = (LinearLayout)findViewById(R.id.mainfunctionlayout);
		if (null == view) 
			return;
		mFunctionList = new CustomList(this);
		mFunctionList.addFunctionItem("基本信息", 0, 1, 1);
		mFunctionList.addFunctionItem("头像", 0, 1, 2);
		mFunctionList.addFunctionItem("真实姓名", 0, 1, 3);		
		mFunctionList.addFunctionItem("性别", 0, 1, 4); // select
		mFunctionList.addFunctionItem("行业/方向", 0, 1, 5); // extend tag
		mFunctionList.addFunctionItem("公司", 0, 1, 6);
		mFunctionList.addFunctionItem("职位", 0, 1, 7);
		// ---------------------------------------------------
		mFunctionList.addFunctionItem("详细信息", 0, 1, 8);
		mFunctionList.addFunctionItem("职业标签", 0, 1, 9); // extend tag
		mFunctionList.addFunctionItem("个人标签", 0, 1, 10); // extend tag
		mFunctionList.addFunctionItem("工作经历", 0, 1, 11); // extend
		mFunctionList.addFunctionItem("教育经历", 0, 1, 12); // extend
		// ---------------------------------------------------
		mFunctionList.addFunctionItem("联系方式", 0, 1, 13);
		mFunctionList.addFunctionItem("工作地点", 0, 1, 14); // select extend
		mFunctionList.addFunctionItem("邮箱", 0, 1, 15);				
		mFunctionList.addFunctionItem("微信", 0, 1, 16);		
		mFunctionList.addFunctionItem("QQ", 0, 1, 17);		
		ListView listview = mFunctionList.getListView();
		if (null != listview) {
			listview.setOnItemClickListener(new OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					CustomListItem listitem = mFunctionList.getListItems().get(position);
					switch ((int) listitem.itemId) {
					   case 1:
						   break;
					   case 2:
						   break;
					   case 3:
						   break;
					}
				}				
			});
			view.addView(listview);
		}
	}	
}
