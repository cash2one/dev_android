package com.mknote.dragonvein;

import android.view.View;


/**
 * 所有View的超类
 * @author miles(chenchao_met@163.com)
 * 
 */
public interface IView extends View.OnClickListener{

	/**
	 * 初始化Activity视图
	 */
	public void initViews();
}
