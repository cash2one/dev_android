package com.mknote.dragonvein.core;

import com.mknote.app.UserAccount;
import com.mknote.dragonvein.AppDragon;
import com.mknote.net.Downloader;
import com.mknote.net.RenmaiClient;

/**
 * 人脉服务器接口代理类， 用于提供人脉服务器接口
 * @author Administrator
 *
 */
public class NetManager  extends AbstractManager  {
	
	public NetManager(ManagerFactory core) {
		super(core);
	}

	public RenmaiClient CreateRenmaiClient()
	{
		return CreateRenmaiClient(false);
	}
	
	
	public RenmaiClient CreateRenmaiClient(boolean isNeedEncrypt)
	{
		String clientVersion = AppDragon.getVersion(); 
		AppConfigManager.AppConfig config = AppDragon.mApp.getConfig();
		String deviceID = config.deviceId;
		String channelID = config.channelId;		
		String userToken = null;
		UserAccount account = AppDragon.core.getUserManager().ActiveUser();
		if (null != account) {
			userToken = account.getToken();
		}
		if (null == userToken)
			userToken = "";
		RenmaiClient client = new RenmaiClient(config.serverSetting, 
				deviceID, 
				channelID, 
				clientVersion, "", 
				userToken, 
				isNeedEncrypt
				); 
		
		return client;
	}
	
	public boolean downloadFile(String url, String localsavefileurl, boolean isOverwriteExists){
		Downloader downloader = new Downloader();
  	    return downloader.downloadFile(url, localsavefileurl, isOverwriteExists);
	}
}
