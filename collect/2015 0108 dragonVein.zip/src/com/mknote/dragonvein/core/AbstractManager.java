package com.mknote.dragonvein.core;

public class AbstractManager {

	protected ManagerFactory mCore = null;
	
	public AbstractManager(ManagerFactory core)
	{
		mCore = core;
	}
	
}
