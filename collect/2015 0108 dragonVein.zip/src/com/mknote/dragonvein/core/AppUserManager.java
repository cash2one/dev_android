package com.mknote.dragonvein.core;

import android.text.TextUtils;

import com.mknote.app.UserAccount;
import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.data.DVStorage;
import com.mknote.net.thrift.MKConstants;

public class AppUserManager extends AbstractManager {

	public AppUserManager(ManagerFactory core) {
		super(core);
	}

	public static final short USER_GENDER_UNKNOWN = 0;
	public static final short USER_GENDER_MALE             = MKConstants.GENDER_MALE_1;
	public static final short USER_GENDER_FEMALE         = MKConstants.GENDER_FEMALE_2;
	
    public boolean isLogined() {
    	return (null != mLoginedActiveUserAccount);
    }
    
    public void activeUserLogout() {
    	if (null != mLoginedActiveUserAccount) {
    		mLoginedActiveUserAccount.clear();
    		mLoginedActiveUserAccount = null;
			AppDragon.mApp.sendBroadcast(GlobleConsts.BROADCAST_USER_LOGOUT, null);
    	}
    }
    
    private static UserAccount mLoginedActiveUserAccount = null;
    public void setLoginedActiveUserAccount(UserAccount account) {
    	if (null != account) {
    		if (0 == account.getUserId()) 
    			return;
    		if (TextUtils.isEmpty(account.getToken()))
    			return;
    	}
    	mLoginedActiveUserAccount = account;	
    	AppConfigManager.AppConfig config = AppDragon.mApp.getConfig();
    	if (null != config) {
    		if (null == account) {
        		config.lastUserId = 0;
    		} else {
        		config.lastUserId = account.getUserId();
    		}
    		AppConfigManager.Save(config);    		
    	}
    	if (null != account) {
        	DVStorage.saveUserProfile(account);
    	}
    	// save last login active user account
    }
    
    public UserAccount ActiveUser() {
    	return mLoginedActiveUserAccount;
    }
    
    public UserAccount newAccount() {
    	return new UserAccount();
    }
    
    public void checkAutoLoginUserAccount() {
    	HistoryUserAccount lastaccount = getLastLoginAccount();
    	if (null != lastaccount) {
    		UserAccount account = newAccount();
    		if (loadAccountFromLocal(account, lastaccount.userId)) {
        		this.setLoginedActiveUserAccount(account);
    		}
    	}
    }
    
    public boolean loadAccountFromLocal(UserAccount account, long userid) {
    	if (0 == userid)
    		return false;
    	if (null == account)
    		return false;
    	// load account info from database
    	account.setUserId(userid);
    	if (DVStorage.loadUserProfile(account, userid)) {
        	return true;
    	}
    	return false;
    }
    
    public class HistoryUserAccount {
    	public String accountName = null;
    	public long userId = 0;
    }
    
    public HistoryUserAccount getLastLoginAccount() {
    	AppConfigManager.AppConfig config = AppDragon.mApp.getConfig();
    	if (null == config) 
    		return null;
    	if (0 == config.lastUserId) 
    		return null;
    	HistoryUserAccount account = new HistoryUserAccount();
    	account.userId = config.lastUserId; 
    	return account;
    }
    
    public int getHistoryAccountCount() {
    	return 0;
    }

    public HistoryUserAccount getHistoryAccount(int index) {
    	return null;
    }
}
