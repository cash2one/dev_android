package com.mknote.dragonvein.core;

import java.io.File;
import java.lang.reflect.Field;

import com.mknote.dragonvein.AppDragon;
import com.mknote.libs.DeviceInfo;
import com.mknote.libs.Log;
import com.mknote.net.ServerSettings;

import android.app.Application;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.text.TextUtils;

/**
 * 本地配置信息管理类，用于读取，保存全局配置到本地存储卡上
 * @author gzh
 *
 */
public class AppConfigManager  extends AbstractManager {

	public static final String APPCFG_NAME = "app";
	
	public static final String CFG_SERVER_CONTACTURL = "srv_co";
	public static final String CFG_SERVER_CONTACTTIMEOUT = "srv_tmo_co";
	public static final String CFG_SERVER_PASSPORTURL = "srv_pass";
	public static final String CFG_SERVER_PASSPORTTIMEOUT = "srv_tmo_pass";
	public static final String CFG_SERVER_IMAGEURL = "srv_img";
	public static final String CFG_SERVER_IMAGETIMEOUT = "srv_tmo_img";

	public static final String CFG_SERVER_DISPATCHURL = "srv_di";
	public static final String CFG_SERVER_DISPATCHTIMEOUT = "srv_tmo_di";

	public static final String CFG_SERVER_CONTENTURL = "srv_cn";
	public static final String CFG_SERVER_CONTENTTIMEOUT = "srv_tmo_cn";

	public static final String CFG_USER_LASTUSERID  = "usr_last_id";
	public static final String CFG_APP_UPDATE_IGNORE = "app_up_ignore";
	
	public AppConfigManager(ManagerFactory core) {
		super(core);
	}

	/**
	 * 本地初始化， 需要确保唯一执行, 在AppManager.OnAppStart中执行
	 */
	public static class AppConfig {
		
		private AppConfig() {
			serverSetting = new ServerSettings();
		}
		
		public ServerSettings serverSetting;
		public long lastUserId = 0;
		public String appUpdateIgnore = null;
		public String deviceId = "";
		public String channelId = "";
	}

	/**
	 * 全局同步保存配置信息到配置文件
	 * @param info
	 * @return
	 */
	private static SharedPreferences getPref() {
		/*/
		boolean isSaveSDCard = true;
		if (isSaveSDCard) {
			Field field;
			// 获取ContextWrapper对象中的mBase变量。该变量保存了ContextImpl对象
			try {
				field = ContextWrapper.class.getDeclaredField("mBase");
				field.setAccessible(true);
				// 获取mBase变量
				Object obj = field.get(AppDragon.mApp);
				// 获取ContextImpl。mPreferencesDir变量，该变量保存了数据文件的保存路径
				field = obj.getClass().getDeclaredField("mPreferencesDir");
				field.setAccessible(true);
				// 创建自定义路径
				//应用数据存储根目录
				String filepath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/.renmai/";
				File file = new File(filepath + "pref");			
				if (!file.exists()) {
					file.mkdirs();
				}
				// 修改mPreferencesDir变量的值
				field.set(obj, file);
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		//*/
		return AppDragon.mApp.getSharedPreferences(APPCFG_NAME, android.app.Activity.MODE_PRIVATE);
	}
	
	public static AppConfig load() {
		AppConfig config = new AppConfig();
		try {
			/*
			 * 此处为了兼容，主动向ApplicationData设置数据
			 */
			// 初始化本地服务器配置信息
			SharedPreferences pref = getPref();
			if (null != pref) {
				toServerSetting(pref, config.serverSetting);
				config.lastUserId = getLong(pref, CFG_USER_LASTUSERID,  0);
				config.appUpdateIgnore = getString(pref, CFG_APP_UPDATE_IGNORE,  "");
				config.deviceId = DeviceInfo.getIMEI();
				
				config.channelId = "";
				PackageManager packagemgr =AppDragon.mApp.getPackageManager();
				String packagename = AppDragon.mApp.getPackageName();
				ApplicationInfo appinfo = packagemgr.getApplicationInfo(packagename, PackageManager.GET_META_DATA);
				if (null != appinfo)
				    config.channelId = appinfo.metaData.getString("UMENG_CHANNEL");
			}
		} catch (Exception ex) {
		}
		return config;
	}

	public synchronized static boolean Save(AppConfig config){		
		Log.d("Save Local Config");
		SharedPreferences pref = getPref(); 
		if (null == pref)
			return false;
		
		Editor edit = pref.edit();
		if (null != edit) {
			try {
				// 初始化本地服务器配置信息
				putServerSetting(edit, config.serverSetting);
				putLong(edit, CFG_USER_LASTUSERID, config.lastUserId);
				putString(edit, CFG_APP_UPDATE_IGNORE,  config.appUpdateIgnore);
				//提交
				edit.commit();			
				Log.d("Save Local Config Success");
				return true;
			}
			catch(Exception ex) {
				Log.d("Save Local Config Error : " + ex.getMessage());
			}
			return false;
		}	
		return false;
	}
	/**
	 * 从SD配置数据中读取ServerSettings
	 * @param sd
	 * @param settings
	 */
	static void toServerSetting(SharedPreferences sd, ServerSettings settings)
	{
		if (null == sd)
			return;
		if (null == settings) 
			return;		
		settings.setContactUrl(sd.getString(CFG_SERVER_CONTACTURL, null), sd.getInt(CFG_SERVER_CONTACTTIMEOUT, 0));
		settings.setContentUrl(sd.getString(CFG_SERVER_CONTENTURL, null), sd.getInt(CFG_SERVER_CONTENTTIMEOUT, 0));
		settings.setDispatchUrl(sd.getString(CFG_SERVER_DISPATCHURL, null), sd.getInt(CFG_SERVER_DISPATCHTIMEOUT, 0));
		settings.setPassportUrl(sd.getString(CFG_SERVER_PASSPORTURL, null), sd.getInt(CFG_SERVER_PASSPORTTIMEOUT, 0));
		settings.setImageUrl(sd.getString(CFG_SERVER_IMAGEURL, null), sd.getInt(CFG_SERVER_IMAGETIMEOUT, 0));
	}
	
	static boolean putServerSetting(Editor prefedit, ServerSettings settings) {
		if (null == prefedit) 
        	return false;
        prefedit.putString(CFG_SERVER_DISPATCHURL, settings.getDispatchUrl());
       	prefedit.putInt(CFG_SERVER_DISPATCHTIMEOUT, settings.getDispatchTimeoutMS());
        prefedit.putString(CFG_SERVER_CONTENTURL, settings.getContentUrl());
       	prefedit.putInt(CFG_SERVER_CONTENTTIMEOUT, settings.getContentTimeoutMS());
        prefedit.putString(CFG_SERVER_CONTACTURL, settings.getContactUrl());
       	prefedit.putInt(CFG_SERVER_CONTACTTIMEOUT, settings.getContactTimeoutMS());
        prefedit.putString(CFG_SERVER_PASSPORTURL, settings.getPassportUrl());     			  
       	prefedit.putInt(CFG_SERVER_PASSPORTTIMEOUT, settings.getPassportTimeoutMS());
        prefedit.putString(CFG_SERVER_IMAGEURL, settings.getImageUrl());
        prefedit.putInt(CFG_SERVER_IMAGETIMEOUT, settings.getImageTimeoutMS());
        return true;
	}

	static String getString(SharedPreferences sd, String Key, String DefaultValue) {
		if(sd == null) 
			return DefaultValue;
		if(Key == null || Key.length() == 0)
			return DefaultValue;
		return sd.getString(Key, DefaultValue);
	}
	
	static int getInt(SharedPreferences sd, String Key, int DefaultValue) {
		if(sd == null) 
			return DefaultValue;
		if(Key == null || Key.length() == 0)
			return DefaultValue;
		try {
			return sd.getInt(Key, DefaultValue);
		}
		catch(Exception ex) {
			return DefaultValue;
		}
	}
	
	static long getLong(SharedPreferences sd, String Key, int DefaultValue) {
		if(sd == null) 
			return DefaultValue;
		if(Key == null || Key.length() == 0)
			return DefaultValue;
		return sd.getLong(Key, DefaultValue);
	}
	
	static boolean putString(Editor prefedit, String Key, String Value) {
		if(null == prefedit) 
			return false;
		if(Key == null || Key.length() == 0) 
			return false;		
		prefedit.putString(Key, Value);		
		return true;
	}	
	
	static boolean putInt(Editor prefedit, String Key, int Value) {
		if(null == prefedit) 
			return false;		
		if(Key == null || Key.length() == 0) 
			return false;		
		prefedit.putInt(Key, Value);		
		return true;
	}
	
	static boolean putLong(Editor prefedit, String Key, long Value) {
		if(null == prefedit) 
			return false;		
		if(Key == null || Key.length() == 0) 
			return false;		
		prefedit.putLong(Key, Value);		
		return true;
	}

}
