package com.mknote.dragonvein.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jivesoftware.smack.Chat;
import org.jivesoftware.smack.ChatManager;
import org.jivesoftware.smack.ChatManagerListener;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Message;

import android.util.Log;

import com.mknote.app.UserAccount;
import com.mknote.dragonvein.AppDragon;

public class AsmackManager {

	private static ConnectionConfiguration mConnConfig;
	private static XMPPConnection mXmppConnection;
	private static ChatManager mChatManager;
	private static Chat mChat;
	private static AsmackManager mManager;
	private static MessageHandler mHandler;
	private static boolean mIsLogin = false;
	private AsmackManager(MessageHandler handler) {
		mHandler = handler;
		login();
	}

	private void login() {
		new Thread(new Runnable() {
			public void run() {
				UserAccount account = AppDragon.core.getUserManager().ActiveUser();

				mConnConfig = new ConnectionConfiguration("10.240.56.77", 5222);
				mConnConfig.setSASLAuthenticationEnabled(false);
				mXmppConnection = new XMPPConnection(mConnConfig);
						try {
							mXmppConnection.connect();
							Log.d("chenchao", "Username =="+account.getUserId()+" Password="+account.getChatPasswd());
							mXmppConnection.login(account.getUserId()+"", account.getChatPasswd());
							// 注册消息监听
							registerMessageListener();
							mIsLogin = true;
							getOnlineUser();
							mHandler.loginSuccess();
							//AsmackUIUtils.GotoActivity(activity, SingleTalkActivity.class);
						} catch (Exception ex) {
							Log.d("chenchao","throw exception");
							ex.printStackTrace();
						}
			}
		}).start();
		
	}
	
	// 注册单人对话监听
		private void registerMessageListener() {
			mChatManager = mXmppConnection.getChatManager();
			mChatManager.addChatListener(new ChatManagerListener() {

				public void chatCreated(Chat chat, boolean arg1) {
					chat.addMessageListener(new MessageListener() {

						public void processMessage(Chat arg0, Message message) {

							String msg = message.getBody();
							Log.d("message", "receiver message="+msg+"    "+message);
							// SystemManager.ShowToast(MainActivity.this,
							// message.getBody());
							if (msg.contains("危险")) {
								/*
								 * DangerActivity.message=msg;
								 * SystemManager.StartApplacation(MainActivity.this,
								 * "com.Kim.MobileHISPkg"
								 * ,"com.Kim.MobileHISPkg.MobileHIS");
								 * SystemManager.GotoActivity(MainActivity.this,
								 * MainActivity.class);
								 */
								/*
								 * AlarmManagerM alarmManagerM=new
								 * AlarmManagerM(activity);
								 * alarmManagerM.SetRepeatAlarm
								 * (AlarmRecevicer.class,1000);
								 */
							}
							mHandler.receiveMessage(message);
						}
					});

				}
			});

		}

		// 发送1 to 1的消息
		public static void semdmessage(final String msg, final String msgto) {

			// 初始化发送消息
			mChat = mChatManager.createChat(msgto, null);
			new Thread() {
				@Override
				public void run() {
					try {
						mChat.sendMessage(msg);
						mHandler.sendMessageResult(msg);
					} catch (XMPPException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}.start();

		}

		// 获取在线好友列表
		public static List<RosterEntry> getOnlineUser() {
			Roster roster = mXmppConnection.getRoster();
			Collection<RosterEntry> usercCollection = roster.getEntries();
			List<RosterEntry> friendList = new ArrayList<RosterEntry>();
			Log.d("chenchao", "online size ="+usercCollection.size());
			// List<Object> userList=Arrays.asList(usercCollection.toArray());
			for (RosterEntry r : usercCollection) {
	            Log.d("chenchao", "r ==="+r);
	            friendList.add(r);
				/*sendhandlemsg(r.getUser(),
						r.getGroups().toString() + "" + r.getStatus(), false);*/
			}
			return friendList;
		}

	public static void init (MessageHandler handler) {
		if (mManager == null) {
			mManager = new AsmackManager(handler);
		}
	}
	public static void changeHandler(MessageHandler handler) {
		mHandler = handler;
	}
	
	public static boolean isLogin() {
		return mIsLogin;
	}
	
	public interface MessageHandler {
		public void loginSuccess();
		public void receiveMessage(Message message);
		public void sendMessageResult(String msg);
	}
}
