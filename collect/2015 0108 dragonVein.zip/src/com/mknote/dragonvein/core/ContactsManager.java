package com.mknote.dragonvein.core;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.core.*;
import com.mknote.dragonvein.data.ContactsImporter;
import com.mknote.dragonvein.data.DVStorage;
import com.mknote.dragonvein.entity.Contact;
import com.mknote.dragonvein.libs.FriendUtils;
import com.mknote.libs.Log;

public class ContactsManager extends AbstractManager {
	
	public ContactsManager(ManagerFactory core){
		super(core);
	}

	public static final String TAG = ContactsManager.class.getSimpleName();
	public void importContactsToLocal(){
		if (AppDragon.core.getUserManager().isLogined()) {
			new Thread(new ImportRunable()).start();
		}
	}
	
	private class ImportRunable implements Runnable{

		@Override
		public void run() {
			// TODO Auto-generated method stub
			ContactsImporter ci = new ContactsImporter();
			if(DVStorage.getContactCount() == 0){
				ci.importContactsFromSystemContacts(1, 100);
				if (ci.mIsChanged) {
					sendDataChangedBroadcast();
				}
			}
			
			ci.importContactsFromSystemContacts(1, 0);
			if (ci.mIsChanged) {
				sendDataChangedBroadcast();
			}
			Intent intent = new Intent(GlobleConsts.BROADCAST_IMPORT_FINISH);
			AppDragon.mApp.sendBroadcast(intent);
		}
		
	}

	public void getFriendsFromServer() {
        (new Thread(){
			@Override  
			public void run(){
				FriendUtils utils = new FriendUtils();
				utils.getFriendsFromServer();
				utils = null;
			}
        }).start();
	}
	
	public void uploadContacts() {
        (new Thread(){
			@Override  
			public void run(){
				List<Contact> contacts = getAllContact();
				if (null != contacts) {
					FriendUtils utils = new FriendUtils();
					utils.uploadContacts(contacts);
					utils = null;
				}
			}
        }).start();
	}
	
	public void sendDataChangedBroadcast() {
		Intent intent = new Intent(GlobleConsts.ACTION_CONTACTS_DATA_CHANGED);
		Log.i(TAG, "sendDataChangedBroadcast - ACTION_CONTACTS_DATA_CHANGED");
		AppDragon.mApp.sendBroadcast(intent);
	}

	public List<Contact> getAllFriend() {
		List<Contact> friendsList = new ArrayList<Contact>();
		DVStorage.fillFriendsList(friendsList);
		return friendsList;
	}
	
	public List<Contact> getAllContact() {
		List<Contact> contactsList = new ArrayList<Contact>();
		DVStorage.fillContactsList(contactsList);
		return contactsList;
	}
	
	public int getContactCount(){
		return DVStorage.getContactCount();
	}
}
