package com.mknote.dragonvein.core;


public class ManagerFactory {
	
	private ManagerFactory(){
	}
	
	/**
	 * 此函数，只能用于容器调用， 比如一个线程中保持单例使用，避免重复初始化各种不同的manager
	 * 默认情况下，统一使用AppDragon.Core来获取全局单例ManagerFactory
	 * @return
	 */
	public static ManagerFactory getManagerFactory() {
		return new ManagerFactory();
	}

	private ContactsManager contactManager;

	public ContactsManager getContactManager() {
		if (null == contactManager){
			contactManager = new ContactsManager(this);
		}
		return contactManager;
	}
	

	private AppUserManager userManager;
	public AppUserManager getUserManager() {
		if (null == userManager){
			userManager = new AppUserManager(this);
		}
		return userManager;
	}
	
	private AppConfigManager cfgManager = null;
	public AppConfigManager getConfigManager() {
		if (null == cfgManager){
			cfgManager = new AppConfigManager(this);
		}
		return cfgManager;
	}	

	private NetManager netManager = null;
	public NetManager getNet() {
		if (null == netManager){
			netManager = new NetManager(this);
		}
		return netManager;
	}	
}
