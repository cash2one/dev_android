package com.mknote.dragonvein;

import android.content.Intent;
import android.text.TextUtils;

import com.mknote.app.AppVersion;
import com.mknote.dragonvein.core.AppConfigManager;
import com.mknote.dragonvein.core.ContactsManager;
import com.mknote.dragonvein.core.ManagerFactory;
public class AppDragon extends android.app.Application {
//public class AppDragon extends BaseApp {
	
	public static AppDragon mApp = null;
	public static ManagerFactory core = null;
	
	@Override
	public void onCreate() {
		super.onCreate();
		mApp = this;
		core = ManagerFactory.getManagerFactory();
	}
	
	public static String getProductID() {
		return "101";
	}
	
	private static AppConfigManager.AppConfig mConfig = null;
	
	private static String mAppVersion = null;
	public static String getVersion() {
		if (TextUtils.isEmpty(mAppVersion)){
			AppVersion ver = new AppVersion();
			mAppVersion = ver.getVersionName();
			ver = null;
		}
		return mAppVersion;
	}
	
	public AppConfigManager.AppConfig getConfig() {
		if (null == mConfig) 
			mConfig = AppConfigManager.load();
		return mConfig;
	}
	public void sendBroadcast(String MsgID, android.os.Bundle extras){
		if (TextUtils.isEmpty(MsgID))
			return;
		Intent intent = new Intent(MsgID);
		if(extras!=null)
			intent.putExtras(extras);
		mApp.sendBroadcast(intent);
	}	

	public void sendBroadcast(String MsgID, String extraName, String extraData){
		if (TextUtils.isEmpty(MsgID))
			return;
		Intent intent = new Intent(MsgID);
		if  (!TextUtils.isEmpty(extraName)) {
			intent.putExtra(extraName, extraData);
		}
		mApp.sendBroadcast(intent);
	}	
}
