package com.mknote.dragonvein.data;

public class DBConsts {

	public static final String DB_NAME = "dragon_vein";
	public static final int DB_VERSION = 1;
	
	public static final class Columns_Contact {
		public static final String  TABLE_NAME = "t_contacts_sync"; 
		public static final String  LOCAL_CONTACTID = "local_contactid"; // INTEGER PRIMARY KEY AUTOINCREMENT,                                       
		public static final String  LOCAL_OWNERID  = "owner_id"; // INTEGER NOT NULL DEFAULT 0,
		// 存放 mobileid
		public static final String  CONTACT_ID = "contact_id"; //  VARCHAR(256) NOT NULL,
		
		public static final String  CONTACTTYPE  = "contacttype"; // INTEGER NOT NULL DEFAULT 0,      // 联系人类型 --> ???                                 
		// 联系人状态 0 无效 1 有效
		public static final String  STATUS  = "status"; // TEXT NOT NULL DEFAULT 1,           
		public static final String  CREATETIME  = "createtime"; // DATETIME NOT NULL,                // 新建时间
		public static final String  UPDATETIME  = "updatetime"; // DATETIME NOT NULL,              // 更新时间戳
		public static final String  SORT_KEY  = "sort_key"; // TEXT NOT NULL DEFAULT "",           // 用于显示排序的键
		public static final String  SEX = "sex"; //  TEXT NOT NULL DEFAULT "",                // 性别
		public static final String  BIRTHDAY  = "birthday"; // TEXT NOT NULL DEFAULT "",           // 生日
		public static final String  MEMORYDAY  = "memoryday"; // TEXT NOT NULL DEFAULT "",          // 纪念日
		public static final String  LOCAL_AVATAR_ID  = "local_photo_id"; // INTEGER NOT NULL DEFAULT 0,   // 头像
		public static final String  IMPORTANT  = "important"; //TEXT NOT NULL DEFAULT "",          // 重要程度
		// 名称相关
		public static final String  DISPLAY_NAME = "display_name"; //  TEXT NOT NULL,                  // 显示名字
		public static final String  ENGLISH_NAME  = "english_name"; // TEXT NOT NULL DEFAULT "",       // 英文名
		public static final String  NICKNAME  = "nickname"; // TEXT NOT NULL DEFAULT "",           // 昵称
		public static final String  FAMILYNAME  = "familyname"; // 姓
		public static final String  GIVENNAME  = "givenname"; // 名
		// 联系方式相关
		public static final String  SCHOOL  = "school"; // TEXT NOT NULL DEFAULT "",             // 学校
		public static final String  COMPANY = "company"; //  TEXT NOT NULL DEFAULT "",            // 工作单位
		public static final String  JOBTITLE  = "jobtitle"; // TEXT NOT NULL DEFAULT "",           // 职务
		// 这个信息 由用户自己填
		//public static final String  SKILL  = "skill"; // TEXT NOT NULL DEFAULT "",              // 技能
		public static final String  PHONENUM = "phonenum"; //  VARCHAR(100) NOT NULL DEFAULT "",       // 联系号码 1
		public static final String  PHONENUMEX  = "phonenumex"; // TEXT NOT NULL DEFAULT "",              // 联系号码扩展
		public static final String  PLACE  = "place"; // VARCHAR(200) NOT NULL DEFAULT "",      // 地区
		public static final String  BLOODTYPE  = "bloodtype"; // VARCHAR(200) NOT NULL DEFAULT "",  // 血型
		public static final String  WORKADDRESS  = "workaddress"; // VARCHAR(200) NOT NULL DEFAULT "",// 工作地址
		public static final String  HOMEADDRESS  = "homeaddress"; // VARCHAR(200) NOT NULL DEFAULT "",// 家庭地址
		public static final String  EMAIL  = "email"; // VARCHAR(100) NOT NULL DEFAULT "",      // 邮箱
		public static final String  QQ   = "qq"; // VARCHAR(100) NOT NULL DEFAULT "",        // 联系QQ 1
		public static final String  WEIXIN   = "weixin"; // VARCHAR(100) NOT NULL DEFAULT "",    // 联系微信 1
		public static final String  WEIBO  = "weibo"; // VARCHAR(100) NOT NULL DEFAULT "",      // 新浪微博
		public static final String  SKYPE  = "skype"; // VARCHAR(100) NOT NULL DEFAULT "",      // Skype
		// 信息发布
		public static final String  BLOG  = "blog"; // VARCHAR(100) NOT NULL DEFAULT "",       // 博客
		public static final String  HOMEPAGE  = "homepage"; // VARCHAR(100) NOT NULL DEFAULT "",   // 主页
		public static final String  BRIEF  = "brief"; // VARCHAR(100) NOT NULL DEFAULT "",      // 备注
		public static final String  GROUPS  = "groups"; // VARCHAR(100) NOT NULL DEFAULT "",     // 群组
		public static final String  RELATIONS  = "relations"; // VARCHAR(100) NOT NULL DEFAULT "",  // 关系
		public static final String  NOTIFY = "notify"; //  VARCHAR(100) NOT NULL DEFAULT "",     // 通知模式 (铃声 消息通知 振动方式)
		public static final String  DATA  = "data"; // TEXT                                    // 扩展信息
	}
	
	/**
	 * 
	 * @author chenchao
	 *一度好友表字段
	 */
	public static final class Columns_User {
		
		/**
		 * name of user table
		 */
		public static final String TABLE_NAME = "t_contacts";
		public static String _ID = "_id";
		/**
		 * 一度人脉ID 主键
		 */
		public static final String USER_ID = "user_id";
		/**
		 * 一度人脉的类型0：黑名单、1：拥有此人号码、2：号码被此人拥有、3：互相有号码
		 */
		public static final String LINK_TYPE = "link_type";
		/**
		 * 好友类型  -1：非龙脉用户、0：非好友、1：一级好友、2:二级好友
		 */
		public static final String FRIEND_TYPE = "friend_type";
		/**
		 * 好友名称
		 */
		public static final String FRIEND_NAME = "friend_name";
		/**
		 * 好友信息最后更新时间戳
		 */
		public static final String LASTTIME_STAMP = "lasttime_stamp";
		/**
		 * 好友头像id
		 */
		public static final String AVATAR_ID = "avatar_id";
		/**
		 * 本地通讯录对此人的标注姓名
		 */
		public static final String LOCAL_NAME = "local_name";
		/**
		 * 好友职位
		 */
		public static final String JOB_TITLE = "job_title";
		/**
		 * 好友手机号
		 */
		public static final String MOBILE_NUMBER = "mobile_number";
		/**
		 * QQ号
		 */
		public static final String QQ = "qq";
		/**
		 * 邮箱
		 */
		public static final String EMAIL = "email";
		/**
		 * 微信号
		 */
		public static final String WEIXIN = "weixin";
		/**
		 * 共同好友数量
		 */
		public static final String COMMON_FRIEND_COUNT = "common_friend_count";
		
		/**
		 * 按名称排序、搜索的关键字
		 */
		public static final String SORT_KEY = "sort_key";
		/**
		 * int型，0未知，1男，2女
		 */
		public static final String SEX = "sex";
		
	}
	
	/**
	 * 
	 * @author chenchao
	 *实名动态表字段
	 */
	public static final class Columns_Feed {
		/**
		 * 表名
		 */
		public static final String TABLE_NAME = "t_feeds";
		public static String _ID = "_id";
		/**
		 * 主键，动态的id
		 */
		public static String FEED_ID = "feed_id";
		/**
		 * 创建时间戳
		 */
		public static final String CREATETIME_STAMP = "Createtime_stamp";
		/**
		 * 最后更新时间戳
		 */
		public static final String UPDATETIME_STAMP = "updatetime_stamp";
		/**int型
		 * 1动态，2赞，3扩散，4贴标签，5结交，6删除
		 */
		public static final String FEED_TYPE = "feed_type";
		/**
		 * 动态发布人id
		 */
		public static final String FROM_USER_ID = "from_user_id";
		/**
		 * 动态发布人名称
		 */
		public static final String FROM_USER_NAME = "from_user_name";
		/**
		 * 动态发布人职位
		 */
		public static final String FROM_USER_TITLE = "from_user_title";
		/**
		 * 动态发布人头像id
		 */
		public static final String FROM_AVATAR_ID = "from_avatar_id";
		/**
		 * int型
		 * 1、好友，2、好友的好友
		 */
		public static final String FROM_DISTANCE = "from_distance";
		/**
		 * 赞的数量
		 */
		public static final String PRAISE_COUNT = "praise_count";
		/**
		 * int型
		 * 评论的数量
		 */
		public static final String COMMENT_COUNT = "comment_count";
		/**
		 * int型
		 * 扩散的次数
		 */
		public static final String FORWARD_COUNT = "forward_count";
		/**
		 * 发布动态的位置，如：北京
		 */
		public static final String FROM_LOCATION = "from_location";
		/**
		 * 正文类型
		 */
		public static final String CONTENT_TYPE = "content_type";
		/**
		 * 正文类容
		 */
		public static final String CONTENT = "content";
		/**
		 * int型目标类型
		 * 1、用户，2、动态
		 */
		public static final String TARGET_TYPE = "target_type";
		/**
		 * 目标id，更具target_type来决定
		 */
		public static final String TARGET_ID = "target_id";
		/**
		 * int型，包含的图片数量
		 */
		public static final String IMG_COUNT = "img_count";
		/**
		 * 图片id 列表
		 */
		public static final String IMG_ID_LIST = "img_id_list";
		/**
		 * TEXT型，赞用户 id列表，前5个
		 */
		public static final String PRAISE_ID_LIST = "praise_id_list";
		/**
		 * 评论者1的id
		 */
		public static final String C1_USER_ID = "c1_user_id";
		/**
		 * 评论者1的名称
		 */
		public static final String C1_USER_NAME = "c1_user_name";
		/**
		 * 评论者1的内容
		 */
		public static final String C1_COMMENT = "c1_comment";
		/**
		 * 评论者2的id
		 */
		public static final String C2_USER_ID = "c2_user_id";
		/**
		 * 评论者2的名称
		 */
		public static final String C2_USER_NAME = "c2_user_name";
		/**
		 * 评论者2的内容
		 */
		public static final String C2_COMMENT = "c2_comment";
		/**
		 * 评论者3的id
		 */
		public static final String C3_USER_ID = "c3_user_id";
		/**
		 * 评论者3的名称
		 */
		public static final String C3_USER_NAME = "c3_user_name";
		/**
		 * 评论者3的内容
		 */
		public static final String C3_COMMENT = "c3_comment";
		
	}
	
	/**
	 * 
	 * @author chenchao
	 *会话列表
	 */
	public static final class Columns_ChatList {
		public static final String TABLE_NAME = "t_chat_list";
		public static final String _ID = "_id";
		/**
		 * 聊天窗口id，TEXT类型，主键
		 */
		public static final String CHAT_ID = "chat_id";
		/**
		 * int型,聊天窗口类型，1单聊，2群聊
		 */
		public static final String CHAT_TYPE = "chat_type";
		/**
		 * TEXT型,会话窗口标题
		 */
		public static final String CHAT_TITLE = "chat_title";
		/**
		 * int型，会话Userid，当chat_type为1时是对方userid，为2时是群主
		 */
		public static final String CHAT_USER_ID = "chat_user_id";
		/**
		 * TEXT型，会话用户名
		 */
		public static final String CHAT_USER_NAME = "chat_user_name";
		/**
		 * TEXT型，会话用户职业
		 */
		public static final String CHAT_USER_TITLE = "chat_user_title";
		/**
		 * TEXT型，会话头像，默认为用户头型id
		 */
		public static final String CHAT_AVATAR_ID = "chat_avatar_id";
		/**
		 * TEXT型，群聊成员列表，不包含群主
		 */
		public static final String MEMBER_JSON = "member_json";
		/**
		 * int型，1消息有通知，2消息无通知
		 */
		public static final String IS_NOTIFY = "is_notify";
		/**
		 * TEXT型，最后一条消息
		 */
		public static final String LAST_MSG = "last_msg";
		/**
		 * int型，最后会话时间
		 */
		public static final String LASTTIME_STAMP = "lasttime_stamp";
	}
	
	/**
	 * 
	 * @author chenchao
	 *消息表字段,该表名称是根据会话窗口id决定
	 */
	public static final class Columns_Message {
		public static final String TABLE_NAME = "t_message_";
		public static final String _ID = "_id";
		/**
		 * int型，消息id，主键
		 */
		public static final String MSG_ID = "msg_id";
		/**
		 * int型，发送者id
		 */
		public static final String FROM_USER_ID = "from_user_id";
		/**
		 * TEXT型，发送者名称
		 */
		public static final String FROM_NAME = "from_name";
		/**
		 * TEXT型，发送者jid
		 */
		public static final String FROM_JID = "from_jid";
		/**
		 * int型，接收者id
		 */
		public static final String TO_USER_ID = "to_user_id";
		/**
		 * TEXT型，接收者名称
		 */
		public static final String TO_NAME = "to_name";
		/**
		 * TEXT型，接收者jid
		 */
		public static final String TO_JID = "to_jid";
		/**
		 * int型，1普通消息
		 */
		public static final String MSG_TYPE = "msg_type";
		/**
		 * TEXT型，消息内容类型，默认为text/plain
		 */
		public static final String MSG_CONTENT_TYPE = "msg_content_type";
		/**
		 * TEXT型，消息正文
		 */
		public static final String CONTENT = "content";
		/**
		 * int型，消息状态
		 */
		public static final String MSG_STATE = "msg_state";
		/**
		 * TEXT型，图片缩略图URL
		 */
		public static final String IMG_THUMB_URL = "img_thumb_url";
		/**
		 * TEXT型，图片缩略图本地URL
		 */
		public static final String IMG_THUMB_URL_LOCAL = "img_thumb_url_local";
		/**
		 * TEXT型，本地图片路径
		 */
		public static final String IMG_URL_LOCAL = "img_thumb_url_local";
		/**
		 * TEXT型，音频URL
		 */
		public static final String AUDIO_URL = "audio_url";
		/**
		 * TEXT型，音频本地URL
		 */
		public static final String AUDIO_URL_LOCAL = "audio_url_local";
		/**
		 * int型，创建时间戳
		 */
		public static final String CREATETIME_STAMP = "createtime_stamp";
	}
}
