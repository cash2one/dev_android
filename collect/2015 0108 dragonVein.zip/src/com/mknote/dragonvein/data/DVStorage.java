package com.mknote.dragonvein.data;

import java.util.ArrayList;
import java.util.List;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.data.DBConsts.Columns_Contact;
import com.mknote.dragonvein.entity.Contact;
import com.mknote.libs.Log;

import android.R.string;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DVStorage {

	private static DVStorage mStorage;
	private static DataHelper mHelper;
	private static final String TAG = DVStorage.class.getSimpleName();
	private DVStorage(Context context) {
		if (mHelper == null) {
			mHelper = new DataHelper(context);
		}
	}
	
	public static DVStorage getInstance() {
		if (mStorage == null) {
			mStorage = new DVStorage(AppDragon.mApp);
		}
		return mStorage;
	}
	
	public SQLiteDatabase getReadOnlyDb() {
		return mHelper.getReadOnlyDb();
	}

	public SQLiteDatabase getWriteableDb() {
		return mHelper.getWriteableDb();
	}

	/**
	 * 插入新数据到联系人数据库
	 * 
	 * @param values
	 */
	public static void insertContactsBySplit(List<ContentValues> values) {
			if (null == values)
				return;
			Log.d("chenchao" + " insertContacts begin:" + values.size());
			SQLiteDatabase db = getInstance().getWriteableDb();
			if (null != db) {
				db.beginTransaction();
				try {
					for (ContentValues value : values) {
						//String phone = value.getAsString(Contacts_Table.PHONENUM);
						//long uid = value.getAsInteger(Contacts_Table.LOCAL_OWNERID);
						//String where = Contacts_Table.PHONENUM + " like '" + phone + "' and "
						//		+ Contacts_Table.LOCAL_OWNERID + "=" + uid;
						String numberString = value.getAsString(Columns_Contact.PHONENUMEX);
						String numbers[] = numberString.split(",");
						for (String number : numbers) {
							ContentValues tempValue = new ContentValues();
							tempValue.putAll(value);
							tempValue.put(Columns_Contact.PHONENUM, number);
							tempValue.put(Columns_Contact.PHONENUMEX,"");
							String where = 
									Columns_Contact.PHONENUM + " like '" + tempValue.getAsString(Columns_Contact.PHONENUM) + "' and " +
									Columns_Contact.LOCAL_OWNERID + "=" + tempValue.getAsInteger(Columns_Contact.LOCAL_OWNERID);
							Cursor cs = db.query(Columns_Contact.TABLE_NAME, null, where, null, null, null, null);
							if (null != cs) {
								if (cs.getCount() == 0) {
									db.insert(Columns_Contact.TABLE_NAME, null, tempValue);
								}
								cs.close();
							}
						}
						
					}
					db.setTransactionSuccessful();
				} finally {
					db.endTransaction();
					db.close();
					db = null;
				}
			}
			Log.d(TAG + " insertContacts end");
		}
	
	
	public static List<String> getAllContactNumList() {
		SQLiteDatabase db = getInstance().getReadOnlyDb();
		List<String> phoneList = new ArrayList<String>();
		Cursor cs = db.query(Columns_Contact.TABLE_NAME, new String[]{Columns_Contact.PHONENUM}, null, null, null, null, Columns_Contact.SORT_KEY);
		if (null != cs && cs.getCount() > 0) {
			try {
				cs.move(-1);
				while(cs.moveToNext()){
					phoneList.add(cs.getString(0));
				}
			} catch (Exception e) {
				
			} finally {
				cs.close();
				db.close();
			}
		}
		return phoneList;
	}
	
	public static int getContactCount() {
		int count = 0;
		SQLiteDatabase db = getInstance().getReadOnlyDb();
		Cursor cs = db.query(Columns_Contact.TABLE_NAME, new String[]{Columns_Contact.PHONENUM}, null, null, null, null, Columns_Contact.SORT_KEY);
		if (cs != null) {
			try{
				count = cs.getCount();
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				cs.close();
				db.close();
			}
		}
		return count;
	}
	
	public static void fillContactsList(List<Contact> contactsList) {
		contactsList.clear();
		SQLiteDatabase db = getInstance().getReadOnlyDb();
		Cursor cs = db.query(Columns_Contact.TABLE_NAME, new String[]{Columns_Contact.DISPLAY_NAME}, null, null, null, null, Columns_Contact.SORT_KEY);
		if (cs != null) {
			try {
				cs.move(-1);
				while (cs.moveToNext()) {
					Contact c = new Contact();
					c.setName(cs.getString(0));
					contactsList.add(c);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				cs.close();
				db.close();
			}
		}
	}
	
	public static void getMessages(String chatID){
		getInstance().mHelper.createMessageTable(chatID);
	}
}
