package com.mknote.dragonvein.data;


import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.data.DBConsts.Columns_ChatList;
import com.mknote.dragonvein.data.DBConsts.Columns_Contact;
import com.mknote.dragonvein.data.DBConsts.Columns_Feed;
import com.mknote.dragonvein.data.DBConsts.Columns_Message;
import com.mknote.dragonvein.data.DBConsts.Columns_User;

import android.R.string;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DataHelper {
	private DBOpenHelper mHelper;
	
	public DataHelper(Context context) {
		mHelper = new DBOpenHelper(context);
	}
	public SQLiteDatabase getReadOnlyDb() {
		return mHelper.getReadableDatabase();
	}

	public SQLiteDatabase getWriteableDb() {
		return mHelper.getWritableDatabase();
	}
	
	public void createMessageTable(String chatID) {
		mHelper.createMessageTable(chatID);
	}
	private static class DBOpenHelper extends IDBHelper {

		public DBOpenHelper(Context context) {
			super(context, DBConsts.DB_NAME+AppDragon.core.getUserManager().ActiveUser().getUserId(),DBConsts.DB_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			 //创建通讯录sync表
			StringBuilder sql = new StringBuilder();
			addSqlCreate(sql, Columns_Contact.TABLE_NAME);
			sql.append( "(");
			addSqlKeyFieldInteger(sql, Columns_Contact.LOCAL_CONTACTID, false);
			addSqlIntField(sql, Columns_Contact.LOCAL_OWNERID, false);            
		    addSqlTextField(sql, Columns_Contact.CONTACT_ID, false);
		    addSqlTextField(sql, Columns_Contact.CONTACTTYPE, false);   // 联系人类型 --> ???                                 
		    addSqlTextField(sql, Columns_Contact.STATUS, false);   // 联系人状态 0 无效 1 有效
	   		sql.append(Columns_Contact.CREATETIME   +" " + "DATETIME NOT NULL DEFAULT '0'" + " " +",");     // 新建时间
	   		addSqlTextField(sql, Columns_Contact.UPDATETIME, false);    // 更新时间戳
	   		addSqlTextField(sql, Columns_Contact.SORT_KEY, false);     // 用于显示排序的键
	   		addSqlTextField(sql, Columns_Contact.SEX, false);              // 性别
	   		addSqlTextField(sql, Columns_Contact.BIRTHDAY, false);         // 生日
	   		addSqlTextField(sql, Columns_Contact.MEMORYDAY , false);          // 纪念日
	   		addSqlIntField(sql, Columns_Contact.LOCAL_AVATAR_ID, false);  // 头像
			addSqlTextField(sql, Columns_Contact.IMPORTANT , false);                 // 重要程度
			
			addSqlTextField(sql, Columns_Contact.DISPLAY_NAME, false);              // 显示名字
			addSqlTextField(sql, Columns_Contact.FAMILYNAME, false);  // 姓
	 		addSqlTextField(sql, Columns_Contact.GIVENNAME, false);  // 名
			addSqlTextField(sql, Columns_Contact.ENGLISH_NAME, false);     // 英文名
			addSqlTextField(sql, Columns_Contact.NICKNAME, false);          // 昵称
			
			addSqlTextField(sql, Columns_Contact.SCHOOL, false);           // 学校
			addSqlTextField(sql, Columns_Contact.COMPANY, false);           // 工作单位
			addSqlTextField(sql, Columns_Contact.JOBTITLE, false);     // 职务
			addSqlTextField(sql, Columns_Contact.PHONENUM, false);     // 联系号码 1
			addSqlTextField(sql, Columns_Contact.PHONENUMEX, false);            // 联系号码扩展
			addSqlTextField(sql, Columns_Contact.PLACE, false);    // 地区
			addSqlTextField(sql, Columns_Contact.BLOODTYPE, false); // 血型
			addSqlTextField(sql, Columns_Contact.WORKADDRESS, false);// 工作地址
			addSqlTextField(sql, Columns_Contact.HOMEADDRESS, false);// 家庭地址
			addSqlTextField(sql, Columns_Contact.EMAIL, false);     // 邮箱
			addSqlTextField(sql, Columns_Contact.QQ, false);        // 联系QQ 1
			addSqlTextField(sql, Columns_Contact.WEIXIN, false);    // 联系微信 1
			addSqlTextField(sql, Columns_Contact.WEIBO, false);     // 新浪微博
			addSqlTextField(sql, Columns_Contact.SKYPE, false);     // Skype
			addSqlTextField(sql, Columns_Contact.BLOG, false);      // 博客
			addSqlTextField(sql, Columns_Contact.HOMEPAGE, false);   // 主页
			addSqlTextField(sql, Columns_Contact.BRIEF, false);      // 备注
			addSqlTextField(sql, Columns_Contact.GROUPS, false);     // 群组
			addSqlTextField(sql, Columns_Contact.RELATIONS, false);  // 关系
			addSqlTextField(sql, Columns_Contact.NOTIFY , false);     // 通知模式 (铃声 消息通知 振动方式)
			addSqlTextField(sql, Columns_Contact.DATA, true);                                    // 扩展信息
			sql.append(")");
			db.execSQL(sql.toString());  //db.execSQL(sql_create_table_contacts);
			//创建Sync表索引
			sql.delete(0, sql.length());
			addSqlCreateIdx(db,Columns_Contact.TABLE_NAME,Columns_Contact.SORT_KEY);
			addSqlCreateIdx(db,Columns_Contact.TABLE_NAME,Columns_Contact.LOCAL_OWNERID);
			
			
			
			
			//创建user表
			sql.delete(0, sql.length());
			addSqlCreate(sql, Columns_User.TABLE_NAME);
			sql.append( "(");
			addSqlFiedByType(sql, Columns_User.AVATAR_ID, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.COMMON_FRIEND_COUNT, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_User.EMAIL, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.FRIEND_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.FRIEND_TYPE, false, DataType.INTEGER, true, "-1");
			addSqlFiedByType(sql, Columns_User.JOB_TITLE, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.LASTTIME_STAMP, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_User.LINK_TYPE, false, DataType.INTEGER, true, "1");
			addSqlFiedByType(sql, Columns_User.LOCAL_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.MOBILE_NUMBER, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.QQ, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.SEX, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_User.SORT_KEY, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_User.USER_ID, false, DataType.INTEGER, true, null, true, false);
			addSqlFiedByType(sql, Columns_User.WEIXIN, true, DataType.TEXT, true, "");
			sql.append(")");
			db.execSQL(sql.toString());
			//创建User表索引
			sql.delete(0, sql.length());
			addSqlCreateIdx(db,Columns_User.TABLE_NAME,Columns_User.SORT_KEY);
			
			
			
			
			
			//创建Feed表
			sql.delete(0, sql.length());
			addSqlCreate(sql, Columns_Feed.TABLE_NAME);
			sql.append( "(");
			addSqlFiedByType(sql, Columns_Feed.C1_COMMENT, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.C1_USER_ID, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.C1_USER_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.C2_COMMENT, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.C2_USER_ID, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.C2_USER_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.C3_COMMENT, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.C3_USER_ID, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.C3_USER_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.COMMENT_COUNT, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.CONTENT, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.CONTENT_TYPE, false, DataType.TEXT, true, "text/plain");
			addSqlFiedByType(sql, Columns_Feed.CREATETIME_STAMP, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.FEED_ID, false, DataType.INTEGER, true, null, true, false);
			addSqlFiedByType(sql, Columns_Feed.FEED_TYPE, false, DataType.INTEGER, true, "1");
			addSqlFiedByType(sql, Columns_Feed.FORWARD_COUNT, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.FROM_AVATAR_ID, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.FROM_DISTANCE, false, DataType.INTEGER, true, "1");
			addSqlFiedByType(sql, Columns_Feed.FROM_LOCATION, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.FROM_USER_ID, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.FROM_USER_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.FROM_USER_TITLE, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.IMG_COUNT, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.IMG_ID_LIST, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.PRAISE_COUNT, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Feed.PRAISE_ID_LIST, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.TARGET_ID, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Feed.TARGET_TYPE, false, DataType.INTEGER, true, "1");
			addSqlFiedByType(sql, Columns_Feed.UPDATETIME_STAMP, true, DataType.INTEGER, true, "0");
			sql.append(")");
			db.execSQL(sql.toString());
			//创建feed表索引
			sql.delete(0, sql.length());
			addSqlCreateIdx(db,Columns_Feed.TABLE_NAME,Columns_Feed.UPDATETIME_STAMP);
			
			
			
			
			//创建chatList表
			sql.delete(0, sql.length());
			addSqlCreate(sql, Columns_ChatList.TABLE_NAME);
			sql.append( "(");
			addSqlFiedByType(sql, Columns_ChatList.CHAT_AVATAR_ID, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_ChatList.CHAT_ID, false, DataType.TEXT, true, null, true, false);
			addSqlFiedByType(sql, Columns_ChatList.CHAT_TITLE, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_ChatList.CHAT_TYPE, false, DataType.INTEGER, true, "1");
			addSqlFiedByType(sql, Columns_ChatList.CHAT_USER_ID, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_ChatList.CHAT_USER_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_ChatList.CHAT_USER_TITLE, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_ChatList.IS_NOTIFY, false, DataType.INTEGER, true, "1");
			addSqlFiedByType(sql, Columns_ChatList.LAST_MSG, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_ChatList.LASTTIME_STAMP, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_ChatList.MEMBER_JSON, true, DataType.TEXT, true, "");
			sql.append(")");
			db.execSQL(sql.toString());
			//创建chatlist表索引
			sql.delete(0, sql.length());
			addSqlCreateIdx(db,Columns_ChatList.TABLE_NAME,Columns_ChatList.LASTTIME_STAMP);
			
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
		}
		
		public void createMessageTable(String chatID) {
			SQLiteDatabase db = getWritableDatabase();
			StringBuilder sql = new StringBuilder();
			addSqlCreate(sql, Columns_Message.TABLE_NAME+chatID);
			sql.append( "(");
			addSqlFiedByType(sql, Columns_Message.AUDIO_URL, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.AUDIO_URL_LOCAL, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.CONTENT, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.CREATETIME_STAMP, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Message.FROM_JID, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.FROM_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.FROM_USER_ID, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Message.IMG_THUMB_URL, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.IMG_THUMB_URL_LOCAL, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.IMG_URL_LOCAL, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.MSG_CONTENT_TYPE, false, DataType.TEXT, true, "text/plain");
			addSqlFiedByType(sql, Columns_Message.MSG_ID, false, DataType.INTEGER, true, null, true, false);
			addSqlFiedByType(sql, Columns_Message.MSG_STATE, false, DataType.INTEGER, true, "0");
			addSqlFiedByType(sql, Columns_Message.MSG_TYPE, false, DataType.INTEGER, true, "1");
			addSqlFiedByType(sql, Columns_Message.TO_JID, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.TO_NAME, false, DataType.TEXT, true, "");
			addSqlFiedByType(sql, Columns_Message.TO_USER_ID, false, DataType.INTEGER, true, "0");
			sql.append(")");
			db.execSQL(sql.toString());
			//创建chatlist表索引
			sql.delete(0, sql.length());
			addSqlCreateIdx(db,Columns_Message.TABLE_NAME+chatID,Columns_Message.CREATETIME_STAMP);
		}
		
	}
}
