package com.mknote.dragonvein.data;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;

import com.mknote.dragonvein.AppDragon;
import com.mknote.dragonvein.GlobleConsts;
import com.mknote.dragonvein.data.DBConsts.Columns_Contact;
import com.mknote.dragonvein.libs.ContactUtils;
import com.mknote.libs.Log;
import com.mknote.libs.StrUtils;

public class ContactsImporter {

	// config
	private static final String TAG = ContactsImporter.class.getSimpleName();

	private static ArrayList<Integer> mAlreadyImportRawIds = new ArrayList<Integer>();
	// private static HashMap<String,Integer> mapMIMETYPE = new
	// HashMap<String,Integer>();

	private static AtomicInteger mContactImportRunning;

	// 是否从系统通讯录中扫描到新的通讯录
	public boolean mIsChanged;
	
	private boolean mIsRunInThread = false;
	//private class RunImportContactFromSystemContact implements Runnable {
	//    @Override
	//    public void run() {
	//	    Log.d(TAG + " RunImportContact =============");
	//	    if (mIsRunInThread) {
	//		    return;
	//	    }
	//	    mIsRunInThread = true;
	//	    importContactsFromSystemContacts(0);
	//	    mIsRunInThread = false;
	//    }
	//}
	
	private void sendFinishMessage() {
		if (mIsChanged) {
			Intent intent = new Intent(GlobleConsts.ACTION_CONTACTS_DATA_CHANGED);
			AppDragon.mApp.sendBroadcast(intent);
		}
	}

	//private boolean isImportedContacts() {
	//	SharedPreferences prf = SharePreference2SDCard.getSDPreferences(GlobleConsts.COMM_SD_SHAREPREFERENCES_NAME);
	//	return prf.getBoolean("imported", false);
	//}

	//private void markLoadContactFinish() {
	//	SharedPreferences prf = SharePreference2SDCard.getSDPreferences(GlobleConsts.COMM_SD_SHAREPREFERENCES_NAME);
	//	if (prf != null) {
	//		prf.edit().putBoolean("imported", true).commit();
	//	}
	//}

	//private boolean isContactsImporting() {
	//	SharedPreferences prf = SharePreference2SDCard.getSDPreferences(GlobleConsts.COMM_SD_SHAREPREFERENCES_NAME);
	//	return prf.getBoolean("importing", false);
	//}

	//private void markContactImporting(boolean status) {
	//	SharedPreferences prf = SharePreference2SDCard.getSDPreferences(GlobleConsts.COMM_SD_SHAREPREFERENCES_NAME);
	//	if (prf != null) {
	//		prf.edit().putBoolean("importing", status).commit();
	//	}
	//}

	/**
	 * 如果excludeRawContactIdList为null则使用mAlreadyImportRawIds保存的rawContactid列表，为null检查增量
	 * 不为null则使用传入的excludeRawContactIdList，检查全量
	 * @param excludePhoneList
	 * @param importCountLimit
	 * @param excludeRawContactIdList
	 */
	public void importContactsFromSystemContacts(int local_user_id, int importCountLimit) {
		Log.d(TAG + "Import Contacts begin:" + importCountLimit);
		//// 无法保障封口，暂时忽略这个逻辑。
		// 没有设置过已导入标志，
		// 这种情况说明其他程序正在导入中，做延迟，直接取数据。
		// if ((!isImportedContacts()) && isContactsImporting()) {
		// try {
		// Thread.sleep(1000);
		// return;
		// } catch (Exception e) {
		// }
		//
		// } else
		{
			try {
				//markContactImporting(true);
				loadContacts(local_user_id, importCountLimit);
			} finally {
				//markLoadContactFinish();
				//markContactImporting(false);
			}
		}
		Log.d(TAG + "Import Contacts end");
		// sendFinishMessage();
	}

	private class ContactImportTaskData {
		private int phoneCount = 0;
		private int emailCount = 0;
		private int memoryCount = 0;
		private int groupCount = 0;
		private int relationCount = 0;
		private int qqCount = 0;
		private int skypeCount = 0;
		private StringBuilder phoneBuilder = new StringBuilder();
		private StringBuilder emailBuilder = new StringBuilder();
		private StringBuilder memoryBuilder = new StringBuilder();
		private StringBuilder qqBuilder = new StringBuilder();
		private StringBuilder skypeBuilder = new StringBuilder();
		private StringBuilder groupBuilder = new StringBuilder();
		private StringBuilder relationBuilder = new StringBuilder();
		private List<String> phones = new ArrayList<String>();
		
		private void initialVariables(){
			phoneCount = 0;
			emailCount = 0;
			memoryCount = 0;
			groupCount = 0;
			relationCount = 0;
			qqCount = 0;
			skypeCount = 0;
			phoneBuilder.delete(0, phoneBuilder.length());
			emailBuilder.delete(0, emailBuilder.length());
			memoryBuilder.delete(0, memoryBuilder.length());
			qqBuilder.delete(0, qqBuilder.length());
			skypeBuilder.delete(0, skypeBuilder.length());
			groupBuilder.delete(0, groupBuilder.length());
			relationBuilder.delete(0, relationBuilder.length());		
		}
	}
	
	private int mOnCountNotifySleep = 50;
	private int mSaveOnGetCount = 50;
	private void loadContacts(int local_user_id, int importCountLimit) {
		Log.d(TAG + " loadContacts begin" + importCountLimit);
		//UnicodePingyin py = UnicodePingyin.getInstance();

		// String limit = Data.RAW_CONTACT_ID +
		// " in (select "+Data.RAW_CONTACT_ID+" from view_data_restricted limit 100)";
		// Log.i(limit);
		StringBuilder where = new StringBuilder();
		//String idFieldName = Data.RAW_CONTACT_ID;
		Integer[] excludeRawContactIdList = new Integer[mAlreadyImportRawIds.size()];
		mAlreadyImportRawIds.toArray(excludeRawContactIdList);
		if (excludeRawContactIdList.length > 0) {
			where.append(android.provider.ContactsContract.Data.RAW_CONTACT_ID + " not in (0");
			for (int i = 0; i < excludeRawContactIdList.length; i++)
				where.append("," + excludeRawContactIdList[i]);
			where.append(")");
			Log.d(TAG + "load system contacts exclude "+ excludeRawContactIdList.length);
		}
		Cursor cursor;
		Uri uri = android.provider.ContactsContract.Data.CONTENT_URI;
		if (importCountLimit > 0) // Data.RAW_CONTACT_ID
			cursor = AppDragon.mApp.getContentResolver().query(uri, null, where.toString(), null, android.provider.ContactsContract.Data.RAW_CONTACT_ID + " limit " + importCountLimit);
		else
			cursor = AppDragon.mApp.getContentResolver().query(uri, null, where.toString(), null, android.provider.ContactsContract.Data.RAW_CONTACT_ID);
		if (null == cursor) {
			Log.d(TAG + " loadContacts get cursor null!!! __ " + importCountLimit);
			return;
		}
		Log.d(TAG + " loadContacts get cursor:" + cursor.getCount());
//		Set<String> excludePhoneList = ContactsManager.getInstance().getContactInfoByPhoneHashMap().keySet();
		ContactImportTaskData importdata = new ContactImportTaskData();
		
//		Iterator<String> ktor = excludePhoneList.iterator();
//		while (ktor.hasNext()) {
//			String p = ktor.next();
//			importdata.phones.put(p, null);
//		}
		importdata.phones = DVStorage.getAllContactNumList();
		List<ContentValues> values = new ArrayList<ContentValues>();
		ContentValues value = new ContentValues();
		String mimetype = "";
		int raw_Contact_Id = -1;
		int old_Raw_Contact_Id = -1;
		mIsChanged = false;
		try {
			importdata.initialVariables();
			//long luid = UserManager.getUserManager().getCurrentUserInfo().getLocal_UserId();
			Log.d(TAG + " loadContacts local user id:" + local_user_id);
			for(cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext()){
				try {
					raw_Contact_Id = cursor.getInt(cursor.getColumnIndex(android.provider.ContactsContract.Data.RAW_CONTACT_ID));
					if (old_Raw_Contact_Id != raw_Contact_Id) {
						if (value.size() == 0 || importdata.phoneCount == 0)
							values.remove(value);
						importdata.initialVariables();
						//达到规定数字，开始保存
						if (values.size() >= mSaveOnGetCount) {
							Log.d(TAG + " imported data save" + values.size());
							DVStorage.insertContactsBySplit(values);
							values.clear();
							mIsChanged = true;
							//如果是另起的线程，则在线程中同步，通知
							if (mIsRunInThread) {
								try {
									synchronized (this) {
										this.notifyAll();
										Thread.sleep(mOnCountNotifySleep);
									}
								} catch (InterruptedException e) {
								}
							}
						}
						value = new ContentValues();
						value.put(Columns_Contact.LOCAL_OWNERID, local_user_id);
						value.put(Columns_Contact.UPDATETIME,System.currentTimeMillis()/1000);
						values.add(value);
						mAlreadyImportRawIds.add(raw_Contact_Id);
						old_Raw_Contact_Id = raw_Contact_Id;
					}

					// 取得mimetype类型
					//mimetype = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.Data.MIMETYPE));
					//Log.d(TAG + " imported rawcontactId" + raw_Contact_Id + " mimetype" + mimetype);					
					SetContactValueByMimeType(importdata, value, cursor, 
							cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.Data.MIMETYPE)));
				} catch (Exception e) {
					Log.e(TAG, "error", e);
					// 这样做是为了某条记录失败不影响其他记录的导入。
				}
			}
			// 最后一个不路过循环开始的判断，在这里再过滤一次，去掉重复的。
			if (value.size() == 0 || importdata.phoneCount <= 0)
				values.remove(value);
			// 有数据的就插入，没有则忽略
			Log.d(TAG + " imported data:" + values.size());
			if (values.size() > 0) {
				DVStorage.insertContactsBySplit(values);
				mIsChanged = true;
			}
			values.clear();
			importdata.initialVariables();
		} finally {
			cursor.close();
			Log.i(TAG,"contact import finish");
			if (mIsRunInThread) {
				synchronized (this) {
					this.notify();
				}
			}
		}
		Log.d(TAG + " loadContacts end");
	}
	
	private boolean SetContactValueByMimeType(ContactImportTaskData importTaskData, ContentValues value,Cursor cursor,String mimetype) {
		//Log.d("" + contactId + " " + mimetype);
		// 获得通讯录中每个联系人的ID
		// 获得通讯录中联系人的名字
		if (android.provider.ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String display_name = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME));
			if (TextUtils.isEmpty(display_name)) 
				return false;
			value.put(Columns_Contact.DISPLAY_NAME, display_name);
				/////
				//value.put(Contacts_Table.SORT_KEY,cursor.getString(cursor.getColumnIndex(StructuredName.SORT_KEY_PRIMARY)).toUpperCase());
				// 自建sort key
			value.put(Columns_Contact.SORT_KEY, ContactUtils.parseSortKey(display_name));							
			return true;
		}
		// 获取电话信息
		if (android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String phoneNumber = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER));
			phoneNumber = ContactUtils.phoneNumFormat(phoneNumber);
			// 如果格式化后为空，在不合格，忽略,如果在列表里有重复，忽略
			if (TextUtils.isEmpty(phoneNumber))
				return false;
			if (!importTaskData.phones.contains(phoneNumber)) {
				importTaskData.phones.add(phoneNumber);
				importTaskData.phoneCount++;
				if (1 >= importTaskData.phoneCount) {
					importTaskData.phoneBuilder.append(phoneNumber);
				} else {
					importTaskData.phoneBuilder.append(",").append(phoneNumber);
				}
				/*if (1 >= importTaskData.phoneCount) {
					value.put(Contacts_Table.PHONENUM, phoneNumber);
					value.put(Contacts_Table.CONTACT_ID,StrUtils.MD5(phoneNumber));
					
				} else if (2 == importTaskData.phoneCount) {
					importTaskData.phoneBuilder.append(phoneNumber);
				} else {
					importTaskData.phoneBuilder.append(",").append(phoneNumber);
				}*/
				if (!TextUtils.isEmpty(importTaskData.phoneBuilder.toString())) {
					value.put(Columns_Contact.PHONENUMEX, importTaskData.phoneBuilder.toString());
				}
			}
			return true;
		}
		// }
		// 查找email地址
		if (android.provider.ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String email = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Email.DATA));
			if (TextUtils.isEmpty(email)) 
				return false;
			importTaskData.emailCount++;
			if (1 == importTaskData.emailCount) {
				importTaskData.emailBuilder.append(email);
			} else {
				importTaskData.emailBuilder.append(",").append(email);
			}
			value.put(Columns_Contact.EMAIL, importTaskData.emailBuilder.toString());
			return true;
		}
		// 查找event地址
		if (android.provider.ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出时间类型
			String event = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Event.START_DATE));
			if  (TextUtils.isEmpty(event)) 
				return false;
			int eventType = cursor.getInt(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Event.TYPE));
			if (eventType == android.provider.ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY) {
				// 生日
				value.put(Columns_Contact.BIRTHDAY, event);
			}
			if (eventType == android.provider.ContactsContract.CommonDataKinds.Event.TYPE_ANNIVERSARY) {
				// 周年纪念日
				importTaskData.memoryCount++;
				if (1 == importTaskData.memoryCount) {
					importTaskData.memoryBuilder.append(event);
				} else {
					importTaskData.memoryBuilder.append(",").append(event);
				}
				value.put(Columns_Contact.MEMORYDAY, importTaskData.memoryBuilder.toString());
			}
			return true;
		}
		// 即时消息
		if (android.provider.ContactsContract.CommonDataKinds.Im.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出即时消息类型
			String msg = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Im.DATA));
			if  (TextUtils.isEmpty(msg)) 
				return false;
			int protocal = cursor.getInt(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Im.PROTOCOL));
			if (android.provider.ContactsContract.CommonDataKinds.Im.PROTOCOL_QQ == protocal) {
				 importTaskData.qqCount++;
				if (1 == importTaskData.qqCount) {
					importTaskData.qqBuilder.append(msg);
				} else {
					importTaskData.qqBuilder.append(",").append(msg);
			    }
				value.put(Columns_Contact.QQ, importTaskData.qqBuilder.toString());
			}
            if (android.provider.ContactsContract.CommonDataKinds.Im.PROTOCOL_SKYPE == protocal) {
            	importTaskData.skypeCount++;
				if (1 == importTaskData.skypeCount) {
					importTaskData.skypeBuilder.append(msg);
				} else {
					importTaskData.skypeBuilder.append(",").append(msg);
				}
				value.put(Columns_Contact.SKYPE, importTaskData.skypeBuilder.toString());
			}
			return true;
		}
		// 获取备注信息
		if (android.provider.ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String remark = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Note.NOTE));
			if (TextUtils.isEmpty(remark)) 
				return false;
			value.put(Columns_Contact.BRIEF, remark);
			return true;
		}
		// 获取昵称信息
		if (android.provider.ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String nickName = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Nickname.NAME));
			if (TextUtils.isEmpty(nickName)) 
				return false;
			value.put(Columns_Contact.NICKNAME, nickName);
			return true;
		}
		// 获取组织信息
		if (android.provider.ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出组织类型
			if (android.provider.ContactsContract.CommonDataKinds.Organization.TYPE_CUSTOM == 
					cursor.getInt(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Organization.TYPE))) {
				// 单位
				String company = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Organization.COMPANY));
				if (!TextUtils.isEmpty(company)) {
					value.put(Columns_Contact.COMPANY, company);
				}
				String jobTitle = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Organization.TITLE));
				if (!TextUtils.isEmpty(jobTitle)) {
					value.put(Columns_Contact.JOBTITLE, jobTitle);
				}
			}
			return true;
		}
		// 获取网站信息
		if (android.provider.ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出组织类型
			if (android.provider.ContactsContract.CommonDataKinds.Website.TYPE_HOMEPAGE ==
					cursor.getInt(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Website.TYPE))) {
				// 个人主页
				String homePage = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Website.URL));
				if  (TextUtils.isEmpty(homePage)) 
					return false;
				value.put(Columns_Contact.HOMEPAGE, homePage);
			}
			return true;
		}
		// 查找通讯地址
		if (android.provider.ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出地址类型
			String street = cursor.getString(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.StructuredPostal.STREET));
			if (TextUtils.isEmpty(street)) 
				return false;
			// 单位通讯地址
			int postalType = cursor.getInt(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.StructuredPostal.TYPE));
			if  (android.provider.ContactsContract.CommonDataKinds.StructuredPostal.TYPE_WORK == postalType) {
				value.put(Columns_Contact.WORKADDRESS, street);
			}
			// 住宅通讯地址
			if (android.provider.ContactsContract.CommonDataKinds.StructuredPostal.TYPE_HOME == postalType) {
				value.put(Columns_Contact.WORKADDRESS, street);
			}
			return true;
		}

		// 群组
		if (android.provider.ContactsContract.CommonDataKinds.GroupMembership.CONTENT_ITEM_TYPE.equals(mimetype)) {
			long groupId = cursor.getLong(cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.GroupMembership.GROUP_ROW_ID));
			Cursor cs = AppDragon.mApp.getContentResolver().query(
					android.provider.ContactsContract.Groups.CONTENT_URI, 
					new String[] { "title" },
					"_id = ?", 
					new String[] { "" + groupId }, 
					null);
		    if (null != cs) {
		    	try {
					cs.moveToFirst();
					String title = cs.getString(cs.getColumnIndex("title"));
					if (!TextUtils.isEmpty(title)) {
						importTaskData.groupCount++;
						if (importTaskData.groupCount == 1) {
							importTaskData.groupBuilder.append(title);
						} else {
							importTaskData.groupBuilder.append(",").append(title);
						}
						value.put(Columns_Contact.GROUPS, importTaskData.groupBuilder.toString());
						// jsonObject.put("group",
						// c.getString(c.getColumnIndex("title")));
					}
		    	} catch (Exception e) {
		    		
		    	} finally {
					cs.close();
					cs = null;
		    	}
		    }
			return true;
		}
		// 关系
		if (android.provider.ContactsContract.CommonDataKinds.Relation.CONTENT_ITEM_TYPE.equals(mimetype)) {
			int relationType = cursor.getInt(cursor.getColumnIndex("data2"));
			String relation = null;
			importTaskData.relationCount++;
			if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_ASSISTANT == relationType) {
				relation = "助手";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_BROTHER == relationType) {
				relation = "兄弟";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_CHILD == relationType) {
				relation = "子女";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_DOMESTIC_PARTNER == relationType) {
				relation = "同居伴侣";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_FATHER == relationType) {
				relation = "父亲";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_FRIEND == relationType) {
				relation = "朋友";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_MANAGER == relationType) {
				relation = "经理";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_MOTHER == relationType) {
				relation = "母亲";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_PARENT == relationType) {
				relation = "父母";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_PARTNER == relationType) {
				relation = "合作伙伴";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_REFERRED_BY == relationType) {
				relation = "介绍人";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_RELATIVE == relationType) {
				relation = "亲戚";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_SISTER == relationType) {
				relation = "姐妹";
			} else if (android.provider.ContactsContract.CommonDataKinds.Relation.TYPE_SPOUSE == relationType) {
				relation = "配偶";
			}
			if (1 == importTaskData.relationCount) {
				importTaskData.relationBuilder.append(relation);
			} else {
				importTaskData.relationBuilder.append(",").append(relation);
			}
			value.put(Columns_Contact.RELATIONS, relation);
			return true;
		}
		return false;
	}
}
