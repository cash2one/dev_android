package com.mknote.dragonvein.data;

import java.util.concurrent.atomic.AtomicInteger;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
/**
 * 
 *所有SQLiteOpenHelper的基类，将数据库db创建在SD卡上
 */
public class IDBHelper extends SQLiteOpenHelper{
	
	public IDBHelper(Context context, String dbName, int version) {
		super(context, dbName, null, version);
	}

	protected void addSqlCreate(StringBuilder sql, String tableName){
		if (sql.length() > 0){
			sql.delete(0, sql.length());
		}
		sql.append("CREATE TABLE IF NOT EXISTS"  + " "+ tableName);
	}

	protected void addSqlCreateIdx(StringBuilder sql){
		if (sql.length() > 0){
			sql.delete(0, sql.length());
		};
		sql.append(" CREATE INDEX IF NOT EXISTS ");
	}
	
	protected void addSqlCreateIdx(SQLiteDatabase db, String table, String field){
		StringBuilder sql = new StringBuilder();
		sql.append(" CREATE INDEX IF NOT EXISTS ");
		sql.append(" Idx_" + table  + "_" + field.replace(',', '_')); 
		sql.append(" ON "  + table); 
		sql.append(" (" + field + ")");
		db.execSQL(sql.toString()); 
	}
	
	protected void addSqlKeyFieldInteger(StringBuilder sql, String fieldName, Boolean isLastField) {
	   sql.append(fieldName  + " " +  "INTEGER PRIMARY KEY AUTOINCREMENT");
		if (!isLastField) {
			sql.append(",");	
		}		
	}
	
	protected void addSqlPrimaryKey(StringBuilder sql, String fieldName, boolean isLastField) {
		sql.append(fieldName + " INTEGER PRIMARY KEY NOT NULL");
		if (!isLastField) {
			sql.append(",");
		}
	}
	
	protected void addSqlTextField(StringBuilder sql, String fieldName, Boolean isLastField){
		//addSqlTextField(sqlBuilder, User_Table.UPDATETIME);
		sql.append(fieldName  + " " + "TEXT NOT NULL DEFAULT ''");
		if (!isLastField) {
			sql.append(",");	
		}		
	}

	protected String alterAddIntField(String table, String field){
		return "ALTER TABLE " + table + " ADD "+ field +" INTEGER NOT NULL DEFAULT '0'";
	}
	
	protected String alterAddStrField(String table, String field){
		return "ALTER TABLE " + table + " ADD "+ field +" TEXT NOT NULL DEFAULT ''";
	}
			
	protected void addSqlIntField(StringBuilder sql, String fieldName, Boolean isLastField){
		//addSqlTextField(sqlBuilder, User_Table.UPDATETIME);
		sql.append(fieldName  + " " + "INTEGER NOT NULL DEFAULT '0'");
		if (!isLastField) {
			sql.append(",");	
		}		
	}

	protected void addSqlBLOBField(StringBuilder sql, String fieldName, Boolean isLastField){
		//addSqlTextField(sqlBuilder, User_Table.UPDATETIME);
		sql.append(fieldName  + " " + "BLOB");
		if (!isLastField) {
			sql.append(",");	
		}		
	}

	protected void addSqlFiedByType(StringBuilder sql, String fieldName, boolean isLastFied, DataType dataType, boolean isPrimaryKey){
		addSqlFiedByType(sql, fieldName, isLastFied, dataType, false, null, isPrimaryKey, false);
	}

	protected void addSqlFiedByType(StringBuilder sql, String fieldName, boolean isLastFied, DataType dataType) {
		addSqlFiedByType(sql, fieldName, isLastFied, dataType, false, null, false, false);
	}
	
	protected void addSqlFiedByType(StringBuilder sql, String fieldName, boolean isLastFied, DataType dataType, boolean notNull, String defaultValue){
		addSqlFiedByType(sql, fieldName, isLastFied, dataType, notNull, defaultValue, false, false);
	}
	
	/**
	 * 
	 * @param sql sql语句
	 * @param fieldName 字段名称
	 * @param isLastFied 是否是最后一个字段
	 * @param dataType 字段数据类型
	 * @param notNull 是否不为空
	 * @param defaultValue 默认值
	 * @param isPrimaryKey 是否是主键
	 * @param isAuto 是否是自增长
	 */
	protected void addSqlFiedByType(StringBuilder sql, String fieldName, boolean isLastFied, DataType dataType, boolean notNull, String defaultValue, boolean isPrimaryKey, boolean isAuto){
		String type = null;
		switch (dataType) {
		case INTEGER:
			type = "INTEGER";
			break;
		
		case TEXT:
			type = "TEXT";
			break;
			
		case BLOB:
			type = "BLOB";
			break;

		default:
			break;
		}
		
		sql.append(fieldName+" "+type);
		if (isPrimaryKey) {
			sql.append(" "+"PRIMARY KEY");
		}
		
		if (notNull) {
			sql.append(" "+"NOT NULL");
		}
		
		if (null != defaultValue) {
			sql.append(" "+"DEFAULT "+"'"+defaultValue+"'");
		}
		
		if (isAuto) {
			sql.append(" AUTOINCREMENT");
		}
		
		if (!isLastFied) {
			sql.append(",");
		}
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}
	
	public enum DataType{INTEGER, TEXT , BLOB}
}
