package com.mknote.dragonvein;


import com.mknote.dragonvein.service.CommService;
import com.mknote.dragonvein.service.MessageListenerService;
import com.mknote.libs.Log;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class CommBroadcastReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
		if (needStartSevice(intent.getAction()) && (AppDragon.core.getUserManager().isLogined())) {
			Intent i = new Intent();
			i.setClass(context, CommService.class);
			Log.d("chenchao", "CommService start");
			context.startService(i);
			i.setClass(context, MessageListenerService.class);
			Log.d("chenchao","message service start");
			context.startService(i);
			return;
		}
		if (GlobleConsts.BROADCAST_IMPORT_FINISH.equals(intent.getAction())) {
			Intent i = new Intent();
			i.setClass(context, CommService.class);
			i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.stopService(i);
		}
	}

	private boolean needStartSevice (String action) {
		if (GlobleConsts.BROADCAST_USER_LOGIN.equals(action)) {
			return true;
		}
		
		if (GlobleConsts.BROADCAST_USER_ENTER.equals(action)) {
			return true;
		}
		return false;
	}
}
