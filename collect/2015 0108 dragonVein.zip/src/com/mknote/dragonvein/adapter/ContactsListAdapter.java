package com.mknote.dragonvein.adapter;

import java.util.List;

import com.mknote.dragonvein.R;
import com.mknote.dragonvein.entity.Contact;
import com.mknote.libs.ChaoticUtil;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ContactsListAdapter extends BaseAdapter{

	private Context mContext;
	private List<Contact> mItems;
	public ContactsListAdapter (Context context, List<Contact> items) {
		mContext = context;
		mItems = items;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		Contact contact = mItems.get(position);
		ContactViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.common_card_view, null);
			holder = new ContactViewHolder();
			holder.avatarLayout = (ImageView) convertView.findViewById(R.id.common_card_avatar);
			holder.topTextView = (TextView) convertView.findViewById(R.id.common_card_top_txt);
			holder.middleTextView = (TextView) convertView.findViewById(R.id.common_card_middle_txt);
			holder.bottomTextView = (TextView) convertView.findViewById(R.id.common_card_bottom_txt);
			convertView.setTag(holder);
		} else {
			holder = (ContactViewHolder) convertView.getTag();
		}
		ChaoticUtil.setTextAvatar(holder.avatarLayout, contact.getName());
		holder.topTextView.setText(contact.getName());
		holder.middleTextView.setText("职业信息未填写");
		holder.bottomTextView.setText("初识好友LV1");
		
		return convertView;
	}

}
