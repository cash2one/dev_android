package com.mknote.dragonvein.adapter;

import java.util.ArrayList;

import com.mknote.dragonvein.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class CustomList {

	public CustomList(Context context) {
		mContext = context;
		mInflater = LayoutInflater.from(mContext);
	}
	
	private Context mContext;
	private LayoutInflater mInflater;
	private CustomListView mListView = null;
	private ArrayList<CustomListItem> mListItems = null; 
	private CustomListAdapter mAdapter = null;
	
	private class CustomListView extends ListView {

		public CustomListView(Context context) {
			super(context);
		}		
	}
	
	public ListView getListView() {
		if (null == mListView) {
			mListView = new CustomListView(mContext);
			mListView.setDividerHeight(0);
			//mListView.setDivider(divider);
			mAdapter = new CustomListAdapter();
			mListView.setAdapter(mAdapter);
		}
		return mListView;
	}

	public void clear() {
		mInflater = null;
		mContext = null;
		mListView = null;
		mAdapter = null;
		if (null != mListItems) {
			mListItems.clear();
			mListItems = null;
		}
	} 
	
	public class CustomListItem {
		public String title;
		public int resId;
		public int height;
		public long itemId ;
		public int itemType;
	}

	public CustomListItem newListItem() {
		CustomListItem result = new CustomListItem();
		getListItems().add(result);
		return result;
	}

	public CustomListItem addFunctionItem(String title, int resId, int itemType, long itemId) {
		CustomListItem result = new CustomListItem();
		getListItems().add(result);
		result.resId = resId;
		result.title = title;
		result.itemType = itemType;
		result.itemId = itemId;
		return result;
	}
	
	private class CustomListItemViewHolder {
		 TextView titleView;
	}
	
	public ArrayList<CustomListItem> getListItems() {
		if (null ==mListItems) {
			mListItems = new ArrayList<CustomListItem>();
		}
		return mListItems;
	}
	
	public class CustomListAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return getListItems().size();
		}

		@Override
		public Object getItem(int position) {
			return getListItems().get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			CustomListItemViewHolder holder;
            CustomListItem item = mListItems.get(position);  
            if (convertView == null) {  
                holder = new CustomListItemViewHolder();
                if (0 == item.resId) { 
                    convertView = mInflater.inflate(R.layout.listview_item2, null);  
                } else {
                    convertView = mInflater.inflate(item.resId, null);  
                }
                holder.titleView = (TextView) convertView.findViewById(R.id.item_title);
                //} 
                AbsListView.LayoutParams lp;
                if (0 < item.height) {
                    lp = new AbsListView.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, item.height);
                } else {
                    lp = new AbsListView.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 70);
                }
                convertView.setLayoutParams(lp);
                convertView.setTag(holder);  
            } else {  
                holder = (CustomListItemViewHolder)convertView.getTag();  
            }
            if (null != holder.titleView)
                holder.titleView.setText(item.title);  
            return convertView;  
		}	
	}
}
