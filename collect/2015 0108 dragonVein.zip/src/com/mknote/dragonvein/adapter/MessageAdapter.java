package com.mknote.dragonvein.adapter;

import java.util.List;

import com.mknote.dragonvein.R;
import com.mknote.dragonvein.asmack.AsmackMessage;
import com.mknote.libs.Log;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MessageAdapter extends BaseAdapter{

	private LayoutInflater mInflater;
	private List<AsmackMessage> messageList;
	private Activity activity;
	
	private class ViewHolder
	{
		public TextView nameTextView;
		public TextView messageTextView;
	}
	
	
	public MessageAdapter(List<AsmackMessage> messageList,Activity activity)
	{
		this.messageList=messageList;
		this.activity=activity;
		this.mInflater=LayoutInflater.from(activity);
	}
	
	
	public int getCount() {
		return messageList.size();
	}

	public Object getItem(int position) {
		return messageList.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		AsmackMessage message=messageList.get(position);
		ViewHolder viewHolder=new ViewHolder();
		
		if(message.issend)
		{
			convertView = mInflater.inflate(R.layout.sendview,null);
			viewHolder.nameTextView=(TextView)convertView.findViewById(R.id.send_name);
			viewHolder.messageTextView=(TextView)convertView.findViewById(R.id.send_msg);
		}
		
		else 
		{
			convertView = mInflater.inflate(R.layout.reciveview,null);
			viewHolder.nameTextView=(TextView)convertView.findViewById(R.id.recive_name);
			viewHolder.messageTextView=(TextView)convertView.findViewById(R.id.recive_msg);
		}
		
		viewHolder.nameTextView.setText(message.ower);
		Log.d("message", "body==="+message.body);
		viewHolder.messageTextView.setText(message.body);
		
		convertView.setTag(viewHolder);
		return convertView;
	}

}
