package com.mknote.dragonvein.adapter;

import android.widget.TextView;

public class ChatViewHolder {
	public TextView userNanmeTextView;
}
