package com.mknote.dragonvein.adapter;

import java.util.List;
import java.util.Map;

import com.mknote.dragonvein.R;
import com.mknote.dragonvein.activity.RoomChatActivity;
import com.mknote.dragonvein.asmack.AsmackConnectManager;
import com.mknote.dragonvein.asmack.AsmackUIUtils;


import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

public class RoomListAdapter extends BaseExpandableListAdapter{
	
	List<Map<String, String>> groups;
	List<List<Map<String, String>>> childs;
	private LayoutInflater GroupInflater;
	private LayoutInflater ChildInflater;
	private ExpandableListView orderListView;
	private Handler handler;
	private Activity activity;
	
	
	
	public  RoomListAdapter(List<Map<String, String>> groups,
			List<List<Map<String, String>>> childs,Activity activity) {
		this.groups=groups;
		this.childs=childs;
		this.activity=activity;
		
		GroupInflater = (LayoutInflater)activity   
	               .getSystemService(Context.LAYOUT_INFLATER_SERVICE);   
		ChildInflater = (LayoutInflater)activity  
	               .getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
	}
	
	public Object getChild(int groupPosition, int childPosition) {
		String childeString=
				childs.get(groupPosition).get(childPosition).get("child");
		return childeString;
	}

	public long getChildId(int groupPosition, int childPosition) {
		return groupPosition*10+childPosition;
	}

	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		
		convertView =GroupInflater.inflate(   
				 R.layout.sendview, null); 
		
		final String value=childs.get(groupPosition).get(childPosition).get("child");
		final String jid=
				childs.get(groupPosition).get(childPosition).get("childid");
		TextView groupView=(TextView)convertView.findViewById(R.id.send_msg);
		groupView.setText(value);
		convertView.setTag(groupView);
		
		//二级目录点击
		convertView.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				AsmackConnectManager.JoinRoom(jid);
				RoomChatActivity.roomname=value;
				RoomChatActivity.roomid=jid;
				AsmackUIUtils.GotoActivity(activity, RoomChatActivity.class);
			}
		});
		
		return convertView;
	}

	public int getChildrenCount(int groupPosition) {
		return childs.get(groupPosition).size();
	}

	public Object getGroup(int groupPosition) {
		String groupString=groups.get(getGroupCount()).get("group");
		return groupString;
	}

	public int getGroupCount() {
		return groups.size();
	}

	public long getGroupId(int groupPosition) {
		return groupPosition;
	}
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		
		
		convertView =GroupInflater.inflate(   
				 R.layout.reciveview, null); 
		
		String value=groups.get(groupPosition).get("group");
		TextView groupView=(TextView)convertView.findViewById(R.id.recive_msg);
		groupView.setText(value);
		convertView.setTag(groupView);
		return convertView;
	}

	public boolean hasStableIds() {
		
		return false;
	}

	public boolean isChildSelectable(int groupPosition, int childPosition) {
		
		return true;
	}

}
