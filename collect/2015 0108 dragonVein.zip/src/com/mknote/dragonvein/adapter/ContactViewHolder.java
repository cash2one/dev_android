package com.mknote.dragonvein.adapter;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ContactViewHolder {

	public ImageView avatarLayout;
    public TextView topTextView, middleTextView, bottomTextView;
    public ImageView relationImageView;
}
