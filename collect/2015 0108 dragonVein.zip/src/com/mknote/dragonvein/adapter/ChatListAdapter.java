package com.mknote.dragonvein.adapter;

import java.util.ArrayList;
import java.util.List;

import org.jivesoftware.smack.RosterEntry;

import com.mknote.dragonvein.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ChatListAdapter extends BaseAdapter{

	private List<RosterEntry> mChatList = new ArrayList<RosterEntry>();
	private Context mContext;
	public ChatListAdapter (Context context) {
		mContext = context;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mChatList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mChatList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	public void updateAdapter (List<RosterEntry> chatList) {
		setChatList(chatList);
		notifyDataSetChanged();
	}
	
	public void setChatList(List<RosterEntry> chatList) {
		mChatList = chatList;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ChatViewHolder holder;
		RosterEntry rsEntry = mChatList.get(position);
		if(null == convertView) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.item_chat_view, null);
			holder = new ChatViewHolder();
			holder.userNanmeTextView = (TextView) convertView.findViewById(R.id.chat_name);
			convertView.setTag(holder);
		} else {
			holder = (ChatViewHolder) convertView.getTag();
		}
		holder.userNanmeTextView.setText(rsEntry.getUser());
		return convertView;
	}

}
