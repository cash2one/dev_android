package com.mknote.dragonvein;

public class GlobleConsts {

	public static final String ACTION_CONTACTS_DATA_CHANGED = "com.mkyuan.action.contacts.data.changed";//联系人表发生变化时发出的广播
	
	public static final String BROADCAST_APP_UPDATE_PREPARED = "com.app.update.prepared"; // 更新下载完成 等待安装
	public static final String BROADCAST_USER_LOGIN = "com.user.logined"; 
	public static final String BROADCAST_USER_LOGOUT = "com.user.logout";
	// 用户进入主界面  用户可能不经过 登录直接进入
	public static final String BROADCAST_USER_ENTER = "com.user.enter";
	public static final String BROADCAST_IMPORT_FINISH = "com.mknote.dragonvein.import_finish_action";

	public static final int ACTIVITYREQUEST_TAKE_ALBUM = 101;
	public static final int ACTIVITYREQUEST_TAKE_PHOTOGRAPH = 102;
	public static final int ACTIVITYREQUEST_TAKE_ZOOM= 103;
	
	public static final int ACTIVITYREQUEST_DIALOG_OKCANCEL= 201;
	public static final int ACTIVITYREQUEST_DIALOG_APPUPDATE= 202;
	public static final int ACTIVITYREQUEST_DIALOG_SELECT_PICSOURCE= 203;
	

	public static final int MSG_TOAST = 1101;	
	public static final int MSG_ACTIVITY_CLOSE = 1501;
}
