package com.mknote.dragonvein.asmack;

import java.lang.reflect.Field;

import com.mknote.dragonvein.ToastEx;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;




public class AsmackUIUtils {

	private static ProgressDialog mpDialog = null;
	
	public  static void ShowToast(Context context, String StringMessage) {
		 
		ToastEx.showMessage(context, StringMessage);
	}
	
	//是对话框不关闭
	public static void NotcloseDialog(DialogInterface dialog)
	{
		try
		{
		    Field field = dialog.getClass().getSuperclass().getDeclaredField("mShowing");
		    field.setAccessible(true);
		     //设置mShowing值，欺骗android系统
		    field.set(dialog, false);
		}catch(Exception e) {
		   
		}
	}
	
	//调用完不关闭后，必须调用次函数来关闭
	public static void CloseDialog(DialogInterface dialog)
	{
		try
		{
		    Field field = dialog.getClass().getSuperclass().getDeclaredField("mShowing");
		    field.setAccessible(true);
		     //设置mShowing值，欺骗android系统
		    field.set(dialog, true);
		} catch(Exception e) {
		    
		}
	}
	
	
	
	// 显示等待窗体
	public static void ShowWaittingDialog(Context context, String StringMessage) {
		mpDialog = new ProgressDialog(context);
		mpDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		mpDialog.setTitle("提示");
		mpDialog.setMessage(StringMessage);
		mpDialog.setIndeterminate(false);
		mpDialog.setCancelable(true);
		mpDialog.setButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				cancelWaittingDialog();
			}
		});
		mpDialog.show();

	}
	
	public static void ShowDangerDialog(final Activity activity,String message)
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(activity);
		builder.setTitle("提示");
		builder.setMessage("message");
		builder.setPositiveButton("确定",
				new DialogInterface.OnClickListener() {

					public void onClick(DialogInterface dialog, int which) {
						activity.finish();
					}
				});
		
		builder.show();
	}
	
	public static void cancelWaittingDialog(){
		if (mpDialog !=null){
			mpDialog.cancel();	
			
		}
		
	}   
	
	
	
	
	 public static void GotoActivity(Activity activity,Class<?> cls)
	 {
		 Intent intent=new Intent();
		 intent.setClass(activity.getApplicationContext(), cls);
		 activity.startActivity(intent);
	 }
	 
	 
	 public static void ResumeActivity(Activity activity,Class<?> cls)
	 {
		 Intent intent=new Intent();
		 intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
		 intent.setClass(activity.getApplicationContext(), cls);
		 activity.startActivity(intent);
	 }
	
	 
	 public static void GotoActivity(Context context,Class<?> cls)
	 {
		 Intent intent=new Intent();
		 intent.setClass(context, cls);
		 context.startActivity(intent);
	 }
	 
	 
	 public static void StartApplacation(Activity activity,String pack,String classname)
	 {
		 Intent intent = new Intent(pack); 
		 intent.setClassName(pack,classname); 
		 intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
		 activity.startActivity(intent);  

	 }
	 
}



