package com.mknote.dragonvein.asmack;

public class AsmackMessage {
		
	public AsmackMessage(String ower,String body,boolean issend) {
		this.issend=issend;
		this.ower=ower;
		this.body=body;
	}
	public boolean issend;
	public String ower;
	public String body;
}
