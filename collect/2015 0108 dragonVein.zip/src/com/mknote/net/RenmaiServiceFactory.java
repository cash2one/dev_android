package com.mknote.net;

import java.util.*;
import org.apache.thrift.protocol.*;
import com.mknote.net.thrift.*;

/*
 * 人脉各个服务的封装类， 用于维护人脉服务
 */
public class RenmaiServiceFactory {
	
	private static final String CONST_THRIFT_COMPACT_HEADER = "application/x-thrift-compact";
	private static final String CONST_THRIFT_JSON_HEADER = "application/x-thrift-json";
	private static final String CONST_THRIFT_BINARY_HEADER = "application/x-thrift";
	
	private static final String CONST_HEADER_AUTH = "auth";
	private static final String CONST_HEADER_DEVICEID = "deviceid";
	private static final String CONST_HEADER_VERSION = "clientversion";
	private static final String CONST_HEADER_NETWORK = "networktype";
	private static final String CONST_HEADER_CHANNEL = "channel";

	
	private ServerSettings ServerConfig;
	Map<String, String> CustomHeaderMap;

	private DeviceService.Client deviceService; 
	private PassportService.Client passportService; 
	private KeyService.Client keyService; 
	private ContentService.Client contentService; 
	private ContactService.Client contactService; 	

	private TRenmaiHttpClient deviceHttpClient;
	private TRenmaiHttpClient passportHttpClient;
	private TRenmaiHttpClient keyHttpClient;
	private TRenmaiHttpClient contentHttpClient;
	private TRenmaiHttpClient contactHttpClient;
	
	RenmaiServiceFactory()
	{
		CustomHeaderMap = new HashMap<String, String>();
		
		//默认使用Compact协议
		CustomHeaderMap.put("content-type", CONST_THRIFT_COMPACT_HEADER);
	}
	
	/**
	 * 设置上下文
	 */
	public void setContext(ServerSettings serverConfig, String DeviceID, String ChannelID, String ClientVersion, String NetworkType, String token, boolean IsNeedEncrypt)
	{
		ServerConfig = serverConfig;
		//添加上下文
		setHeader(CONST_HEADER_AUTH,token);
		setHeader(CONST_HEADER_DEVICEID,DeviceID);
		setHeader(CONST_HEADER_VERSION,ClientVersion);
		setHeader(CONST_HEADER_NETWORK,NetworkType);
		setHeader(CONST_HEADER_CHANNEL, ChannelID);
	}
	
	public void setContextToken(String token)
	{
		setHeader(CONST_HEADER_AUTH,token);
	}
	
	private void setHeader(String Key, String Value)
	{
		if(Key != null && Key.length() > 0){
			if(Value != null && Value.length() > 0){
				CustomHeaderMap.put(Key, Value);
			}
			else{
				if(CustomHeaderMap.containsKey(Key)){
					CustomHeaderMap.remove(Key);
				}
			}
		}
	}
	
	private TRenmaiHttpClient CreateRenmaiHttpClient(String url, int timeoutSecond) throws Exception
	{
		TRenmaiHttpClient http = new TRenmaiHttpClient(url);
		
		http.SetCompress(true);
		http.setCustomHeaders(CustomHeaderMap);
		http.setReadTimeout(timeoutSecond * 1000);
		return http;
	}
	
	private TProtocol createProtocol(TRenmaiHttpClient http) throws Exception
	{
		return new TCompactProtocol(http);
	}
	
	/*
	 * 获取设备服务
	 */
	/**
	 * @return
	 * @throws Exception
	 */
	protected DeviceService.Client getDeviceService() throws Exception
	{
		if(deviceHttpClient == null){
			deviceHttpClient = CreateRenmaiHttpClient(ServerConfig.getPassportUrl() + "/device/", ServerConfig.getPassportTimeoutMS());
		}
		
		if (deviceService == null) {
			TProtocol protocol = createProtocol(deviceHttpClient);
			deviceService = new DeviceService.Client(protocol);
		}

		return deviceService;
	}
	
	
	/*
	 * 获取认证，账号服务
	 */
	protected PassportService.Client getPassportService() throws Exception
	{
		if(passportHttpClient == null){
			passportHttpClient = CreateRenmaiHttpClient(ServerConfig.getPassportUrl() + "/auth/", ServerConfig.getPassportTimeoutMS());
		}
		
		if (passportService == null) {
			TProtocol protocol = createProtocol(passportHttpClient);
			passportService = new PassportService.Client(protocol);
		}

		return passportService;
	}

	/*
	 * 获取配置服务
	 */
	protected KeyService.Client getKeyService() throws Exception
	{
		if(keyHttpClient == null){
			keyHttpClient = CreateRenmaiHttpClient(ServerConfig.getPassportUrl() + "/keys/", ServerConfig.getPassportTimeoutMS());
		}
		
		if (keyService == null) {
			TProtocol protocol = createProtocol(keyHttpClient);
			keyService = new KeyService.Client(protocol);
		}

		return keyService;
	}
	
	/*
	 * 获取内容服务
	 */
	protected ContentService.Client getContentService() throws Exception
	{
		if(contentHttpClient == null){
			contentHttpClient = CreateRenmaiHttpClient(ServerConfig.getContentUrl() + "/content/", ServerConfig.getContentTimeoutMS());
		}
		
		if (contentService == null) {
			TProtocol protocol = createProtocol(contentHttpClient);
			contentService = new ContentService.Client(protocol);
		}

		return contentService;
	}

	/*
	 * 获取通讯录服务
	 */
	protected ContactService.Client getContactService() throws Exception
	{
		if(contactHttpClient == null){
			contactHttpClient = CreateRenmaiHttpClient(ServerConfig.getContactUrl() + "/contact/", ServerConfig.getContactTimeoutMS());
		}
		
		if (contactService == null) {
			TProtocol protocol = createProtocol(contactHttpClient);
			contactService = new ContactService.Client(protocol);
		}

		return contactService;
	}
}
