package com.mknote.net;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;
import org.apache.thrift.transport.TTransportFactory;

import android.util.Log;

public class TRenmaiHttpClient extends TTransport {
	
	private static String LOGTAG = TRenmaiHttpClient.class.getSimpleName();

	private URL url_ = null;

	private final ByteArrayOutputStream requestBuffer_ = new ByteArrayOutputStream();

	private InputStream inputStream_ = null;

	private int connectTimeout_ = 0;

	private int readTimeout_ = 0;
	
	private boolean isCompress = false;			

	private Map<String, String> customHeaders_ = null;
	
	private static void PrintLog(String msg)
	{
		Log.i(LOGTAG, msg);
	}
	
	public void SetCompress(boolean compress){
		isCompress = compress;
	}

	public static class Factory extends TTransportFactory {

		private final String url;

		public Factory(String url) {
			this.url = url;
		}

		@Override
		public TTransport getTransport(TTransport trans) {
			try {
				return new TRenmaiHttpClient(url);
			} catch (TTransportException tte) {
				return null;
			}
		}
	}

	public TRenmaiHttpClient(String url) throws TTransportException {
		try {
			url_ = new URL(url);
		} catch (IOException iox) {
			throw new TTransportException(iox);
		}
	}

	public void setConnectTimeout(int timeout) {
		connectTimeout_ = timeout;
	}

	public void setReadTimeout(int timeout) {
		readTimeout_ = timeout;
	}

	public void setCustomHeaders(Map<String, String> headers) {
		customHeaders_ = headers;
	}

	public void setCustomHeader(String key, String value) {
		if (customHeaders_ == null) {
			customHeaders_ = new HashMap<String, String>();
		}
		
		customHeaders_.put(key, value);
	}
	
	public void open() {
	}

	public void close() {
		if (null != inputStream_) {
			try {
				inputStream_.close();
			} catch (IOException ioe) {
				;
			}
			inputStream_ = null;
		}
	}

	public boolean isOpen() {
		return true;
	}

	public int read(byte[] buf, int off, int len) throws TTransportException {
		if (inputStream_ == null) {
			throw new TTransportException(
					"Response buffer is empty, no request.");
		}
		try {
			int ret = inputStream_.read(buf, off, len);
			if (ret == -1) {
				throw new TTransportException("No more data available.");
			}
			return ret;
		} catch (IOException iox) {
			throw new TTransportException(iox);
		}
	}

	public void write(byte[] buf, int off, int len) {
		requestBuffer_.write(buf, off, len);
	}
	
	public void flush() throws TTransportException {
		//如果主动设置了压缩，或者上传的内容大于40k， 则自动压缩
		boolean c = isCompress ||  (requestBuffer_.size() > 1024 * 40);
		if(c)
		{
			if(isCompress)
			{
				PrintLog("强制压缩");
			}
			else
			{
				PrintLog("上传内容大于40K, 启用压缩");
			}
			
			byte[] data = requestBuffer_.toByteArray();
			requestBuffer_.reset();
			try
			{
				GZIPOutputStream zip = new GZIPOutputStream(requestBuffer_);
				zip.write(data);
				zip.finish();
				zip.flush();
				zip.close();
			}
			catch(Exception ex)
			{
				try
				{
					requestBuffer_.reset();
					requestBuffer_.write(data);
					c = false;
				}
				catch(Exception ex2)
				{
					throw new TTransportException("Reset Data (" + ex2.getMessage() + ") after Compress Error :" + ex.getMessage());
				}
			}
			
			PrintLog("压缩比: " + requestBuffer_.size() + "/" + data.length);
			
			data = null;
		}

		//Real Flash
		flushInternal(c);

	}


	private void flushInternal(boolean IsCompressed) throws TTransportException {


		// Extract request and reset buffer
		byte[] data = requestBuffer_.toByteArray();
		requestBuffer_.reset();
		try {
			PrintLog("Post: " + url_.toString());
			// Create connection object
			HttpURLConnection connection = (HttpURLConnection) url_
					.openConnection();

			// Timeouts, only if explicitly set
			if (connectTimeout_ > 0) {
				connection.setConnectTimeout(connectTimeout_);
			}
			if (readTimeout_ > 0) {
				connection.setReadTimeout(readTimeout_);
			}

			// Make the request
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Accept", "application/x-thrift");
			connection.setRequestProperty("User-Agent", "Java/TRenmaiHttpClient");
			
			if (customHeaders_ != null) {
				for (Map.Entry<String, String> header : customHeaders_
						.entrySet()) {
					connection.setRequestProperty(header.getKey(),
							header.getValue());
				}
			}
			
			if(IsCompressed)
			{
				connection.setRequestProperty("TransferEncoding","gzip");
			}
			
			connection.setDoOutput(true);
			connection.connect();
			connection.getOutputStream().write(data);

			int responseCode = connection.getResponseCode();
			if (responseCode != HttpURLConnection.HTTP_OK) {
				
				String Msg = connection.getResponseMessage();
				
				if(Msg == null || Msg.length() == 0)
				{
					InputStream ErrStream = connection.getInputStream();
					int len = connection.getContentLength();
					InputStreamReader reader = new InputStreamReader(ErrStream, "UTF-8");
				    char[] buffer = new char[len];
				    reader.read(buffer);
					Msg = new String(buffer);
					reader.close();
					ErrStream.close();
				}
				PrintLog("Post Error(HTTP " + responseCode + "): " + Msg);
				throw new TTransportException("HTTP Response code(" + responseCode + "): " + Msg);
			}

			// Read the responses
			inputStream_ = connection.getInputStream();
			
			PrintLog("Post End");
		} catch (IOException iox) {
			throw new TTransportException(iox);
		}
	}
}
