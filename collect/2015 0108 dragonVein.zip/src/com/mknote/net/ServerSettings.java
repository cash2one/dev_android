package com.mknote.net;

public class ServerSettings {
	
	private String mSiteRoot = ".mknote.org";

	private String mDispatchUrl = "http://dispatch" + mSiteRoot + "/disp/";
	private String mContactUrl = "http://contact" + mSiteRoot;
	private String mContentUrl = "http://passport" + mSiteRoot;
	private String mPassportUrl = "http://passport" + mSiteRoot;
	private String mImageUrl = "http://img" + mSiteRoot;

	private int mDispatchTimeoutMS = 20;
	private int mPassportTimeoutMS = 10;
	private int mContactTimeoutMS = 10;
	private int mContentTimeoutMS = 10;
	private int mImageTimeoutMS = 10;
	
	private long serverTime = 0;
	
	public long getServerTime() {
		return serverTime;
	}

	public void setServerTime(long serverTime) {
		this.serverTime = serverTime;
	}

	private static String FormatScehma(String url, String defaultUrl){
		if(url == null || url.length() == 0)
			return defaultUrl;
		
		if(url.indexOf("//") < 0)
		{
			return "http://" + url;
		}
		
		return url;
	}

	public String getDispatchUrl() {
		return mDispatchUrl;
	}

	public String getContactUrl() {
		return mContactUrl;
	}

	public String getPassportUrl() {
		return mPassportUrl;
	}
	
	public String getContentUrl() {
		return mContentUrl;
	}
	
	public String getImageUrl() {
		return mImageUrl;
	}
	
	
	public int getDispatchTimeoutMS() {
		return mDispatchTimeoutMS;
	}

	public int getContactTimeoutMS() {
		return mContactTimeoutMS;
	}

	public int getPassportTimeoutMS() {
		return mPassportTimeoutMS;
	}
	
	public int getContentTimeoutMS() {
		return mContentTimeoutMS;
	}
	
	public int getImageTimeoutMS() {
		return mImageTimeoutMS;
	}
	
	
	
	public void setDispatchUrl(String url, int TimeoutSecond){
		mDispatchUrl = FormatScehma(url, mDispatchUrl);
		
		if(TimeoutSecond > 0){
			mDispatchTimeoutMS = TimeoutSecond;
		}
	}
	
	public void setContactUrl(String url, int TimeoutSecond){
		mContactUrl = FormatScehma(url, mContactUrl);
		
		if(TimeoutSecond > 0){
			mContactTimeoutMS = TimeoutSecond;
		}
	}
	
	public void setPassportUrl(String url, int TimeoutSecond){
		mPassportUrl = FormatScehma(url, mPassportUrl);
		
		if(TimeoutSecond > 0){
			mPassportTimeoutMS = TimeoutSecond;
		}
	}
	
	public void setContentUrl(String url, int TimeoutSecond){
		mContentUrl = FormatScehma(url, mContentUrl);
		
		if(TimeoutSecond > 0){
			mContentTimeoutMS = TimeoutSecond;
		}
	}
	
	public void setImageUrl(String url, int TimeoutSecond){
		mImageUrl = FormatScehma(url, mImageUrl);
		
		if(TimeoutSecond > 0){
			mImageTimeoutMS = TimeoutSecond;
		}
	}
}
