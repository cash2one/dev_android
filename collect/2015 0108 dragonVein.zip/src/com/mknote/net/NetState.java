package com.mknote.net;

import com.mknote.dragonvein.AppDragon;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

// 需要权限 <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

public class NetState {
	/*//ConnectivityManager有四个主要任务： 
    //1、监听手机网络状态（包括GPRS，WIFI， UMTS等) 
    //2、手机状态发生改变时，发送广播 
    //3、当一个网络连接失败时进行故障切换 
    //4、为应用程序提供可以获取可用网络的高精度和粗糙的状态
    // 可能会存在4中状态 
    //1.无网络（这种状态可能是因为手机停机，网络没有开启，信号不好等原因） 
    //2.使用WIFI上网 
    //3.CMWAP（中国移动代理） 
    //4.CMNET上网 
	//*/
	BroadcastReceiver mConnectionReceiver = null;
	
	public boolean isNetworkConnected() { 
	   ConnectivityManager mConnectivityManager = (ConnectivityManager) AppDragon.mApp.getSystemService(Context.CONNECTIVITY_SERVICE); 
	   NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo(); 
	   if (mNetworkInfo != null) { 
	      return mNetworkInfo.isAvailable(); 
	   } 
	   return false; 
    }
	
	public boolean isWifiConnected() { 
	    ConnectivityManager mConnectivityManager = (ConnectivityManager) AppDragon.mApp.getSystemService(Context.CONNECTIVITY_SERVICE); 
	    NetworkInfo mWiFiNetworkInfo = mConnectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI); 
	    if (mWiFiNetworkInfo != null) { 
	       return mWiFiNetworkInfo.isAvailable(); 
		} 
		return false; 
	} 
	
	public boolean isMobileConnected() { 
	    ConnectivityManager mConnectivityManager = (ConnectivityManager) AppDragon.mApp.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo mMobileNetworkInfo = mConnectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE); 
	    if (mMobileNetworkInfo != null) { 
	        return mMobileNetworkInfo.isAvailable(); 
		} 
		return false; 
	}
	
	public  int getConnectedType() { 
	    ConnectivityManager mConnectivityManager = (ConnectivityManager) AppDragon.mApp.getSystemService(Context.CONNECTIVITY_SERVICE); 
	    NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo(); 
	    if (mNetworkInfo != null && mNetworkInfo.isAvailable()) { 
	        return mNetworkInfo.getType(); 
	    } 
		return -1; 
	} 
	
	public void registerNetStateMonitorReceiver(){
		mConnectionReceiver = new BroadcastReceiver() { 
			@Override 
			public void onReceive(Context context, Intent intent) { 
			ConnectivityManager connectMgr = (ConnectivityManager) AppDragon.mApp.getSystemService(context.CONNECTIVITY_SERVICE); 
			NetworkInfo mobNetInfo = connectMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE); 
			NetworkInfo wifiNetInfo = connectMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI); 
			if (!mobNetInfo.isConnected() && !wifiNetInfo.isConnected()) { 
			// unconnect network 
			}else { 
			// connect network 
			} 
			} 
			}; 
		IntentFilter intentFilter = new IntentFilter(); 
		intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION); 
		AppDragon.mApp.registerReceiver(mConnectionReceiver, intentFilter); 
	}
	
	public void unRegisterNetStateMonitorReceiver(Context context){
		if (mConnectionReceiver != null) { 
			context.unregisterReceiver(mConnectionReceiver);
		}
	}
}
