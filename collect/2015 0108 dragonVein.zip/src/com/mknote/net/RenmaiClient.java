package com.mknote.net;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TCompactProtocol;

import android.util.Log;

import com.mknote.net.thrift.*;

public class RenmaiClient extends RenmaiServiceFactory implements DeviceService.Iface, ContactService.Iface, PassportService.Iface, KeyService.Iface, ContentService.Iface
{

	private static String LOGTAG = RenmaiClient.class.getSimpleName();
	/**
	 * 服务器接口代理类
	 * @param DeviceID 设备ID
	 * @param ClientVersion 客户端版本号
	 * @param NetworkType 网络类型
	 * @param token Token认证
	 * @param IsNeedEncrypt 是否需要加密, 尚未实现
	 */
	public RenmaiClient(ServerSettings serverConfig, String DeviceID, String ChannelID, String ClientVersion, String NetworkType, String token, boolean IsNeedEncrypt)
	{
		super.setContext(serverConfig, DeviceID, ChannelID, ClientVersion, NetworkType, token, IsNeedEncrypt);
	}
	
	/**
	 * 注册设备
	 */
	@Override
	public DeviceRegResp RegDevice(String DeviceID, String IMEI, String MAC,
			String ProductID, String ProductVersion, String DeviceName,
			String DeviceModel, String DeviceOS, String DeviceOSVersion,
			String Channel) throws ServerError, TException {
		try
		{
			DeviceService.Client client = getDeviceService();
			
			return client.RegDevice(DeviceID, IMEI, MAC, ProductID, ProductVersion, DeviceName, DeviceModel, DeviceOS, DeviceOSVersion, Channel);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 更新推送消息 
	 */
	@Override
	public void UpdateNotify(String ProductID, String DeviceID,
			ENUM_NOTIFY_TYPE NotifyType, String NotifyProvider,
			String NotifyKey, String NotifyToken) throws ServerError,
			TException {
		try
		{
			DeviceService.Client client = getDeviceService();
		
			client.UpdateNotify(ProductID, DeviceID, NotifyType, NotifyProvider, NotifyKey, NotifyToken);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 上传通讯录
	 */
	@Override
	public ContactResp UploadContacts(
			List<ContactEntity> Contacts) throws ServerError, TException {
		try
		{
			ContactService.Client client = getContactService();
		
			return client.UploadContacts(Contacts);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	/**
	 * 读取设备通讯录
	 */
	@Override
	public ContactResp DownloadContacts() throws ServerError,
			TException {
		try
		{
			ContactService.Client client = getContactService();
		
			return client.DownloadContacts();
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 发送注册验证码， 如果手机号已经被注册， 返回IsExisted = true
	 */
	@Override
	public SendRegCodeResp SendRegCode(String MobileNumber) throws ServerError,
			TException {
		try
		{
			PassportService.Client client = getPassportService();
		
			return client.SendRegCode(MobileNumber);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 注册用户，必须在调用SendRegCode之后，使用手机验证码来注册
	 */
	@Override
	public MobileRegResp Reg(String MobileNumber, String Password,
			String SmsCode, String UserName,
			String AnonymousName, String AvatarID, short Gender)
			throws ServerError, TException {
		try
		{
			PassportService.Client client = getPassportService();
		
			return client.Reg(MobileNumber, Password, SmsCode, UserName, AnonymousName, AvatarID, Gender);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 使用手机号和密码登录
	 */
	@Override
	public MobileLoginResp Login(String MobileNumber, String Password)
			throws ServerError, TException {
		// TODO Auto-generated method stub
		try
		{
			PassportService.Client client = getPassportService();
		
			return client.Login(MobileNumber, Password);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 获取当前用户信息
	 */
	@Override
	public UserEntity GetInfo() throws ServerError, TException {
		try
		{
			PassportService.Client client = getPassportService();
		
			return client.GetInfo();
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 读取公共配置信息， 返回KeyList列表
	 */
	@Override
	public KeyListResp GetKeyList(String ProductID, long UpdateTime,
			boolean IsIncludeSubKeys, String PathName) throws ServerError,
			TException {
		try
		{
			KeyService.Client client = getKeyService();
		
			return client.GetKeyList(ProductID, UpdateTime, IsIncludeSubKeys, PathName);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	/**
	 * 读取公共配置信息， 返回指定Key的结果
	 */
	@Override
	public KeyResp GetKey(String ProductID, String PathName, String KeyName)
			throws ServerError, TException {
		try
		{
			KeyService.Client client = getKeyService();
		
			return client.GetKey(ProductID, PathName, KeyName);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public void UpdateInfo(UserEntity Entity) throws ServerError, TException {
		
		try
		{
			PassportService.Client client = getPassportService();
		
			client.UpdateInfo(Entity);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
		
		
	}


	@Override
	public void UpdateProfile(UserProfileEntity Entity) throws ServerError,
			TException {
		try
		{
			PassportService.Client client = getPassportService();
		
			client.UpdateProfile(Entity);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
		
	}


	@Override
	public UserProfileEntity GetProfile() throws ServerError, TException {
		// TODO Auto-generated method stub
		try
		{
			PassportService.Client client = getPassportService();
		
			return client.GetProfile();
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public Map<String, Long> GetUpdated(Map<String, Long> MobileIdMap)
			throws ServerError, TException {
		// TODO Auto-generated method stub
		try
		{
			ContentService.Client client = getContentService();
		
			return client.GetUpdated(MobileIdMap);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public List<MobileDetailEntity> GetRecent(List<String> MobileIDList,
			int TagCount, int CommentCount) throws ServerError, TException {
		try
		{
			ContentService.Client client = getContentService();
		
			return client.GetRecent(MobileIDList, TagCount, CommentCount);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	@Override
	public List<TagEntity> GetTagHistory(String MobileID, long StartTimestamp,
			int Count) throws ServerError, TException {
		// TODO Auto-generated method stub
		try
		{
			ContentService.Client client = getContentService();
		
			return client.GetTagHistory(MobileID, StartTimestamp, Count);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public List<CommentEntity> GetCommentHistory(String MobileID,
			long StartTimestamp, int Count) throws ServerError, TException {
		// TODO Auto-generated method stub
		try
		{
			ContentService.Client client = getContentService();
		
			return client.GetCommentHistory(MobileID, StartTimestamp, Count);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public PostCommentsResp PostComment(List<String> MobileNumberList,
			boolean IsAnonymous, short CommentType, String Title,
			String Content, int ExpireMinute, String ContentType, short TargetType,
			String TargetID, short RelatedType, String RelatedID)
			throws ServerError, TException {
		try
		{
			ContentService.Client client = getContentService();
		
			return client.PostComment(MobileNumberList, IsAnonymous,  CommentType, Title,
					Content, ExpireMinute, ContentType, TargetType,
					TargetID, RelatedType, RelatedID);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public PostTagResp PostTags(List<String> MobileNumberList, boolean IsAnonymous,
			Map<String, Set<String>> Tags, short RelatedType, String RelatedID)
			throws ServerError, TException {
		try
		{
			ContentService.Client client = getContentService();
		
			return client.PostTags(MobileNumberList, IsAnonymous,  Tags, RelatedType, RelatedID);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public MyContentResp MyContent() throws ServerError, TException {
		// TODO Auto-generated method stub
		try
		{
			ContentService.Client client = getContentService();
		
			return client.MyContent();
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public void DeleteComments(List<Integer> idlist) throws ServerError,
			TException {
		try
		{
			ContentService.Client client = getContentService();
		
			client.DeleteComments(idlist);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}


	@Override
	public void DeleteTags(List<Integer> idlist) throws ServerError, TException {
		try
		{
			ContentService.Client client = getContentService();
		
			client.DeleteTags(idlist);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
		
	}

	@Override
	public void SendForgetCode(String MobileNumber) throws ServerError,
			TException {
		try
		{
			PassportService.Client client = getPassportService();
		
			client.SendForgetCode(MobileNumber);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	@Override
	public void ResetPassword(String MobileNumber, String Password,
			String SmsCode) throws ServerError, TException {
		try
		{
			PassportService.Client client = getPassportService();
		
			client.ResetPassword(MobileNumber, Password, SmsCode);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}

	@Override
	public FriendListResp listFriends(long lastTimestamp) throws ServerError,
			TException {
		try
		{
			ContactService.Client client = getContactService();
		
			return client.listFriends(lastTimestamp);
		}
		catch(ServerError se)
		{
			Log.w(LOGTAG, se.toString());
			throw se;
		}
		catch(TException te)
		{
			Log.w(LOGTAG, te.toString());
			throw te;
		}
		catch(Exception ex)
		{
			Log.w(LOGTAG, ex.toString());
			throw new TException(ex);
		}
	}
}
