package com.mknote.net;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.os.Environment;

public class Downloader {

	public boolean downloadFile(String url, String localsavefileurl, boolean isOverwriteExists){
		
        File file=new File(localsavefileurl);
        if(file.exists()){
        	if (isOverwriteExists) {
            	file.delete();
        	} else {
        		return true;
        	}
        }
		URL urlobj = null;
        HttpURLConnection conn = null;
        //取得inputStream，并进行读取   
        InputStream input = null;
        OutputStream output=null;  
		try {
			urlobj = new URL(url);
			conn = (HttpURLConnection)urlobj.openConnection();
			// 3)设置连接超时
			conn.setConnectTimeout(30*1000);
			
			file.createNewFile();//新建文件   
            output=new FileOutputStream(file);   
                // 读取大文件   
                // 主 UI 线程里不能运行网络
                // 这里怎么保证 下载完成了 ????
    		input = conn.getInputStream();
            byte[] buffer=new byte[4*1024];
    	        //BufferedReader in=new BufferedReader(new InputStreamReader(input));
            int len = input.read(buffer);
            while(len!=-1){   
                   //Log.d("len:" + len);	
                   output.write(buffer, 0, len);
                   len = input.read(buffer);
            }   
            output.flush();
            return true;
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		//} finally {
			//if (null != conn) {
			//    conn.disconnect();
			//}
		}   
		// 如果下载出错 则将先前下载的文件删除
        if(file.exists()){
        	file.delete();
		}
		return false;
	}
}
