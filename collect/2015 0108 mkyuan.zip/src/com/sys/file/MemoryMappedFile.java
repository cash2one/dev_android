package com.sys.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.security.AccessController;
import java.security.PrivilegedAction;

import com.mkyuan.GlobleConsts;

public class MemoryMappedFile {
	
	public static void Test1() throws IOException {
		int FILEMAPSIZE = 10485760; // 10 MB
		RandomAccessFile tmpfile = null;
		tmpfile =  new RandomAccessFile(GlobleConsts.ROOT_DIRECTORY  + "largeFile.txt", "rw");
		// Mapping a file into memory
        MappedByteBuffer out = tmpfile.getChannel().map(FileChannel.MapMode.READ_WRITE, 0, FILEMAPSIZE);// Writing into Memory Mapped File
        for (int i = 0; i < 100; i++) {
            out.put((byte) 'A');
        }
        // reading from memory file in Java
        for (int i = 0; i < 10; i++) {
            System.out.print((char) out.get(i));
        }
        tmpfile.close();
	}

	public void Test2() throws IOException{
		//http://blog.csdn.net/jiafu1115/article/details/7644264
		// 1、RandomAccessFile本身不带缓冲读写，和FileInputStream、FileOutputStream等一样，直接按字节读写时，性能不可接受
		// 2、使用MappedByteBuffer读写，固然性能会得到极大提升；其实只要自己处理缓冲，性能都会有非常大的提升，比如以下两种
		//       方式（见下记代码）中第一种使用了MappedByteBuffer，第二种自己进行缓冲，对于12M的文件，后者的效率甚至高于前者
		/* 
		 * 测试结果与Buffer size有关 
		 */  
		// 1、使用MappedByteBuffer: 0.7s   
		String srcFile = "D://Noname1.txt";  
		String destFile = "D://copy.txt";  
		RandomAccessFile rafi;
			rafi = new RandomAccessFile(srcFile, "r");
		RandomAccessFile rafo = new RandomAccessFile(destFile, "rw");  
		FileChannel fci = rafi.getChannel();  
		FileChannel fco = rafo.getChannel();  
		long size = fci.size();  
		MappedByteBuffer mbbi = fci.map(FileChannel.MapMode.READ_ONLY, 0, size);  
		MappedByteBuffer mbbo = fco.map(FileChannel.MapMode.READ_WRITE, 0, size);  
		long start = System.currentTimeMillis();  
		for (int i = 0; i < size; i++) {  
		    byte b = mbbi.get(i);  
		    mbbo.put(i, b);  
		}  
		fci.close();  
		fco.close();  
		rafi.close();  
		rafo.close();  
		System.out.println("Spend: " + (double) (System.currentTimeMillis() - start) / 1000 + "s");  
	}

	public void Test3() throws IOException{
		// 2、自己处理Buffer(RandomAccessFile): 0.13s       
		String srcFile = "D://Noname1.txt";  
		String destFile = "D://copy.txt";  
		RandomAccessFile rafi = new RandomAccessFile(srcFile, "r");  
		RandomAccessFile rafo = new RandomAccessFile(destFile, "rw");  
		  
		byte[] buf = new byte[1024 * 8];  
		  
		long start = System.currentTimeMillis();  
		  
		int c = rafi.read(buf);  
		  
		while (c > 0) {  
		    if (c == buf.length) {  
		        rafo.write(buf);  
		    } else {  
		        rafo.write(buf, 0, c);  
		    }  
		  
		    c = rafi.read(buf);  
		}  
		rafi.close();  
		rafo.close();  
		System.out.println("Spend: " + (double) (System.currentTimeMillis() - start) / 1000 + "s");  
	}

	public void Test4() throws IOException{
		// 3、BufferedInputStream&BufferedOutputStream: 3.02s   
		String srcFile = "D://Noname1.txt";  
		String destFile = "D://copy.txt";  
		FileInputStream rafi = new FileInputStream(srcFile);  
		FileOutputStream rafo = new FileOutputStream(destFile);  
		  
		BufferedInputStream bis = new BufferedInputStream(rafi, 8192);  
		BufferedOutputStream bos = new BufferedOutputStream(rafo, 8192);  
		long size = rafi.available();  
		  
		long start = System.currentTimeMillis();  
		  
		for (int i = 0; i < size; i++) {  
		    byte b = (byte) bis.read();  
		    bos.write(b);  
		}  
		rafi.close();  
		rafo.close();  
		System.out.println("Spend: " + (double) (System.currentTimeMillis() - start) / 1000 + "s");  		
	}
	
	//http://www.ibm.com/developerworks/cn/java/l-javaio/
	// 花1K内存实现高效I/O的RandomAccessFile类

	//http://unmi.cc/java-nio-memory-mapping-communicate/
	// Java NIO 应用 -- 使用内存映射文件实现进程间通信
	public class WriteShareMemory {
		
	    public void main(String[] args) throws Exception {
	        RandomAccessFile raf = new RandomAccessFile("c:/swap.mm", "rw");
	        FileChannel fc = raf.getChannel();
	        MappedByteBuffer mbb = fc.map(MapMode.READ_WRITE, 0, 1024);
	 
	        //清除文件内容
	        for(int i=0;i<1024;i++){
	            mbb.put(i,(byte)0);
	        }
	 
	        //从文件的第二个字节开始，依次写入 A-Z 字母，第一个字节指明了当前操作的位置
	        for(int i=65;i<91;i++){
	            int index = i-63;
	            int flag = mbb.get(0); //可读标置第一个字节为 0
	            if(flag != 0){ //不是可写标示 0，则重复循环，等待
	                i --;
	                continue;
	            }
	            mbb.put(0,(byte)1); //正在写数据，标志第一个字节为 1
	            mbb.put(1,(byte)(index)); //写数据的位置
	 
	            System.out.println("程序 WriteShareMemory："+System.currentTimeMillis() +
	                    "：位置：" + index +" 写入数据：" + (char)i);
	 
	            mbb.put(index,(byte)i);//index 位置写入数据
	            mbb.put(0,(byte)2); //置可读数据标志第一个字节为 2
	            Thread.sleep(513);
	        }
	    }
	}
	public class ReadShareMemory {
		 
	    public void main(String[] args) throws Exception {
	        RandomAccessFile raf = new RandomAccessFile("c:/swap.mm", "rw");
	        FileChannel fc = raf.getChannel();
	        MappedByteBuffer mbb = fc.map(MapMode.READ_WRITE, 0, 1024);
	        int lastIndex = 0;
	 
	        for(int i=1;i<27;i++){
	            int flag = mbb.get(0); //取读写数据的标志
	            int index = mbb.get(1); //读取数据的位置,2 为可读
	 
	            if(flag != 2 || index == lastIndex){ //假如不可读，或未写入新数据时重复循环
	                i--;
	                continue;
	            }
	 
	            lastIndex = index;
	            System.out.println("程序 ReadShareMemory：" + System.currentTimeMillis() +
	                    "：位置：" + index +" 读出数据：" + (char)mbb.get(index));
	 
	            mbb.put(0,(byte)0); //置第一个字节为可读标志为 0
	 
	            if(index == 27){ //读完数据后退出
	                break;
	            }
	        }
	    }
	}		
	//  MappedByteBuffer的Bug
	// MappedByteBuffer在关闭后仍然不能删除文件
	// http://blog.csdn.net/yangjun2/article/details/6542348
	// http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=635956
	// 显性设置byteBuffer为null，并调用GC
	protected void deleteMapFile() {
		java.security.AccessController.doPrivileged(new java.security.PrivilegedAction() {    
			  public Object run() {    
			    try {    
			      MappedByteBuffer buffer = null;
			      Method getCleanerMethod = buffer.getClass().getMethod("cleaner", new Class[0]);    
			      getCleanerMethod.setAccessible(true);    
			      //sun.misc.Cleaner cleaner = (sun.misc.Cleaner)     
			      //getCleanerMethod.invoke(byteBuffer, new Object[0]);    
			      //cleaner.clean();    
			    } catch (Exception e) {    
			      e.printStackTrace();    
			    }    
			    return null;    
			  }    
			});    
	}
}
