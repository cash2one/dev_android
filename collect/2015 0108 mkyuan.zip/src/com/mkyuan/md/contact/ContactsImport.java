package com.mkyuan.md.contact;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.Handler;
import android.provider.ContactsContract.Data;
import android.provider.ContactsContract.Groups;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Event;
import android.provider.ContactsContract.CommonDataKinds.GroupMembership;
import android.provider.ContactsContract.CommonDataKinds.Im;
import android.provider.ContactsContract.CommonDataKinds.Nickname;
import android.provider.ContactsContract.CommonDataKinds.Note;
import android.provider.ContactsContract.CommonDataKinds.Organization;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.CommonDataKinds.Relation;
import android.provider.ContactsContract.CommonDataKinds.StructuredName;
import android.provider.ContactsContract.CommonDataKinds.StructuredPostal;
import android.provider.ContactsContract.CommonDataKinds.Website;
import android.text.TextUtils;

import com.mkyuan.data.comm.ContactsStorage;
import com.mkyuan.data.comm.CommDBConsts.Contacts_Table;

public class ContactsImport {

   public class RunContactsImport implements Runnable {
	   
	   public Context mcontext;
	   public ContactsStorage mstorage;
	   public Handler mHandler;
	   
	   public RunContactsImport(Context context, ContactsStorage storage, Handler handler){
		   mcontext = context;
		   mstorage = storage;
		   mHandler = handler;
	   }
	   
	  @Override
	  public void run() {
		// TODO Auto-generated method stub
		  importFromSystem(mcontext,  mstorage);
		  mHandler.sendEmptyMessage(1);
	  }
   }

	// int numm = 0;
	int phoneCount = 0;
	int emailCount = 0;
	int memoryCount = 0;
	int groupCount = 0;
	int relationCount = 0;
	int qqCount = 0;
	int skypeCount = 0;
	StringBuilder phoneBuilder = new StringBuilder();
	StringBuilder emailBuilder = new StringBuilder();
	StringBuilder memoryBuilder = new StringBuilder();
	StringBuilder qqBuilder = new StringBuilder();
	StringBuilder skypeBuilder = new StringBuilder();
	StringBuilder groupBuilder = new StringBuilder();
	StringBuilder relationBuilder = new StringBuilder();

    public void readContactContentFromSystemCursor(Context context, ContentValues value, Cursor cursor){
		String mimetype = "";
		// 取得mimetype类型
		mimetype = cursor.getString(cursor.getColumnIndex(Data.MIMETYPE));
		// 获得通讯录中每个联系人的ID
		// 获得通讯录中联系人的名字
		if (StructuredName.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String display_name = cursor.getString(cursor.getColumnIndex(StructuredName.DISPLAY_NAME));
			value.put(Contacts_Table.DISPLAY_NAME, display_name);
			value.put(Contacts_Table.SORT_KEY, cursor.getString(cursor.getColumnIndex(StructuredName.SORT_KEY_PRIMARY)));
			return;
		}
		// 获取电话信息
		if (Phone.CONTENT_ITEM_TYPE.equals(mimetype)) {
			phoneCount++;
			String phoneNumber = cursor.getString(cursor.getColumnIndex(Phone.NUMBER));
			if (phoneCount <= 3) {
				value.put("phonenum" + phoneCount, phoneNumber);
			} else if (phoneCount == 4) {
				phoneBuilder.append(phoneNumber);
			} else {
				phoneBuilder.append(";").append(phoneNumber);
			}
			;
			if (!TextUtils.isEmpty(phoneBuilder.toString())) {
				value.put(Contacts_Table.PHONENUMEX, phoneBuilder.toString());
			}
			return;
		}
		// }
		// 查找email地址
		if (Email.CONTENT_ITEM_TYPE.equals(mimetype)) {
			emailCount++;
			String email = cursor.getString(cursor.getColumnIndex(Email.DATA));
			if (emailCount == 1) {
				emailBuilder.append(email);
			} else {
				emailBuilder.append(";").append(email);
			}
			value.put(Contacts_Table.EMAIL, emailBuilder.toString());
			return;
		}
		// 查找event地址
		if (Event.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出时间类型
			int eventType = cursor.getInt(cursor.getColumnIndex(Event.TYPE));
			String event = cursor.getString(cursor.getColumnIndex(Event.START_DATE));

			// 生日
			if (eventType == Event.TYPE_BIRTHDAY) {
				value.put(Contacts_Table.BIRTHDAY, event);
			}
			// 周年纪念日
			if (eventType == Event.TYPE_ANNIVERSARY) {
				memoryCount++;
				if (memoryCount == 1) {
					memoryBuilder.append(event);
				} else {
					memoryBuilder.append(";").append(event);
				}
				value.put(Contacts_Table.MEMORYDAY, memoryBuilder.toString());
			}
			return;
		}
		// 即时消息
		if (Im.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出即时消息类型
			int protocal = cursor.getInt(cursor.getColumnIndex(Im.PROTOCOL));
			String msg = cursor.getString(cursor.getColumnIndex(Im.DATA));
			if (Im.PROTOCOL_QQ == protocal) {
				qqCount++;
				if (qqCount == 1) {
					qqBuilder.append(msg);
				} else {
					qqBuilder.append(";").append(msg);
				}
				value.put(Contacts_Table.QQ, qqBuilder.toString());
			}
			if (Im.PROTOCOL_SKYPE == protocal) {
				skypeCount++;
				if (skypeCount == 1) {
					skypeBuilder.append(msg);
				} else {
					skypeBuilder.append(";").append(msg);
				}
				value.put(Contacts_Table.SKYPE, skypeBuilder.toString());
			}
			return;
		}
		// 获取备注信息
		if (Note.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String remark = cursor.getString(cursor.getColumnIndex(Note.NOTE));
			value.put(Contacts_Table.BRIEF, remark);
			return;
		}
		// 获取昵称信息
		if (Nickname.CONTENT_ITEM_TYPE.equals(mimetype)) {
			String nickName = cursor.getString(cursor.getColumnIndex(Nickname.NAME));
			value.put(Contacts_Table.NICKNAME, nickName);
			return;
		}
		// 获取组织信息
		if (Organization.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出组织类型
			int orgType = cursor.getInt(cursor.getColumnIndex(Organization.TYPE));
			// 单位
			if (orgType == Organization.TYPE_CUSTOM) {
				String company = cursor.getString(cursor.getColumnIndex(Organization.COMPANY));
				value.put(Contacts_Table.COMPANY, company);
				String jobTitle = cursor.getString(cursor.getColumnIndex(Organization.TITLE));
				value.put(Contacts_Table.JOBTITLE, jobTitle);
			}
			return;
		}
		// 获取网站信息
		if (Website.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出组织类型
			int webType = cursor.getInt(cursor.getColumnIndex(Website.TYPE));

			// 个人主页
			if (webType == Website.TYPE_HOMEPAGE) {
				String homePage = cursor.getString(cursor.getColumnIndex(Website.URL));
				value.put(Contacts_Table.HOMEPAGE, homePage);
			}
			return;
		}
		// 查找通讯地址
		if (StructuredPostal.CONTENT_ITEM_TYPE.equals(mimetype)) {
			// 取出地址类型
			int postalType = cursor.getInt(cursor.getColumnIndex(StructuredPostal.TYPE));
			String street = cursor.getString(cursor.getColumnIndex(StructuredPostal.STREET));
			// 单位通讯地址
			if (postalType == StructuredPostal.TYPE_WORK) {
				value.put(Contacts_Table.WORKADDRESS, street);
			}
			// 住宅通讯地址
			if (postalType == StructuredPostal.TYPE_HOME) {
				value.put(Contacts_Table.WORKADDRESS, street);
			}
			return;
		}

		// 群组
		if (GroupMembership.CONTENT_ITEM_TYPE.equals(mimetype)) {
			long groupId = cursor.getLong(cursor.getColumnIndex(GroupMembership.GROUP_ROW_ID));
			Cursor c = context.getContentResolver().query(
					Groups.CONTENT_URI, new String[] { "title" },
					"_id = ?", new String[] { "" + groupId }, null);
			c.moveToFirst();
			String title = c.getString(c.getColumnIndex("title"));
			groupCount++;
			if (groupCount == 1) {
				groupBuilder.append(title);
			} else {
				groupBuilder.append(";").append(title);
			}
			value.put(Contacts_Table.GROUPS, groupBuilder.toString());
			// jsonObject.put("group",
			// c.getString(c.getColumnIndex("title")));
			c.close();
			return;
		}
		// 关系
		if (Relation.CONTENT_ITEM_TYPE.equals(mimetype)) {
			int relationType = cursor.getInt(cursor.getColumnIndex("data2"));
			String relation = null;
			relationCount++;
			if (Relation.TYPE_ASSISTANT == relationType) {
				relation = "助手";
			}
			if (Relation.TYPE_BROTHER == relationType) {
				relation = "兄弟";
			}
			if (Relation.TYPE_CHILD == relationType) {
				relation = "子女";
			}
			if (Relation.TYPE_DOMESTIC_PARTNER == relationType) {
				relation = "同居伴侣";
			}
			if (Relation.TYPE_FATHER == relationType) {
				relation = "父亲";
			}
			if (Relation.TYPE_FRIEND == relationType) {
				relation = "朋友";
			}
			if (Relation.TYPE_MANAGER == relationType) {
				relation = "经理";
			}
			if (Relation.TYPE_MOTHER == relationType) {
				relation = "母亲";
			}
			if (Relation.TYPE_PARENT == relationType) {
				relation = "父母";
			}
			if (Relation.TYPE_PARTNER == relationType) {
				relation = "合作伙伴";
			}
			if (Relation.TYPE_REFERRED_BY == relationType) {
				relation = "介绍人";
			}
			if (Relation.TYPE_RELATIVE == relationType) {
				relation = "亲戚";
			}
			if (Relation.TYPE_SISTER == relationType) {
				relation = "姐妹";
			}
			if (Relation.TYPE_SPOUSE == relationType) {
				relation = "配偶";
			}
			if (relationCount == 1) {
				relationBuilder.append(relation);
			} else {
				relationBuilder.append(";").append(relation);
			}
			return;
		}    	
    }
    
	public void importFromSystem(Context context, ContactsStorage storage) {
		List<ContentValues> values = new ArrayList<ContentValues>();
		int oldrid = -1;
		int contactId = -1;
		Cursor cursor = context.getContentResolver().query(Data.CONTENT_URI,	null, null, null, Data.RAW_CONTACT_ID);

		if (cursor.moveToNext()) {
			contactId = cursor.getInt(cursor.getColumnIndex(Data.RAW_CONTACT_ID));
			oldrid = contactId;
			ContentValues value = new ContentValues();
			values.add(value);
			readContactContentFromSystemCursor(context, value, cursor);
			while (cursor.moveToNext()) {
				if (oldrid != contactId) {
					if (values.size() > 40) {
						storage.insertContacts(values, context);
						values.clear();
					}
					phoneCount = 0;
					emailCount = 0;
					memoryCount = 0;
					qqCount = 0;
					skypeCount = 0;
					groupCount = 0;
					relationCount = 0;
					phoneBuilder.delete(0, phoneBuilder.length());
					emailBuilder.delete(0, emailBuilder.length());
					memoryBuilder.delete(0, memoryBuilder.length());
					qqBuilder.delete(0, qqBuilder.length());
					skypeBuilder.delete(0, skypeBuilder.length());
					groupBuilder.delete(0, groupBuilder.length());
					relationBuilder.delete(0, relationBuilder.length());
					
					value = new ContentValues();
					values.add(value);
					oldrid = contactId;
				}				
				readContactContentFromSystemCursor(context, value, cursor);
			}
			storage.insertContacts(values, context);
			values.clear();
		}
	}
}
