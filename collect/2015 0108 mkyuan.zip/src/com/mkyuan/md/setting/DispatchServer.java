package com.mkyuan.md.setting;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.mkyuan.data.SharePreference2SDCard;
import com.mkyuan.data.comm.ServerSettings;

import android.content.Context;
import android.content.SharedPreferences;

public class DispatchServer {

	   public String fetchDataFromDispatchServer(String url) {
		   String result = "";
		   // http://blog.csdn.net/huzgd/article/details/8712187
		   /* 网上不少人都认为HttpClient更好，理由是功能更强，BUG更少，更容易控制细节。
		    * 但我个人认为普通JAVA人员可选用HttpClient，安卓开发人员则应该使用HttpUrlConnection，理由如下 
		    * */
	   	   HttpURLConnection httpconn = null;
	       InputStreamReader instream = null;
	    	//  android.permission.INTERNET
	       try {
	    	    if ((url == "") || (url == null)) {
	    	       url = ServerSettings.getDispatchUrl();
	    	    }
	       	   URL urlobj = new URL(url);
	       	   httpconn = (HttpURLConnection) urlobj.openConnection();
	           int nRC = httpconn.getResponseCode();
	           if (nRC == HttpURLConnection.HTTP_OK) {
	        	  instream = new InputStreamReader(httpconn.getInputStream());
	              BufferedReader bufferedReader = new BufferedReader(instream);
	              StringBuffer strBuffer = new StringBuffer();
	              String line = null;
	              while ((line = bufferedReader.readLine()) != null) {
	                  strBuffer.append(line);
	              }
	              result = strBuffer.toString();
	            }  
	       } catch (Exception e) {
	    	   e.printStackTrace();
	       } finally {
	           if (httpconn != null) {
	        	   httpconn.disconnect();
	           }
	           if (instream != null) {
	               try {
	            	   instream.close();
	               } catch (IOException e) {
	                   e.printStackTrace();
	               }
	           }
	       }
		   return result;
	   }
	   /*
	   // 解析处理 dispatch server 返回的数据
		// 从 dispatch server 获取数据
		// {"serverTime":1413474236158,
		//  "config":{
		//                 "Passport":{"Address":"passport.mknote.org","TimeoutSecond":30},
		//                 "Contact":{"Address":"contact.mknote.org","TimeoutSecond":30},
		//                 "Test":{"Address":"127.0.0.1","TimeoutSecond":30}
		//                  }}
	   //*/
	   public void parseHandleDispatchServerReturn(Context context, String dispatchData){
	       try {  
			   JSONTokener jsonParser = new JSONTokener(dispatchData);  
			   JSONObject jobj = (JSONObject) jsonParser.nextValue();
			   if (jobj == null) {
				   return;
			   }
			   // 接下来的就是JSON对象的操作了  
	    	   JSONObject jconfig = jobj.getJSONObject("config");
	    	   if (jconfig == null) {
	    		   return;
	    	   }
	       	   //SharedPreferences settings = context.getSharedPreferences("dispatch", Context.MODE_WORLD_READABLE);
	    	   SharedPreferences settings = SharePreference2SDCard.getSDPreferences(context, "dispatch");
			   SharedPreferences.Editor setsettings = settings.edit();
			   
			    jobj.getString("serverTime");
	    	   
	    	   // passport 服务器信息
			   JSONObject jpassport = jconfig.getJSONObject("Passport");
			   //StorageUtils.getSDPreferences(context, );
			   
			   if (jpassport != null) {
				   String strpassport = jpassport.getString("Address");
				   if ((strpassport != null) & (strpassport != "")) {
					   setsettings.putString("", strpassport);
				   }
			   }
	     		// contact Thrift 服务器信息
			   JSONObject jcontact = jconfig.getJSONObject("Contact");
			   if (jcontact != null){
				   String strcontact = jcontact.getString("Address");
				   setsettings.putString("", strcontact);
	  		   }
			   setsettings.commit();
			   
			} catch (JSONException e) {  
			    // 异常处理代码  
			} catch (Exception e) {  
			    // 异常处理代码  
			}  
	   }   
}
