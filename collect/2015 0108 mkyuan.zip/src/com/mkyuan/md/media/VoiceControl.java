package com.mkyuan.md.media;

import java.io.IOException;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;

/* 声音控制 */
public class VoiceControl {
	
     public void playVoice1() throws IllegalArgumentException, SecurityException, IllegalStateException, IOException{
    	 MediaPlayer mediaPlayer = new MediaPlayer();  
    	 if (mediaPlayer.isPlaying()) {  
    	     mediaPlayer.reset();//重置为初始状态  
    	 }  
    	 mediaPlayer.setDataSource("/mnt/sdcard/god.mp3");  
    	 mediaPlayer.prepare();//缓冲   
    	 mediaPlayer.start();//开始或恢复播放  
    	 mediaPlayer.pause();//暂停播放  
    	 mediaPlayer.start();//恢复播放  
    	 mediaPlayer.stop();//停止播放  
    	 mediaPlayer.release();//释放资源  
    	 mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {//播出完毕事件  
    	         @Override public void onCompletion(MediaPlayer mediaPlayer) {  
    	       mediaPlayer.release();  
    	         }  
    	 });  
    	 mediaPlayer.setOnErrorListener(
    		  new MediaPlayer.OnErrorListener() {// 错误处理事件  
    	          @Override 
    	      public boolean onError(MediaPlayer player, int arg1, int arg2) {
   	               //player.release();
         			return false;  
              }
            }
    	);	  
     }
    
     public void playVoice2(){
    	 // 适合播放那些需要反复播放，但时间较短的音效
    	 // 支持同时播放多种声音，这些声音在系统开始时会加载到列表中，
    	 // 按照这些声音的id，我们可以调用这些音效
    	 SoundPool soundPool= new SoundPool(10, AudioManager.STREAM_SYSTEM,5);
    	 //soundPool.load(this,R.raw.collide,1);
    	 soundPool.play(1,1, 1, 0, 0, 1);
     }     
}
