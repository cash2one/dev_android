package com.mkyuan.md.media;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

// Android 轻松实现语音识别的完整代码

public class Voice {
	
	Activity mActivity;
    public void Test(Activity activity){
    	Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    	PackageManager pm = activity.getPackageManager();
    	List activities = pm.queryIntentActivities(intent, 0);
    	if (activities.size() != 0) {
    		startVoiceRecognitionActivity(activity);
    	}
    }
    
    private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
    
    private void startVoiceRecognitionActivity(Activity activity) {
    	Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    	intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    	intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speech recognition demo");
    	
    	/*/1、startActivity( ) 
            仅仅是跳转到目标页面，若是想跳回当前页面，则必须再使用一次startActivity( )。
             2、startActivityForResult( ) 
            可以一次性完成这项任务，当程序执行到这段代码的时候，假若从T1Activity跳转到下一个Text2Activity，
            而当这个Text2Activity调用了finish()方法以后，程序会自动跳转回T1Activity，并调用前一个T1Activity中的onActivityResult( )方法
    	//*/
    	activity.startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data)  {
    	if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == Activity.RESULT_OK) 
    	{
    		ArrayList matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
    	}
    }
}

