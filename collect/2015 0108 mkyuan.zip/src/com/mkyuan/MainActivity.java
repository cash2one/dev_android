package com.mkyuan;

import java.io.File;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.base.HD_RomMobile.sys_device;
import com.base.HD_SDCard.SDCardControl;

import android.text.method.ScrollingMovementMethod;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	Context mcontext;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mcontext = this;
		initEvent1();
		//buttonClickEvent2(mcontext);
	}

	public void initEvent1(){
		Button btn1 = (Button) findViewById(R.id.button1);
		btn1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//buttonClickEvent_appVersion(mcontext);
				buttonClick_dispatchServer1(mcontext);
			}
		});
	}

	public void buttonClickEvent_appVersion(Context context){
		AppVersion appver = new AppVersion();
		TextView txtview = (TextView) findViewById(R.id.textView1);
		String txtValue = "";
		//txtValue = appver.getSelfVersionInfo(context);
		txtValue = appver.checkVersionUpdateRule("1.0.0.3_r3454356",  "");
		txtview.setText(txtValue);
	}
	
	public void buttonClickEvent_sdcard(Context context){
		SDCardControl sdcard = new SDCardControl();
		try {
			//File sdCardDir = new File("/mnt/sdcard"); //获取SDCard目录
		    //File saveFile = new File(sdCardDir, "happy.txt");
			
			File sdCardDir = new File(Environment.getExternalStorageDirectory(), "devtest");
		        if(!sdCardDir.exists()) sdCardDir.mkdirs();
		        
			sdcard.saveToSDCard("devtest/test20141011.txt",  "12345");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void buttonClick_dispatchServer1(Context context){
		/*//
		new Thread() {   
          @Override   
          public void run() {  
      		DispatchServer dispsrv = new DispatchServer();
    		String txtValue = "";
    		TextView txtview = (TextView) findViewById(R.id.textView1);
    		txtview.setText(txtValue);
        	}
        }.start();  
        //*/
		//dispsrv.Refresh(context);
		//txtValue = dispsrv.javaHttpRequestDispatchInfo();
		new refreshDispatchServerInfoTask().execute();   
	}
	class refreshDispatchServerInfoTask extends AsyncTask<String, Integer, String> {   
	       @Override   
	       protected String doInBackground(String... params) {   
	      		DispatchServer dispsrv = new DispatchServer();	  
	      		return dispsrv.javaHttpRequestDispatchInfo();
	           //return dispsrv.parseReturnInfo(dispsrv.javaHttpRequestDispatchInfo());   
	       }   
	  
	       protected void onPostExecute(String result) {   
	           //把doInBackground处理的结果 即天气信息显示在title上
	    		TextView txtview = (TextView) findViewById(R.id.textView1);
	    		// android TextView不用ScrollViewe也可以滚动的方法，很简单实用的代码
	    		txtview.setMovementMethod(ScrollingMovementMethod.getInstance());
	    		txtview.setText(result);
	       }   
	    }
	
	public void buttonClick_dispatchServer2(Context context){
		DispatchServer dispsrv = new DispatchServer();
		TextView txtview = (TextView) findViewById(R.id.textView1);
		String txtValue = "";
		//dispsrv.Refresh(context);
		//txtValue = dispsrv.javaHttpRequestDispatchInfo();
		txtview.setText(txtValue);
	}
	
	public void buttonClick_sysParam(Context context){
		TextView txtview = (TextView) findViewById(R.id.textView1);
		txtview.setSingleLine(false);
		sys_device dev = new sys_device();
		String txtValue = "id:"+ dev.getAndroid_id(context);
		txtValue = txtValue + "\n";		
		txtValue = txtValue + "imei:"+ dev.getIMEI(context);
		txtValue = txtValue + "\n";		
		txtValue = txtValue + "phone:"+ dev.getPhoneNo(context);		
		txtValue = txtValue + "\n";		
		txtValue = txtValue + "info:"+ dev.getDeviceInfo(context);		
		txtview.setText(txtValue);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		return super.onOptionsItemSelected(item);
	}
}
