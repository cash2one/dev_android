package com.mkyuan.pd.comm.view;

import com.mkyuan.libs.Log;

import android.app.Activity;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.PopupWindow;

public class CustomMenu {
	
	//pop.showAtLocation(findViewById(R.id.  tt ),Gravity. BOTTOM , 0, 0);
    // 使用
	/*/CustomMenu cm = new CustomMenu(this); 
        pop = cm.getMenu(touchListener, keyListener); 
        public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            if (pop.isShowing()) {
                pop.dismiss();
            } else {    
                pop.showAtLocation(findViewById(R.id.tt),Gravity.BOTTOM, 0, 0);
            }
        }
        return super.onKeyDown(keyCode, event);
        }
        
        private OnTouchListener touchListener = new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                    pop.dismiss();
                }
                return false;
            }
        };
        
        private OnKeyListener keyListener = new OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_MENU) {
                    pop.dismiss();
                    return true;
                }
                return false;
            }
        }; 
	//*/
	private static PopupWindow mPopWin=null;
    private final Activity mActivity;
     
    public CustomMenu(Activity activity) {
        // TODO Auto-generated constructor stub
        this.mActivity = activity;
    }
                     
    public  PopupWindow getMenu(OnTouchListener touchListener, android.view.View.OnKeyListener keyListener) {
        View view = null;//activity.getLayoutInflater().inflate(R.layout.layout_custom_menu, null);  // layout_custom_menu菜单的布局文件
        mPopWin = new PopupWindow(view,ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);          
        //pop.setAnimationStyle(R.style.pop_anim_style);
        //pop.setBackgroundDrawable(activity.getResources().getDrawable(R.drawable.pop_menu_bg));// 这句是关键，响应返回键必须的语句
        mPopWin.setFocusable(true);
        mPopWin.setTouchable(true);
        mPopWin.setOutsideTouchable(true);
        view.setFocusableInTouchMode(true); 
        mPopWin.setTouchInterceptor(touchListener);
        view.setOnKeyListener(keyListener);
         
        //Log.i(pop.toString());
        return mPopWin;
    }
}
