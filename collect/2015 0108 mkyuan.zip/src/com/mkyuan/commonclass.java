package com.mkyuan;

public class commonclass {

}
