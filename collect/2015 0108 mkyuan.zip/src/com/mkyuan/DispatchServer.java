package com.mkyuan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;

public class DispatchServer {

    public String javaHttpRequestDispatchInfo(){
	   // 刷新 dispatch server 信息
    	// 标准 java 方法
    	// http://dispatch.mknote.org/disp
    	String result = "";
    	HttpURLConnection connection = null;
        InputStreamReader in = null;
        try {
        	// android.permission.INTERNET
        	//URL url = new URL("http://dispatch.mknote.org/disp/");
        	URL url = new URL("http://hq.sinajs.cn/list=s_sh000001,sz002414");
        	connection = (HttpURLConnection) url.openConnection();
            int nRC = connection.getResponseCode();
            if (nRC == HttpURLConnection.HTTP_OK) {
                in = new InputStreamReader(connection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(in);
                // 为什么用 String Buffer 不直接使用 string 运算
                StringBuffer strBuffer = new StringBuffer();
                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    //strBuffer.append(line);
                    result = result + line;
                }
                //String temp = strBuffer.toString();
                //String temp2 = "";
                //result = strBuffer.toString();
                //result = result.getBytes("UTF-8");
                //String temp2 = new String(temp.getBytes("GBK"), "UTF-8");
                //String temp2 = new String(temp.getBytes("UTF-8"), "UTF-8");
                //String temp2 = new String(temp.getBytes(), "UTF-8");
                //String temp2 = new String(temp.getBytes(), "GBK");
                //String temp2 = new String(temp.getBytes("UTF-8"), "GBK");
                //result = temp;
            } else {
            }            	
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    	return result;
    }
    
   public String parseReturnInfo(String retData){
	   String result = retData;
	   return result;
	   /*
       try {  
		   JSONTokener jsonParser = new JSONTokener(retData);  
		   JSONObject jobj = (JSONObject) jsonParser.nextValue();  
		   // 接下来的就是JSON对象的操作了  
		   result =  jobj.getString("serverTime");
		   JSONObject jconfig = jobj.getJSONObject("config");
		   JSONObject jpassport = jconfig.getJSONObject("Passport");
		   result =  result + "\n" + jpassport.getString("Address");
		} catch (JSONException ex) {  
		    // 异常处理代码  
		}  
	  return result;
	  //*/ 
   }   
   
   public void Refresh(){
   	  Thread thread = new Thread( new Runnable() {
   			@Override
   			public void run() {
   			// TODO Auto-generated method stub
   				String retValue = javaHttpRequestDispatchInfo();
   				if (retValue == ""){
   				} else {
   				}    					
   			}
 		  });
   	  thread.start();
   }  

}
