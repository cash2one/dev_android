package com.mkyuan.widget;

import java.lang.reflect.Method;
import java.util.Calendar;

import com.mkyuan.R;
import com.mkyuan.libs.Log;
import com.mkyuan.pd.comm.activities.CalendarActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

//public class VerticalCalendar extends android.widget.ScrollView {
public class VerticalCalendar extends android.widget.FrameLayout {

	//*//
	public VerticalCalendar(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initData(context, attrs, defStyle);
	}
	
	public VerticalCalendar(Context context, AttributeSet attrs) {
		super(context, attrs);
		initData(context, attrs, 0); 
	}

	public VerticalCalendar(Context context) {
		super(context);
		//VerticalCalendar(context, null);
		initData(context, null, 0); 
	}
    //*/

	// 自身的高度
	private int mHeight = 0;

    @Override
	protected void onLayout(boolean changed, int l, int t, int r, int b){
		super.onLayout(changed, l, t, r, b);
		Log.d("VerticalCalendar ------- VerticalCalendar onLayout:" + getMeasuredHeight());
		// 看来 onLayout 是可以用的
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		Log.d("VerticalCalendar onDraw --------------------------------------------------- " + mHeight);
		if (0 == mHeight) {
			if (null != mContainer) {
			   mHeight = mContainer.getMeasuredHeight();
				Log.d("VerticalCalendar onDraw getHeight:" + mHeight);
			}
		}
	}
	
	protected class ContainerLayout extends LinearLayout {

		public ContainerLayout(Context context) {
			super(context);
		}

	    @Override
		protected void onLayout(boolean changed, int l, int t, int r, int b){
			super.onLayout(changed, l, t, r, b);
			Log.d("VerticalCalendar ------- Container onLayout:" + getMeasuredHeight());
			// 看来 onLayout 是可以用的
		}
		
	    @Override
	    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
	        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
			Log.d("VerticalCalendar ------ Container onMeasure:" + widthMeasureSpec + " x " + heightMeasureSpec);	    	
	    }
	    
		@Override
		protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			Log.d("VerticalCalendar ------- Container onDraw:" + getMeasuredHeight());	  
		}
	} 
	
	private float touchdown_y;// 坐标  
	private CalendarData mCalendarData = null;
	private ContainerLayout mContainer = null;
	private int mScreenHeight;
	private int mItemsCount = 20;
	private int mItemHeight = 0;
	private Context mContext;
	private void initData(Context context, AttributeSet attrs, int defStyle){
		Log.d("initData");
		mContext = context;
		if (null == mCalendarData) {
		    mCalendarData = new CalendarData();
		} 
		if (null == mGestureDetector ) {
		    mGestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
		    	
		    });
		}
		// 计算屏幕的高度
	    WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
	    DisplayMetrics outMetrics = new DisplayMetrics();
	    wm.getDefaultDisplay().getMetrics(outMetrics);
	    /*/
	    Display display = wm.getDefaultDisplay(); 
	    Class c = Class.forName("android.view.Display");
	    Method method = c.getMethod("getRawHeight");
	    int height = (Integer) method.invoke(display);
	    Rect rect= new Rect();  
	    this.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
	    // 得到状态栏 高度  
	    getStatusHeight();
	    //*/
	    mScreenHeight = outMetrics.heightPixels;
	    
		Log.d("VerticalCalendar -------------------------------------- mScreenHeight" + mScreenHeight);
		// 设置滚动条的自动隐藏,即不滚动的时候隐藏
		this.setScrollbarFadingEnabled(true);
		// 隐藏垂直滚动条
		this.setVerticalScrollBarEnabled(false);
		//this.setScrollContainer(false);
		
		if (null == mContainer) {
			Log.d("VerticalCalendar -------------------------------------- scroll view add linear layout");
		    mContainer = new ContainerLayout(context);
		    mContainer.setOrientation(LinearLayout.VERTICAL);
  		    //mContainer.setBackgroundColor(android.graphics.Color.BLACK);
		    ViewGroup.LayoutParams layoutParam = new ViewGroup.LayoutParams(
		    		ViewGroup.LayoutParams.MATCH_PARENT,
		    		ViewGroup.LayoutParams.MATCH_PARENT);
  			this.addView(mContainer, layoutParam);
  			
  			for (int i = 0; i < mItemsCount; i++) {
  			   appendChildView(i);
  			}
  			//this.scrollTo(0, mItemHeight);
  			Log.d("VerticalCalendar --------------- container.getHeight:" + mContainer.getMeasuredHeight()); 
		}
	}
	
	private View insertChildView(int index){
	    View item = (LinearLayout) LayoutInflater.from(mContext).inflate(R.layout.calendar_cell_item, null);
		item.setTag(index);	    
		TextView txt = (TextView)item.findViewById(R.id.text_calendar_cell_date);
		if (null != txt) {
		    txt.setText("item" + index);
		}
		mContainer.addView(item, 0);
		return item;		
	}
	
	private View appendChildView(int index){
	    View item = (LinearLayout) LayoutInflater.from(mContext).inflate(R.layout.calendar_cell_item, null);
		item.setTag(index);
		TextView txt = (TextView)item.findViewById(R.id.text_calendar_cell_date);
		ViewGroup.LayoutParams itemLayoutParam = item.getLayoutParams();
		if (null != itemLayoutParam) {			
		    Log.d("VerticalCalendar --------------- item.getHeight:" + itemLayoutParam.height + "_" +
		    item.getMeasuredHeight()); // 0
		} else {
			Log.d("VerticalCalendar --------------- item.getHeight:" + item.getMeasuredHeight());
		}
		if (null != txt) {
		    txt.setText("item" + index);
		}
		mContainer.addView(item);
		//mContainer.getMeasuredHeight();
		//mContainer.getHeight();		
		return item;
	}
	
	@Override  
    protected void onFinishInflate() {  
		Log.d("VerticalCalendar -------------------------------------- onFinishInflate");
        //if (getChildCount() > 0) {  
		//    inner = getChildAt(0);  
		//}  
    }  
      
    @Override  
    public boolean onInterceptTouchEvent(MotionEvent ev) {
    	Log.d("VerticalCalendar -------------------------------------- onInterceptTouchEvent" + ev.getAction());
    	//onTouchEvent：触发触摸事件
    	//onInterceptTouchEvent：触发拦截触摸事件
		final int action = ev.getAction();
        switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
            	return false;
            case MotionEvent.ACTION_UP:
            	return false;
            case MotionEvent.ACTION_MOVE: 
            	// 默认值是false这样才能把事件传给View里的onTouchEvent
            	return false;
        }
       // 返回 true 表示拦截 不再传给 onTouchEvent
        return super.onInterceptTouchEvent(ev);  
    }  
    
    // 手势检测
    private GestureDetector mGestureDetector = null;
    
	@Override  
    public boolean onTouchEvent(android.view.MotionEvent ev) {
		Log.d("VerticalCalendar -------------------------------------- onTouchEvent" + ev.getAction());
		final int action = ev.getAction();
        switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
            	// 获取点击y坐标 
            	touchdown_y = ev.getY();
                final ViewParent parent = getParent();
            	Log.d("VerticalCalendar touchdown:" + touchdown_y);
            	break;
            case MotionEvent.ACTION_UP:
            	Log.d("VerticalCalendar touchup:" + ev.getY());
            	break;
            case MotionEvent.ACTION_MOVE:
            	final float preY = touchdown_y;  
                float nowY = ev.getY();  
                if (0 == mItemHeight) {
                	// 获得linearlayout的具体高度，xml中属性为fill_parent
                	// 等到组件被绘之后才能，得到其位置。准确说是View中的某一个函数被执行后
                	// 可以用 getMeasuredHeight 之类的函数
                	mItemHeight = mContainer.getMeasuredHeight() / mItemsCount; 
                }
      			//Log.d("VerticalCalendar --------------- mItemHeight" +mItemHeight); 
                Log.d("VerticalCalendar touchmove:" + nowY);
                // 获取滑动距离  
                // 当达到顶部时，会动态为顶部添加一个Item，
                // 同时移除底部最后一个Item；用户滑动到达底部也一样，
                // 底部动态添加一个Item，顶部第一个移除；ScrollView内会始终维持用户指定数量+1个Item
                int deltaY = (int) (preY - nowY);
                MarginLayoutParams layoutParam = (MarginLayoutParams)mContainer.getLayoutParams();
                layoutParam.topMargin = deltaY; 
                mContainer.setLayoutParams(layoutParam);
                /*//
                if (mItemHeight > 0) {
                	//int scrollY = getScrollY();
                	if (deltaY > 0) {
                    	if (deltaY >mItemHeight) {
                    		// 在后面插入
                    		appendChildView(mItemsCount);
                    		mItemsCount++;
                    	}
                	} else {
                		if ((deltaY + mItemHeight) < 0) {
                   		    // 在前面插入
                		    insertChildView(mItemsCount);
                    		mItemsCount++;
                		}
                	}
                }
                //*/
        		//**smoothScrollTo(heightMeasureSpec, heightMeasureSpec);
            	break;
            default:
            	Log.d("VerticalCalendar touchevent:" + ev.getAction());
            	break;
        }
        // 这里返回 true 可以接收 后续的 事件通知
        return true;
        //return super.onTouchEvent(ev);  
    }  
	
	@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		//Log.d("VerticalCalendar ------------- onMeasure" +widthMeasureSpec + " x " + heightMeasureSpec);
        //防止多次调用
		/*//
        if (!flag)
        {
            mContainer = (ViewGroup) getChildAt(0);     
            //根据Adapter的方法，为容器添加Item
            if (mAdapter != null)
            {
                mItemCount = mAdapter.getCount();
                mItemHeight = mScreenHeight / mItemCount;
                mContainer.removeAllViews();
                for (int i = 0; i < mAdapter.getCount(); i++)
                {
                    addChildView(i);
                }
            }
            addChildView(0);
        }
        
		setMeasuredDimension();
        //*/
    }
	
	 // 开启动画移动  
    public void animation() {  
        // 开启移动动画  
        TranslateAnimation ta = new TranslateAnimation(0, 0, 0, 0);  
        ta.setDuration(200);  
        ta.setAnimationListener(new AnimationListener() {  
            @Override  
            public void onAnimationStart(Animation animation) {  
                //animationFinish = false;    
            }  
  
            @Override  
            public void onAnimationRepeat(Animation animation) {  
  
            }  
  
            @Override  
            public void onAnimationEnd(Animation animation) {  
                //inner.clearAnimation();  
                // 设置回到正常的布局位置  
            	//inner.layout(normal.left, normal.top, normal.right, normal.bottom);  
            	//normal.setEmpty();  
            	//animationFinish = true;  
            }  
        });  
        //inner.startAnimation(ta);  
    }  	
	/**
	 * 在容器末尾添加一个Item
	 * @param i
	 */
	private void addChildView2(int i)
	{
		/*/
	    View item = mAdapter.getView(this, i);
	    //设置参数
	    android.view.ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
	            android.view.ViewGroup.LayoutParams.MATCH_PARENT, mItemHeight);
	    item.setLayoutParams(lp);
	    //设置Tag
	    item.setTag(i);
	    //添加事件
	    item.setOnClickListener(this);
	    mContainer.addView(item);
	    //*/
	} 
	
	// CellItem 对应每个 cell 里存储的对象
	public class DateCellItem {
		private int mYear = 0;
		public int getYear() { return mYear; }
		public void setYear(int mYear) { this.mYear = mYear; }
		private int mMonth = 0;
		public int getMonth() { return mMonth; }
		public void setMonth(int mMonth) { this.mMonth = mMonth; }
		private int mDay = 0;
		public int getDay() { return mDay; }
		public void setDay(int mDay) { this.mDay = mDay; }
	}
	
	// CalendarData 其实是可以不用放在里面的
	public class CalendarData {
		
		protected int mToday_Year = 0;
	    protected int mToday_Month = 0;
	    protected int mToday_Day = 0;
	    protected int mToday = 0;
	    
	    public int getToday_Day(){
	    	Calendar c = Calendar.getInstance();
	    	if (null == c)
	    		return 0;
	    	return c.get(Calendar.DAY_OF_MONTH);
	    };

	    public int getToday_Month(){
	    	Calendar c = Calendar.getInstance();
	    	if (null == c)
	    		return 0;
	    	return c.get(Calendar.MONTH) + 1;
	    };
	    
	    public int getToday_Year(){
	    	Calendar c = Calendar.getInstance();
	    	if (null == c)
	    		return 0;
	    	return c.get(Calendar.YEAR) + 1;
	    };
	    
	    //<uses-permission android:name="android.permission.READ_CALENDAR"/>   
	    //<uses-permission android:name="android.permission.WRITE_CALENDAR"/>
	    
		public CalendarData(){
		    Calendar c = Calendar.getInstance();
		    //c.getTime()
		    mToday_Year = c.get(Calendar.YEAR);
		    mToday_Month = c.get(Calendar.MONTH) + 1;
		    mToday_Day = c.get(Calendar.DAY_OF_MONTH);
		    //long tmtime = c.getTime().getTime();
		    //long tmdate = c.getTime().getDate(); // 10
		    //Log.d("CalendarData " + tmdate);
		    
		    /*/
		    Log.d("CalendarData Year" + 
		        mToday_Year + "/" + 
		    	mToday_Month + "/" + 
		        mToday_Day + " " +
		        c.get(Calendar.HOUR_OF_DAY) + ":" +
		        c.get(Calendar.MINUTE) + ":" +
		        c.get(Calendar.SECOND)
		        );
		    //*/
		} 
	}		
}
