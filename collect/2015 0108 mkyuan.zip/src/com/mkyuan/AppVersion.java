package com.mkyuan;

import java.io.File;
import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Environment;
import android.os.Bundle;
import android.os.Handler;  

/*//
//*/

// 版本管理
public class AppVersion {
	
	//  检查更新
	public void checkUpdate(){
		//  检查本地保存的更新信息
		checkLocalUpdateInfo();
	}

	//  检查本地保存的更新信息
	public String checkLocalUpdateInfo(){
		return "";
	}
	
	//  检查 最新版本
	public String checkLastestVersion(){
		// 从麦库 服务器 获取最新版本 ???
		// 从电子市场 获取版本信息 ???
		return "";
	}

	public String checkVersionUpdateRule(String appVersion, String updateVersion){
		// 主版本号 + 子版本号 + 指令版本号 + 渠道号 + 发布开发标示 + svn版本号
		String result = appVersion;
		int codePoint  = result.indexOf(".");
		//return codePoint + "";
		if (codePoint > 0) {
			result =  result.substring(codePoint + 1);
			codePoint  = result.indexOf(".");
			if (codePoint > 0) {
				result =  result.substring(codePoint + 1);
				codePoint  = result.indexOf(".");
				if (codePoint > 0) {
					result =  result.substring(codePoint + 1);
					codePoint  = result.indexOf("_");
					if (codePoint > 0) {
						result =  result.substring(codePoint + 1);
					}
				}
			}	
		}
		return result;
	}
	
	public String getSelfVersionInfo(Context context){
	        String verName = "";  
	        try {  
	        	ActivityManager am = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);  
 
		        if (am != null){
			        // < uses-permission android:name =“android.permission.GET_TASKS” />
			        List<RunningTaskInfo> tasks = am.getRunningTasks(2);
		            ComponentName cn = tasks.get(0).topActivity;  
		            String currentPackageName = cn.getPackageName();  
		        	PackageManager pm = context.getPackageManager();
		        	//PackageInfo info = pm.getPackageArchiveInfo(archiveFilePath, PackageManager.GET_ACTIVITIES);
			        PackageInfo pi = pm.getPackageInfo(currentPackageName, 0);
		        	//return pi.activities[0].processName;
		        	//return pi.applicationInfo.processName;
		        	//return pi.applicationInfo.packageName;
		            verName = pi.versionName;  
		        }
	        } catch (Exception e) {  
	        }  
	        return verName;  
	}
	
	// 下载更新文件
	public void downloadUpdateFile(){
		// 1. 从尽量从各电子市场升级
		// 2. 当无法从电子市场下载 则从麦库默认服务器下载
		// 3. 下载地址 由 dispatch server 发布
	}
	
	// 运行下载的更新文件
	public String runUpdateFromLocalUrl(Context context, String fileurl){
		// 新的APK的文件名  
		//String str = "newUpdate.apk";  
		// 新APK在存储卡上的位置  
		//String fileName = Environment.getExternalStorageDirectory() + str;  
		// 通过启动一个Intent让系统来帮你安装新的APK  
		Intent intent = new Intent(Intent.ACTION_VIEW);  
		intent.setDataAndType(Uri.fromFile(new File(fileurl)), "application/vnd.android.package-archive");  
		context.startActivity(intent);  
		return "";
	}
}
