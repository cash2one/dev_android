package com.mkyuan.pd;

import java.io.File;
import java.util.Stack;

import org.apache.thrift.TException;

import com.mkyuan.ApplicationData;
import com.mkyuan.GlobleConsts;
import com.mkyuan.R;
import com.mkyuan.RenMai;
import com.mkyuan.data.SharePreference2SDCard;
import com.mkyuan.data.comm.CommDBConsts;
import com.mkyuan.data.comm.ContactsStorage;
import com.mkyuan.data.comm.ServerSettings;
import com.mkyuan.data.remark.RemarkDBConsts;
import com.mkyuan.data.remark.RemarkStorage;
import com.mkyuan.device.DeviceInfo;
import com.mkyuan.libs.Log;
import com.mkyuan.md.remind.RenmaiRemind;
import com.mkyuan.md.update.AppUpdate;
import com.mkyuan.md.user.UserInfo;
import com.mkyuan.md.user.UserManager;
import com.mkyuan.md.user.UserRegister;
import com.mkyuan.net.DispatchServer;
import com.mkyuan.net.NetState;
import com.mkyuan.net.RenmaiClient;
import com.mkyuan.net.thrift.DeviceRegResp;
import com.mkyuan.net.thrift.ServerError;
import com.mkyuan.pd.comm.activities.AppSplashActivity;
import com.mkyuan.pd.comm.activities.CommMainActivity;
import com.mkyuan.pd.comm.activities.FirstGuideActivity;
import com.mkyuan.pd.comm.activities.SettingActivity;
import com.mkyuan.pd.comm.activities.UserChangePwdActivity;
import com.mkyuan.pd.comm.activities.UserForgetPwdActivity;
import com.mkyuan.pd.comm.activities.UserLoginActivity;
import com.mkyuan.pd.comm.activities.UserRegisterActivity;
import com.mkyuan.service.CommService;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Build;
import android.os.Message;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

/**
 * 应用程序Activity管理类：用于Activity管理和应用程序退出
 */
public class AppManager {
	/*//
    public static class AppReceiver extends BroadcastReceiver{

    	public AppReceiver(){
    		Log.d("AppReceiver create");
    	}
    	
		@Override
		public void onReceive(Context context, Intent intent) {
			Log.d("AppReceiver on rece");
			if (Alarms.APP_NOTIFY_ACTION.equals(intent.getAction())) {
				Toast.makeText(context, "app notify action", Toast.LENGTH_LONG).show();
			}
		}
    }
	private static AppReceiver mAppReceiver;
			mAppReceiver = new AppReceiver();
    //*/
    
	private Stack<Activity> activityStack;
	private static AppManager instance;
	// ====================================
	// single activities
	//private static IntentFilter mIntentFilter = null;
	 public static final String APP_NOTIFY_ACTION = "android.renmai.app";
	 public static final String RENMAI_BROADCAST = "android.renmai.activity.broadcast";
	 public static final String NOTIFY_TYPE = "type";
	 public static final String NOTIFY_TYPE_COMMAND_UPDATE = "update";
	 
	private AppManager(){
		
	}
	/**
	 * 单一实例
	 */
	public static AppManager getAppManager(){
		if(instance==null){
			instance=new AppManager();
		}
		return instance;
	}
	/**
	 * 添加Activity到堆栈
	 */
	public void addActivity(BaseActivity activity){
		if(activityStack==null){
			activityStack=new Stack<Activity>();
		}
		//Log.d("renmai app manager add activity:" + activity.getLocalClassName());
		Log.d("AppManager addActivity:" + activity.getLocalClassName());
		activityStack.add(activity);
		   //动态注册
	   //也可以用这种方法动态注册多个，说明我可以”接收“这么多的动态广播。
	}
	/**
	 * 获取当前Activity（堆栈中最后一个压入的）
	 */
	public Activity currentActivity(){
  	  if (activityStack == null || activityStack.isEmpty()) {
  		  return null;
  	  } else {
  		return activityStack.lastElement();
  	  }
	}

	public void closeActivityByClass(Class<?> activityClass){
		for (int i = activityStack.size() - 1; i >= 0; i--){
			Activity activity = activityStack.get(i);
			if (null != activity){
				if (activity.getClass().equals(activityClass)) {
					activity.finish();
				}
			}
		}
	}
	
    public void closeAllActivityExceptMain(){
    	// 关闭除了 main 以外所有的 activity;
    	Log.d("AppManager closeAllActivityExceptMain begin:");
    	if (null == activityStack) 
    		return;
        if (activityStack.isEmpty()) 
        	return;
    	CommMainActivity mainactivity = null; 
        try {
            for (int i = activityStack.size() - 1; i >= 0; i--){
                try {
            		//**for (int i = 0, size = activityStack.size(); i < size; i++){
            		Activity activity = activityStack.get(i);
                    if (null != activity){
                    	activityStack.remove(activity);
                        if (mainactivity == null) {
                        	if (activity.getClass().equals(CommMainActivity.class)) {
                        		Log.d("AppManager closeAllActivityExceptMain: getmain");
                        		mainactivity = (CommMainActivity) activity;
                        	} else {
                        		Log.d("AppManager closeAllActivityExceptMain: close " + activity.getLocalClassName());
                        		activity.finish();
                        	}
                        } else {
                        	Log.d("AppManager closeAllActivityExceptMain: close " + activity.getLocalClassName());
                           	activity.finish();
                        }
                    }
                } catch (Exception e) {     
                } // try
            } // for 
        } catch (Exception e) {     
        }
        try {
            activityStack.clear();
        } catch (Exception e) {
        		
        }
		Log.d("AppManager closeAllActivityExceptMain end:");
		if (null != mainactivity)
		    activityStack.add(mainactivity);    	
    }
	/**
	 * 结束当前Activity（堆栈中最后一个压入的）
	 */
	public void finishActivity(){
		if (!activityStack.isEmpty()) {
			Activity activity=activityStack.lastElement();
			finishActivity(activity);
		}
	}
	/**
	 * 结束指定的Activity
	 */
	public void finishActivity(Activity activity){
		if(activity!=null){
			Log.d("finishActivity:" + activity.getLocalClassName());
			//activity.unregisterReceiver(mAppReceiver);
			activityStack.remove(activity);
			activity.finish();
			activity=null;
		}
	}
	
	public void showToast(String toastmsg){
		RenMai.mInstance.sendAppMessage(GlobleConsts.MSG_TOAST, toastmsg);
	}

	public void showNetConnectErrorToast(){
		RenMai.mInstance.sendAppMessage(GlobleConsts.MSG_TOAST, RenMai.mInstance.getResources().getString(R.string.err_warning_netconnect));
	}

	private void handleAppMessage(Message msg){
	}
	
	private void handleAppBroadcast(Context context, Intent intent){
		Log.d("doBroadcastNotify:" + intent.getAction());
		String extratype = intent.getStringExtra(AppManager.NOTIFY_TYPE);
		Log.d("doBroadcastNotify extra:" + extratype);
		if (!TextUtils.isEmpty(extratype)) {
			if (extratype.equals(NOTIFY_TYPE_COMMAND_UPDATE)){
				// Application receive update command broadcast
				//Toast.makeText(context, "do update" + context.getClass().getName(), Toast.LENGTH_LONG).show();
				//AppUpdate.showUpdateAlert(context);
			}
		}
	}

	public String getFeedbackTextInfo(){
		SharedPreferences pref = SharePreference2SDCard.getServerSettingPref(RenMai.mInstance);
		if (null != pref)
	        return pref.getString(SharePreference2SDCard.PREF_APP_FEEDBACK_TEXT, ServerSettings.getContactUrl());		
		return null;
	}
	
	public void saveFeedbackTextInfo(String data){
		SharedPreferences pref = SharePreference2SDCard.getServerSettingPref(RenMai.mInstance);
		if (null != pref)
	        pref.edit().putString(SharePreference2SDCard.PREF_APP_FEEDBACK_TEXT, data).commit();		
	}
	
	public void sendUserLoginBroadCast(){
		RenMai.sendBroadcast(GlobleConsts.NOTIFY_COMMAND_USERLOGIN, null);
	}
	
	public void sendUserLogoutBroadCast(){
		RenMai.sendBroadcast(GlobleConsts.NOTIFY_COMMAND_USERLOGOUT, null);
	}
	
	public void sendBroadCast(String key, String data){
		if (TextUtils.isEmpty(key))
			return;
		Intent intent = new Intent(RENMAI_BROADCAST);
		intent.putExtra(key, data);
		RenMai.mInstance.sendBroadcast(intent);
	}
	
	private void handleActivityBroadcast(Context context, Intent intent){
		
	}
	
	public void quitApplication(){
		//Log.d("AppManager quitApplication");
		/*//
       Context context = this.currentActivity();
       if (null != context) {
    	   Log.d("AppManager quitApplication begin");
    	   Intent intent = new Intent(Intent.ACTION_MAIN);  
           intent.addCategory(Intent.CATEGORY_HOME);  
           intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    	   context.startActivity(intent);
           android.os.Process.killProcess(android.os.Process.myPid());
       }
	   //*/ 
	   finishAllActivity();
	   System.exit(0);       
	}
	/**
	 * 结束指定类名的Activity
	 */
	public void finishActivity(Class<?> cls){
		if (null == activityStack)
			return;
		for (Activity activity : activityStack) {
			if(activity.getClass().equals(cls) ){
				finishActivity(activity);
			}
		}
	}
	/**
	 * 结束所有Activity
	 */
	public void finishAllActivity(){
		if (null == activityStack)
			return;
		for (int i = 0, size = activityStack.size(); i < size; i++){
            if (null != activityStack.get(i)){
            	activityStack.get(i).finish();
            }
	    }
		activityStack.clear();
	}
	/**
	 * 退出应用程序
	 */
	public void AppExit(Context context) {
		try {
			finishAllActivity();
			ActivityManager activityMgr= (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
			activityMgr.restartPackage(context.getPackageName());
			System.exit(0);
		} catch (Exception e) {	}
	}

	private void initializeServerSettings(Context context){
		// 从 SD 卡上 先 获取一遍
		try {
    		SharedPreferences pref = SharePreference2SDCard.getServerSettingPref(context);
		String str = pref.getString(SharePreference2SDCard.PREF_SERVER_CONTACTURL, ServerSettings.getContactUrl());
		if (!TextUtils.isEmpty(str)) {
			if (!str.equals(ServerSettings.getContactUrl())) {
				ServerSettings.setContactUrl(str);
			}
		} 
		str = pref.getString(SharePreference2SDCard.PREF_SERVER_PASSPORTURL, ServerSettings.getPassportUrl());
		if (!TextUtils.isEmpty(str)) {
			if (!str.equals(ServerSettings.getPassportUrl())) {
				ServerSettings.setPassportUrl(str);
			}
		  }
		} catch (Exception e) {	}
	}

	private void initDbVersion(Context context) {
		RemarkStorage.DbVersion = RemarkDBConsts.DB_VERSION;
		
		SharedPreferences pref = SharePreference2SDCard.getDbVersionPref(context);
 		if (null != pref) {
 			int version = pref.getInt(SharePreference2SDCard.PREF_VERSION_CONTACTDB, 0);
 			if (version < CommDBConsts.DB_VERSION) {
 				pref.edit().putInt(SharePreference2SDCard.PREF_VERSION_CONTACTDB, CommDBConsts.DB_VERSION).commit();
 			} else {
 				CommDBConsts.DB_VERSION = version;
 			}
 			version = pref.getInt(SharePreference2SDCard.PREF_VERSION_REMARKDB, 0);
 			if (version < RemarkDBConsts.DB_VERSION) {
 				pref.edit().putInt(SharePreference2SDCard.PREF_VERSION_REMARKDB, RemarkDBConsts.DB_VERSION).commit();
 				RemarkStorage.DbVersion = RemarkDBConsts.DB_VERSION;
 			} else {
 				RemarkStorage.DbVersion = version;	
 			} 			 
 		}
	}
	
	private void initReminds(Context context){
		// 打开 remind 数据库
		// 把最近需要的 Remind 加进去
		// 完成一次 Remind 以后再把下一条 Remind 添加进去
		//RenmaiRemind.addRemind(context, System.currentTimeMillis() + 5000);
	}

	private void initPrefs(Context context){
		SharedPreferences pref = SharePreference2SDCard.getCommonPref(context);
 		if (null != pref) {
			AppUpdate.getAppUpdate().setIgnoreUpdateVersion(pref.getString(SharePreference2SDCard.PREF_APP_IGNOREUPDATE, ""));
			
			UserManager usermgr = UserManager.getUserManager();
			usermgr.getCurrentUserInfo().setEnterUserId(pref.getLong(SharePreference2SDCard.PREF_USER_CURRENT, usermgr.getCurrentUserInfo().getEnterUserId()));
	 		UserManager.UserHasLoginedHistory = pref.getLong(SharePreference2SDCard.PREF_USER_LOGINED, UserManager.UserHasLoginedHistory);
	 		
 			Log.d("AppManager initPrefs userid:" + usermgr.getCurrentUserInfo().getEnterUserId());
 			if ((UserManager.INVLAID_USERID == usermgr.getCurrentUserInfo().getEnterUserId()) || (UserManager.INVLAID_INITIALUSERID == usermgr.getCurrentUserInfo().getEnterUserId())) {
 				// 当前 是无效的 用户 id 设为默认的 工作用户
 				usermgr.setUserId(UserManager.DEFAULT_USERID);
 			} else {
 				usermgr.setUserId(usermgr.getCurrentUserInfo().getEnterUserId());
 			}
 		}
	}

	private void finalPrefs(Context context){
		/*/
		SharedPreferences pref = SharePreference2SDCard.getCommonPref(context);
 		if (null != pref) {
			Editor edtpref = pref.edit();
	 		if (null != edtpref) {
			  //edtpref.putString(SharePreference2SDCard.PREF_PROTO_CONTACTLISTID, UserInfo.getContactListId());
			  edtpref.commit();
	 		}
 		}
 		//*/
	}
	
	private Boolean checkRegisterDevice(Context context){
		Log.d("AppManager checkRegisterDevice begin");
		SharedPreferences pref = SharePreference2SDCard.getCommonPref(context);
 		if (null != pref) { 			
 			String devid = pref.getString(SharePreference2SDCard.PREF_RENMAI_DEVICEID, "");
 			String oldImei = pref.getString(SharePreference2SDCard.PREF_DEVICE_IMEI , "");
 			String oldmac = pref.getString(SharePreference2SDCard.PREF_DEVICE_MAC, "");
 			String newImei = DeviceInfo.getIMEI(context); //"IMEI",
 			String newmac = DeviceInfo.getWifiMacAddress(context); //"MAC",
 			UserManager usermgr = UserManager.getUserManager();
 			if (!TextUtils.isEmpty(devid)) {
 				usermgr.getCurrentUserInfo().setDeviceId(devid);
 			}
 			if (!TextUtils.isEmpty(newImei)) {
 				usermgr.getCurrentUserInfo().setIMEI(newImei);
 			}
 			if (TextUtils.isEmpty(devid) || (!oldImei.equals(newImei)) || (!oldmac.equals(newmac))) {
 	 			RenmaiClient client = new RenmaiClient(usermgr.getCurrentUserInfo().getToken(), false);
 	 			try {
	 				DeviceRegResp devreg = client.RegDevice(
 	 						devid, //android.os.Build.ID, //"DeviceID", 
 	 						newImei, //"IMEI", 
 	 						newmac, 
 	 						ApplicationData.getProductID(), //"ProductID", 
 	 						ApplicationData.getAppVersionName(context), //"ProductVersion", 
 	 						android.os.Build.DISPLAY, //"DeviceName", 
 	 						Build.MODEL, // + Build.MANUFACTURER, //"DeviceModel", 
 	 						"android", // Build.TYPE, //"DeviceOS", 
 	 						Build.VERSION.RELEASE, //"DeviceOSVersion", Build.VERSION_CODES.BASE + "_" +  
 	 						""//"Channel"
 	 						);
 	 				if (!TextUtils.isEmpty(devreg.DeviceID)){
 	 					 usermgr.getCurrentUserInfo().setDeviceId(devreg.DeviceID);
 	 				  Editor edt = pref.edit();
 	 				  edt.putString(SharePreference2SDCard.PREF_RENMAI_DEVICEID, devreg.DeviceID);
   	 				  edt.putString(SharePreference2SDCard.PREF_DEVICE_IMEI, newImei);
 	 				  edt.putString(SharePreference2SDCard.PREF_DEVICE_MAC, newmac);
 	 				  edt.commit();
 	 				  return true;
 	 				}
 	 			} catch (ServerError e) {
 	 				// TODO Auto-generated catch block
 	 				//Log.d("register device server err:" + e.Msg);
 	 				e.printStackTrace();
 	 			} catch (TException e) {
 	 				// TODO Auto-generated catch block
 	 				//Log.d("register device err:" + e.getMessage());
 	 				e.printStackTrace();
 	 			}
 			}
 		} else {
 			
 		}
 		return false;
 		//Log.d("checkRegisterDevice end");
	}
	
	// 这个如果放在 getAppManager() 那就全部 activity 无论在哪里 启动 都通用了
	public void startInitApp(Activity activity){
	
		WindowManager winmgr = activity.getWindowManager();
		Display display = winmgr.getDefaultDisplay();
        DisplayMetrics metric = new DisplayMetrics(); 
        display.getMetrics(metric); 
		Log.d("startInitApp (" + display.getWidth() + " x "+ display.getHeight() + ")" + activity.getResources().getDisplayMetrics().density + " _ " + metric.densityDpi);		
        /*
         * activity.getResources().getDisplayMetrics().density
         * LDPI 0.75
         * 1 MDPI                
         *  HDPI (480 * 854) 1.5_240 dpi sony 
         * xhdpi：至少960*720
         * (720 * 1280) 2.0_320 xxhdpi 红米 5.5 寸  [360 * 2.54 X 640 * 2.54]
         * (1080 * 1776) 3.0_480 dpi nexus  914.4 * 1503.68 [360 * 2.54 X 592 * 2.54]
         * 1 英寸 = 2.54 厘米
         * Density 每平方英寸中的像素数
         * Resolution（分辨率）
         * Density=Resolution/Screen size
        int width = metric.widthPixels; // 宽度（PX） 
        int height = metric.heightPixels; // 高度（PX） 
        float density = metric.density; // 密度（0.75 / 1.0 / 1.5） 
        int densityDpi = metric.densityDpi;
         * */
        
		// 获取本机参数
		initPrefs(activity);
		// 初始化 动态数据库版本
		initDbVersion(activity);
        // 这个应该放到一个 初始化的地方去 放在线程里
       initializeServerSettings(activity);
		// 开启本地服务 
		startCommService(activity);
       
       
		(new Thread() {
			@Override  
			public void run(){  
				Context context = getAppManager().currentActivity();
				NetState state = new NetState();
				if (state.isNetworkConnected(context)){
					// 优先向服务器注册 设备 
					// 本来应该先 更新服务器 配置的 不过也没有什么关系
			        //Log.d("checkRegisterDevice");
			        boolean isreged = checkRegisterDevice(context);
			        
			        try {
		    			// 刷新服务器配置 不是每次启动 都需要刷新 ??? 当天刷新一次 ???
						// 从 dispatch server 更新 服务器地址信息
			        	
						// 这个刷新不用很频繁 一天最多一次 ?? 把 获取过 更新的时间记录下来 用作比对
		    	  		//refreshServerSettings(context);
			        	if (DispatchServer.parseUpdateDispatchServerSettings(DispatchServer.fetchDataFromDispatchServer(ServerSettings.getDispatchUrl())))
  			          	  DispatchServer.saveServerSettings(context);
			        } catch (Exception e) 
			        {	
			        }
			        if (!isreged) {
			        	checkRegisterDevice(context);
		            }
					// 完成 获取服务器配置以后 开始检查更新
					AppUpdate.getAppUpdate().checkUpdate();
				}
            }  
		}).start();
	}
	
	// 主界面开始以后的初始化 避免 splash activity 销毁
	public void mainInitApp(Activity activity){
		Log.d("mainInitApp");
		(new Thread() {
			@Override  
			public void run(){
				Context context = getAppManager().currentActivity();
				NetState state = new NetState();
				if (state.isNetworkConnected(context)){
					//*/
					//Log.d("send sms code");
	    	  		//UserRegister userreg = new UserRegister();
 	    	  		//userreg.doRegister("13917781774", "123456", "", "hello word");
	    	  		//userreg.doRequestSmsCode("13917781774");
	    	  		//Log.d("send sms code end");
 	    	  		//*/
					// 完成 获取服务器配置以后 开始检查更新
					//Log.d("checkUpdate");
					//checkUpdate(context);
				}
			}
		}).start();
		// 应该在 用户信息 初始化里面 把应用的提醒 初始化
		// 主界面 初始化 完成以后 才 初始化 提醒 否则没必要
		//initReminds(context);
	}

	/********* 示例代码 create broadcast receiver
	public BroadcastReceiver createBroadcastReceiver(Context context){
        //注册广播接收器
		BroadcastReceiver receiver=new BroadcastReceiver() {
		  	   @Override
		  	   public void onReceive(Context context, Intent intent) {
		  		 if (intent.getAction().equals(AppManager.ACTIVITY_NOTIFY_ACTION)) {
		  			   //doActivityBroadcast(context, intent);
		  		 }
		  	   }
		};
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(AppManager.ACTIVITY_NOTIFY_ACTION);
		context.registerReceiver(receiver, intentFilter);
		return receiver;
	}
	//*********/
	
	/*********
	private static AppSplashActivity mSplashActivity = null;
    public static AppSplashActivity getSplashActivity(){
    	return mSplashActivity;
    }
    public static void setSplashActivity(AppSplashActivity activity){
    	mSplashActivity = activity;
    }
   //*********/
    
	//*********
	private FirstGuideActivity mFirstUseActivity = null;	
    public FirstGuideActivity getFirstUseActivity(){
    	return mFirstUseActivity;
    }
    public void setFirstUseActivity(FirstGuideActivity activity){
    	mFirstUseActivity= activity;
    }
    //*********/
    
	//*********
	private UserLoginActivity mUserLoginActivity = null;
    public UserLoginActivity getUserLoginActivity(){
    	return mUserLoginActivity;
    }
    public void setUserLoginActivity(UserLoginActivity activity){
    	mUserLoginActivity= activity;
    }
    public void closeUserLoginActivity(){
		if (null != mUserLoginActivity) {
			mUserLoginActivity.callCloseActivity();
			mUserLoginActivity = null;
		}
    }
   //*********/
    
	//*********
	private UserRegisterActivity mUserRegiserActivity = null;
    public UserRegisterActivity getUserRegisterActivity(){
    	return mUserRegiserActivity;
    }
    public void setUserRegisterActivity(UserRegisterActivity activity){
    	mUserRegiserActivity= activity;
    }
    public void closeUserRegisterActivity(){
		if (null != mUserRegiserActivity) {
			mUserRegiserActivity.callCloseActivity();
			mUserRegiserActivity = null;
		}
    }
   //*********/
    
  //*********
	private UserForgetPwdActivity  mUserForgetPwdActivity = null;
    public UserForgetPwdActivity getUserForgetPwdActivity(){
    	return mUserForgetPwdActivity;
    }
    public void setUserForgetPwdActivity(UserForgetPwdActivity activity){
    	mUserForgetPwdActivity= activity;
    }
    public void closeUserForgetPwdActivity(){
		if (null != mUserForgetPwdActivity) {
			mUserForgetPwdActivity.callCloseActivity();
			mUserForgetPwdActivity = null;
		}
    }
   //*********/
    
    //*********
    private UserChangePwdActivity mUserChangePwdActivity = null;
    public UserChangePwdActivity getUserChangePwdActivity(){
    	return mUserChangePwdActivity;
    }
    public void setUserChangePwdActivity(UserChangePwdActivity activity){
    	mUserChangePwdActivity= activity;
    }
    public void closeUserChangePwdActivity(){
		if (null != mUserChangePwdActivity) {
			mUserChangePwdActivity.callCloseActivity();
			mUserChangePwdActivity = null;
		}    	
    }
    //*********/
    
   //*********
	private CommMainActivity mMainFragActivity = null;
    public CommMainActivity getMainActivity(){
    	return mMainFragActivity;
    }
    public void setMainActivity(CommMainActivity activity){
    	mMainFragActivity = activity;
    }
   //*********/
    
   //*********
    private SettingActivity mAppSettingActivity = null;
    public SettingActivity getAppSettingActivity(){
    	return mAppSettingActivity;
    }
    public void setAppSettingActivity(SettingActivity activity){
    	mAppSettingActivity = activity;
    }    
    public void closeAppSettingActivity(){
		if (null != mAppSettingActivity) {
			mAppSettingActivity.callCloseActivity();
			mAppSettingActivity = null;
		}
    }
	//*********/
	/**
	 * 开启数据处理服务
	*/
	private void startCommService(Context context){
		Intent intent = new Intent();
		intent.setClass(RenMai.mInstance, CommService.class);
		RenMai.mInstance.startService(intent);
	}
	
	public void runApkPackage(String fileurl){
		Context context = getAppManager().currentActivity();
  	    if (null == context) 
  	    	context = RenMai.mInstance;
		File file=new File(fileurl);
		if(file.exists()){
		   Intent intent = new Intent(Intent.ACTION_VIEW);
		  intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  
		  intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
		  context.startActivity(intent); 
        }
	}
	/**
	 * 显示或隐藏输入法
	 * @param v
	 * @param show
	 */
	public void showOrHideInputMethod (View v, boolean show) {
		if (show) {
			showKeyboard(v);
		} else {
			hideKeyboard(v);
		}
	}
	
	 public void hideKeyboard(View v)
     {
         InputMethodManager imm = ( InputMethodManager ) v.getContext( ).getSystemService( Context.INPUT_METHOD_SERVICE );     
       if ( imm.isActive( ) ) {     
           imm.hideSoftInputFromWindow( v.getApplicationWindowToken( ) , 0 );   
           
       }    
     }
     
     //显示虚拟键盘
     public void showKeyboard(View v)
     {
         InputMethodManager imm = ( InputMethodManager ) v.getContext( ).getSystemService( Context.INPUT_METHOD_SERVICE );     
       
       imm.showSoftInput(v,InputMethodManager.SHOW_FORCED);    
   
     }
}