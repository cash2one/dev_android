package com.mkyuan.pd.phone.activities;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.telephony.CellLocation;
import android.telephony.NeighboringCellInfo;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;

import com.mkyuan.R;
import com.mkyuan.RenMai;
import com.mkyuan.data.SharePreference2SDCard;
import com.mkyuan.libs.Log;
import com.mkyuan.md.setting.AppSplashHelper;
import com.mkyuan.md.user.UserInfo;
import com.mkyuan.md.user.UserManager;
import com.mkyuan.pd.AppManager;
import com.mkyuan.pd.BaseActivity;

public class PhoneActivity extends BaseActivity  {
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		System.gc();
	}
	
    // 通过TelephoneManager类的getCallState() 方法获取状态值，有三种
	//int CALL_STATE_IDLE Device call state: No activity. 
	//int CALL_STATE_OFFHOOK Device call state: Off-hook. 
	//int CALL_STATE_RINGING Device call state: Ringing.
	
	public class PhoneCallOut {
		
		private Phone mPhone;
		
		private static final String PERMISSION = android.Manifest.permission.PROCESS_OUTGOING_CALLS;		
		public static final String EXTRA_ALREADY_CALLED = "android.phone.extra.ALREADY_CALLED";
		public static final String EXTRA_ORIGINAL_URI = "android.phone.extra.ORIGINAL_URI";
		boolean callNow;
		 
		private void call() {
			//mPhone = PhoneActivity.this.getInstance().phone;
		    Intent intent = getIntent();
		    String action = intent.getAction();
		    intent.setAction(Intent.ACTION_CALL);
		    String number = "";
		    Intent broadcastIntent = new Intent(Intent.ACTION_NEW_OUTGOING_CALL);
	        if (number != null) broadcastIntent.putExtra(Intent.EXTRA_PHONE_NUMBER, number);
	        broadcastIntent.putExtra(EXTRA_ALREADY_CALLED, callNow);
	        broadcastIntent.putExtra(EXTRA_ORIGINAL_URI, intent.getData().toString());   
	        //boolean b = intent.getBooleanExtra(PhoneActivity.EXTRA_INTENT_FROM_BT_HANDSFREE, false);      
	        //broadcastIntent.putExtra(EXTRA_INTENT_FROM_BT_HANDSFREE, b); 
	                
	        sendOrderedBroadcast(broadcastIntent, PERMISSION, null, null, Activity.RESULT_OK, number, null);
		}
		
		private void call2() {
			//Intent intent=new Intent("android.intent.action.CALL", Uri.parse("tel:"+"13900001111"));
			Uri uri=Uri.parse("tel:"+"13900001111");  
            Intent intent=new Intent();  
            intent.setAction(Intent.ACTION_CALL);  // 直接拨号  
            intent.setAction(Intent.ACTION_DIAL);  // 调用拨号程序 手工拨出。
            intent.setData(uri);  
			startActivity(intent);
			String SECRET_CODE_ACTION ="android.provider.Telephony.SECRET_CODE";
			
			Uri uri2 = Uri.parse("android_secret_code://" + "1");
			 //Intent intent2 = new Intent(android.provider.Telephony.Mms.Intents.SECRET_CODE_ACTION, uri2);
			//Intent intent2 = new Intent(android.provider.Telephony.Sms.Intents.SECRET_CODE_ACTION, uri2);
			//Intent intent2 = new Intent(Intents.SECRET_CODE_ACTION, uri2);
			// PhoneActivity.this.sendBroadcast(intent2);  
		}
		 //<uses-permission android:name="android.permission.BROADCAST_STICKY" />
		 //<uses-permission android:name="android.permission.CALL_PHONE" />
	     //<uses-permission android:name="android.permission.CALL_PRIVILEGED" />
	}
	
	public class SmsMgr {
		private void test() {
			// <uses-permission android:name="android.permission.SEND_SMS"/>
		    SmsManager manager = SmsManager.getDefault();  
		    //manager.sendTextMessage(MOBILE_NUMBER, null, MOBILE_BALANCE, null,null); 
		}
	}
	
	public class DialListener extends BroadcastReceiver {
		//注：用户在拨号盘输入*#*#xxxx#*#*后会发送一个广播
		//action是android.provider.Telephony.SECRET_CODE
		//data是 android_secret_code://xxxx
		//<receiver android:name="Listener">
		//<intent-filter>
		//<action android:name="android.provider.Telephony.SECRET_CODE" />
			//<data android:host="0556" android:scheme="android_secret_code" />
			//</intent-filter>
	    //</receiver>		
		@Override
		public void onReceive(Context context, Intent intent) {
			String pwd = intent.getData().getHost();
		}
	}
	
	public class TelListener extends PhoneStateListener {
		
		@Override     
	    public void onCallStateChanged(int state, String incomingNumber) {
			 super.onCallStateChanged(state, incomingNumber); 
			 switch (state) {     
		        case TelephonyManager.CALL_STATE_IDLE: // 空闲状态，即无来电也无
		        	break;
		        case TelephonyManager.CALL_STATE_RINGING: // 来电响铃
		        	break;
		        case TelephonyManager.CALL_STATE_OFFHOOK: // 摘机，即接通
		        	break;
			 }
		}	    
	}
	
	private void checkPhoneState() {
		//TelephoneManager tele
		//TelephonyManager.CALL_STATE_OFFHOOK
		//Intent intent = new Intent("android.intent.action.CALL", Uri.parse("tel:" + mobile));             
		//startActivity(intent)
		//Call.State state = call.getState();
		//TelephonyManager tele = TelephonyManager.();
		//if (tele.getDefault().getVoiceMailNumber() != null) {
			
		//}
		// 来电状态监听功能
		//<uses-permission android:name="android.permission.READ_PHONE_STATE" />    
		//<uses-permission android:name="android.permission.PROCESS_OUTGOING_CALLS" />
		//<uses-permission android:name="android.permission.RECORD_AUDIO"/>
		// <!-- 要存储文件或者创建文件夹的话还需要以下两个权限 -->
		//<uses-permission android:name="android.permission.MOUNT_UNMOUNT_FILESYSTEMS"/>     
		//<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>  
		TelephonyManager telMgr = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);    
        telMgr.listen(new TelListener(), PhoneStateListener.LISTEN_CALL_STATE);        
	}
	
	public class TeleManagerAgent {
		private void test() {
			TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
			 /** 返回电话状态
	         * CALL_STATE_IDLE 无任何状态时 
	         * CALL_STATE_OFFHOOK 接起电话时
	         * CALL_STATE_RINGING 电话进来时 */
 		    tm.getCallState();
 		    
 		   //返回当前移动终端的位置
 	        CellLocation location=tm.getCellLocation();
 	        
 	       /** 获取数据活动状态
 	         * DATA_ACTIVITY_IN 数据连接状态：活动，正在接受数据
 	         * DATA_ACTIVITY_OUT 数据连接状态：活动，正在发送数据
 	         * DATA_ACTIVITY_INOUT 数据连接状态：活动，正在接受和发送数据
 	         * DATA_ACTIVITY_NONE 数据连接状态：活动，但无数据发送和接受  */
 	        tm.getDataActivity();
 	        
 	       /** 获取数据连接状态
 	         * DATA_CONNECTED 数据连接状态：已连接
 	         * DATA_CONNECTING 数据连接状态：正在连接
 	         * DATA_DISCONNECTED 数据连接状态：断开
 	         * DATA_SUSPENDED 数据连接状态：暂停  */
 	        tm.getDataState();
 	        
 	       tm.getDataState();
 	        /**
 	         * 返回当前移动终端的唯一标识
 	         * 
 	         * 如果是GSM网络，返回IMEI；如果是CDMA网络，返回MEID
 	         */
 	        tm.getDeviceId();
 	        //返回移动终端的软件版本，例如：GSM手机的IMEI/SV码。
 	        tm.getDeviceSoftwareVersion();
 	        //返回手机号码，对于GSM网络来说即MSISDN
 	        tm.getLine1Number();
 	        //返回当前移动终端附近移动终端的信息
 	        List<NeighboringCellInfo> infos=tm.getNeighboringCellInfo();
 	        for(NeighboringCellInfo info:infos){
 	            //获取邻居小区号
 	            int cid=info.getCid();
 	            //获取邻居小区LAC，LAC: 位置区域码。为了确定移动台的位置，每个GSM/PLMN的覆盖区都被划分成许多位置区，LAC则用于标识不同的位置区。
 	            info.getLac();
 	            info.getNetworkType();
 	            info.getPsc();
 	            //获取邻居小区信号强度  
 	            info.getRssi();
 	        }
 	        //返回ISO标准的国家码，即国际长途区号
 	        tm.getNetworkCountryIso();
 	        //返回MCC+MNC代码 (SIM卡运营商国家代码和运营商网络代码)(IMSI)
 	        tm.getNetworkOperator();
 	        //返回移动网络运营商的名字(SPN)
 	        tm.getNetworkOperatorName(); 	
 	       /**
 	         * 获取网络类型
 	         * 
 	         * NETWORK_TYPE_CDMA 网络类型为CDMA
 	         * NETWORK_TYPE_EDGE 网络类型为EDGE
 	         * NETWORK_TYPE_EVDO_0 网络类型为EVDO0
 	         * NETWORK_TYPE_EVDO_A 网络类型为EVDOA
 	         * NETWORK_TYPE_GPRS 网络类型为GPRS
 	         * NETWORK_TYPE_HSDPA 网络类型为HSDPA
 	         * NETWORK_TYPE_HSPA 网络类型为HSPA
 	         * NETWORK_TYPE_HSUPA 网络类型为HSUPA
 	         * NETWORK_TYPE_UMTS 网络类型为UMTS
 	         * 
 	         * 在中国，联通的3G为UMTS或HSDPA，移动和联通的2G为GPRS或EGDE，电信的2G为CDMA，电信的3G为EVDO
 	         */
 	        tm.getNetworkType();
 	        /**
 	         * 返回移动终端的类型
 	         * 
 	         * PHONE_TYPE_CDMA 手机制式为CDMA，电信
 	         * PHONE_TYPE_GSM 手机制式为GSM，移动和联通
 	         * PHONE_TYPE_NONE 手机制式未知
 	         */
 	        tm.getPhoneType();
 	        //返回SIM卡提供商的国家代码
 	        tm.getSimCountryIso();
 	        //返回MCC+MNC代码 (SIM卡运营商国家代码和运营商网络代码)(IMSI)
 	        tm.getSimOperator();
 	        tm.getSimOperatorName();
 	        //返回SIM卡的序列号(IMEI)
 	        tm.getSimSerialNumber();
 	       /**
 	         * 返回移动终端
 	         * 
 	         * SIM_STATE_ABSENT SIM卡未找到
 	         * SIM_STATE_NETWORK_LOCKED SIM卡网络被锁定，需要Network PIN解锁
 	         * SIM_STATE_PIN_REQUIRED SIM卡PIN被锁定，需要User PIN解锁
 	         * SIM_STATE_PUK_REQUIRED SIM卡PUK被锁定，需要User PUK解锁
 	         * SIM_STATE_READY SIM卡可用
 	         * SIM_STATE_UNKNOWN SIM卡未知
 	         */
 	        tm.getSimState();
 	        //返回用户唯一标识，比如GSM网络的IMSI编号
 	        tm.getSubscriberId();
 	        //获取语音信箱号码关联的字母标识。 
 	        tm.getVoiceMailAlphaTag();
 	        //返回语音邮件号码
 	        tm.getVoiceMailNumber();
 	        tm.hasIccCard();
 	        //返回手机是否处于漫游状态
 	        tm.isNetworkRoaming();
 	        // tm.listen(PhoneStateListener listener, int events) ;
 	        
 	        //解释：
 	        //IMSI是国际移动用户识别码的简称(International Mobile Subscriber Identity)
 	        //IMSI共有15位，其结构如下：
 	        //MCC+MNC+MIN
 	        //MCC：Mobile Country Code，移动国家码，共3位，中国为460;
 	        //MNC:Mobile NetworkCode，移动网络码，共2位
 	        //在中国，移动的代码为电00和02，联通的代码为01，电信的代码为03
 	        //合起来就是（也是Android手机中APN配置文件中的代码）：
 	        //中国移动：46000 46002
 	        //中国联通：46001
 	        //中国电信：46003
 	        //举例，一个典型的IMSI号码为460030912121001

 	        //IMEI是International Mobile Equipment Identity （国际移动设备标识）的简称
 	        //IMEI由15位数字组成的”电子串号”，它与每台手机一一对应，而且该码是全世界唯一的
 	        //其组成为：
 	        //1. 前6位数(TAC)是”型号核准号码”，一般代表机型
 	        //2. 接着的2位数(FAC)是”最后装配号”，一般代表产地
 	        //3. 之后的6位数(SNR)是”串号”，一般代表生产顺序号
 	        //4. 最后1位数(SP)通常是”0″，为检验码，目前暂备用 	        
		}
	}
	
	// 去电自动录音的实现方法
	// 记得是查询系统日志的方式，从中找到去电过程中的各个状态的关键词
	// http://www.jizhuomi.com/android/example/354.html
	  //DIALING 拨号，对方还未响铃
	 //ACTIVE   对方接通，通话建立
	 //DISCONNECTING 通话断开时
	 //DISCONNECTED  通话已断开，可以认为是挂机了
	
	private int logCount;  
	public class ThreadReadLog extends Thread {
		
		// <uses-permission android:name="android.permission.READ_LOGS"/>
		// 电话外呼 监控
		private final String TAG = ThreadReadLog.class.getSimpleName();
		
		private class CallViewState {    
	        public static final String FORE_GROUND_CALL_STATE = "mForeground";    
	    }    

	    private class CallState {    
	        public static final String DIALING = "DIALING";    
	        public static final String ALERTING = "ALERTING";    
	        public static final String ACTIVE = "ACTIVE";    
	        public static final String IDLE = "IDLE";    
	        public static final String DISCONNECTED = "DISCONNECTED";    
	    }  
	    
		@Override    
	    public void run() {
			String[] catchParams = {"logcat", "InCallScreen *:s"};
			String[] clearParams = {"logcat", "-c"};  
			try {
				Process process=Runtime.getRuntime().exec(catchParams);
				
				InputStream is = process.getInputStream();    
	            BufferedReader reader = new BufferedReader(new InputStreamReader(is));    
	            String line = null;    
	            while ((line=reader.readLine())!=null) {    
	            	logCount++;    
	                //输出所有    
	                Log.v(TAG, line);    
	                    
	                //日志超过512条就清理    
	                if (logCount>512) {    
	                    //清理日志    
	                	
	                    Runtime.getRuntime().exec(clearParams)    
	                        .destroy();//销毁进程，释放资源    
	                    logCount = 0;    
	                    Log.v(TAG, "-----------清理日志---------------");    
	                }        /*---------------------------------前台呼叫-----------------------*/    
	                //空闲    
	                if (line.contains(ThreadReadLog.CallViewState.FORE_GROUND_CALL_STATE)    
	                        && line.contains(ThreadReadLog.CallState.IDLE)) {    
	                    Log.d(TAG, ThreadReadLog.CallState.IDLE);    
	                }    
	                    
	                //正在拨号，等待建立连接，即已拨号，但对方还没有响铃，    
	                if (line.contains(ThreadReadLog.CallViewState.FORE_GROUND_CALL_STATE)    
	                        && line.contains(ThreadReadLog.CallState.DIALING)) {    
	                    Log.d(TAG, ThreadReadLog.CallState.DIALING);    
	                }    
	                    
	                //呼叫对方 正在响铃    
	                if (line.contains(ThreadReadLog.CallViewState.FORE_GROUND_CALL_STATE)    
	                        && line.contains(ThreadReadLog.CallState.ALERTING)) {    
	                    Log.d(TAG, ThreadReadLog.CallState.ALERTING);    
	                }    
	                    
	                //已接通，通话建立    
	                if (line.contains(ThreadReadLog.CallViewState.FORE_GROUND_CALL_STATE)    
	                        && line.contains(ThreadReadLog.CallState.ACTIVE)) {    
	                    Log.d(TAG, ThreadReadLog.CallState.ACTIVE);    
	                }          
	                //断开连接，即挂机    
	                if (line.contains(ThreadReadLog.CallViewState.FORE_GROUND_CALL_STATE)    
	                        && line.contains(ThreadReadLog.CallState.DISCONNECTED)) {    
	                    Log.d(TAG, ThreadReadLog.CallState.DISCONNECTED);    
	                }    
	            }
			} catch (IOException e) {
				e.printStackTrace();
			}  
	    }
		
	}
	
}
