package com.mkyuan.pd.comm.activities;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import com.mkyuan.R;
import com.mkyuan.libs.Log;
import com.mkyuan.pd.BaseActivity;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.os.Bundle;
import android.os.Environment;
import android.view.SurfaceHolder;  
import android.view.SurfaceView; 
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;

public class CameraActivity extends BaseActivity  implements OnClickListener,  SurfaceHolder.Callback  {
	   /** Called when the activity is first created. */  
	@Override  
    public void onCreate(Bundle savedInstanceState) {  
	        super.onCreate(savedInstanceState);  
	        // <uses-permission android:name="android.permission.CAMERA"/>
	        requestWindowFeature(Window.FEATURE_NO_TITLE);  
	        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);  
	        getWindow().setFormat(PixelFormat.TRANSLUCENT);  
	        setContentView(R.layout.activity_comm_camera);  	  
	        layout_CameraView = (LinearLayout) findViewById(R.id.cameraView);
            mCameraView = new CameraView(this);  
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT);  
            layout_CameraView.addView(mCameraView, params);
            

            //设置手机屏幕朝向，一共有7种
            //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);
            //SCREEN_ORIENTATION_BEHIND： 继承Activity堆栈中当前Activity下面的那个Activity的方向
            //SCREEN_ORIENTATION_LANDSCAPE： 横屏(风景照) ，显示时宽度大于高度 
            //SCREEN_ORIENTATION_PORTRAIT： 竖屏 (肖像照) ， 显示时高度大于宽度 
            //SCREEN_ORIENTATION_SENSOR  由重力感应器来决定屏幕的朝向,它取决于用户如何持有设备,当设备被旋转时方向会随之在横屏与竖屏之间变化
            //SCREEN_ORIENTATION_NOSENSOR： 忽略物理感应器——即显示方向与物理感应器无关，不管用户如何旋转设备显示方向都不会随着改变("unspecified"设置除外)
            //SCREEN_ORIENTATION_UNSPECIFIED： 未指定，此为默认值，由Android系统自己选择适当的方向，选择策略视具体设备的配置情况而定，因此不同的设备会有不同的方向选择
            //SCREEN_ORIENTATION_USER： 用户当前的首选方向
            //SurfaceView surface = null;
            //SurfaceHolder holder = surface.getHolder();//获得句柄
            //holder.addCallback(this);//添加回调
            //surfaceview不维护自己的缓冲区，等待屏幕渲染引擎将内容推送到用户面前
            //holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	}
	// --------------------------------------
	// OnClickListener Override
    @Override  
	public void onClick(View v) {  
    	//if (null == mCameraView) {  
    	//} else {  
    	//        mCamera.takePicture(null, null, picture);  
	    //}
	    switchCameraForeBack();
	}  
    
    private android.hardware.Camera openCameraByFacing(int facing) {
    	//android.hardware.Camera
        CameraInfo cameraInfo = new CameraInfo();
        int cameraCount = Camera.getNumberOfCameras();//得到摄像头的个数
        for(int i = 0; i < cameraCount; i++ ) {
        	Camera.getCameraInfo(i, cameraInfo);//得到每一个摄像头的信息
        	if (facing == cameraInfo.facing) {
        		android.hardware.Camera camera = Camera.open(i);//打开当前选中的摄像头
                try {
                	camera.setPreviewDisplay(mCameraView.holder);//通过surfaceview显示取景画面
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                camera.startPreview();//开始预览
                return camera;
        	}
        }
        return null;
    }
    
    private void switchCameraForeBack() {
    	Log.d("switchCameraForeBack");
        int cameraCount = 0;
        
        //mCamera.
        
        CameraInfo cameraInfo = new CameraInfo();
        cameraCount = Camera.getNumberOfCameras();//得到摄像头的个数
        Log.d("switchCameraForeBack camera" + cameraCount);
        for(int i = 0; i < cameraCount; i++ ) {
            Camera.getCameraInfo(i, cameraInfo);//得到每一个摄像头的信息
        	//代表摄像头的方位，CAMERA_FACING_FRONT前置      CAMERA_FACING_BACK后置  
            //if (Camera.CameraInfo.CAMERA_FACING_FRONT == cameraInfo.facing) {
            if (Camera.CameraInfo.CAMERA_FACING_BACK == cameraInfo.facing) {
            	mCamera.stopPreview();//停掉原来摄像头的预览
            	mCamera.release();//释放资源
            	mCamera = null;//取消原来摄像头
            	mCamera = Camera.open(i);//打开当前选中的摄像头
                try {
                	mCamera.setPreviewDisplay(mCameraView.holder);//通过surfaceview显示取景画面
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                mCamera.startPreview();//开始预览
            }
        }
    }
        
	// --------------------------------------
    // SurfaceHolder.Callback Override
	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {		
	}  
	// --------------------------------------
      
	private LinearLayout layout_CameraView = null;
	
    // camera 类  
    private android.hardware.Camera mCamera = null;  
    // 继承surfaceView的自定义view 用于存放照相的图片  
    private CameraView mCameraView = null;  
  
    // 回调用的picture，实现里边的onPictureTaken方法，其中byte[]数组即为照相后获取到的图片信息  
    private Camera.PictureCallback picture = new Camera.PictureCallback() {  
  
        @Override  
        public void onPictureTaken(byte[] data, Camera camera) {  
            // 主要就是将图片转化成drawable，设置为固定区域的背景（展示图片），当然也可以直接在布局文件里放一个surfaceView供使用。
        	saveCameraPhotoData(data);
        }   
    };
    
    private void saveCameraPhotoData(byte[] data) {
        ByteArrayInputStream bais = new ByteArrayInputStream(data);  
        Drawable d = BitmapDrawable.createFromStream(bais, Environment.getExternalStorageDirectory().getAbsolutePath() + "/img.jpeg");  
        layout_CameraView.setBackgroundDrawable(d);  
        try {  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }
    
    //主要的surfaceView，负责展示预览图片，camera的开关  
    class CameraView extends SurfaceView {  
  
        //  
        private SurfaceHolder holder = null;  

        public CameraView(Context context) {  
            super(context);  
            holder = this.getHolder();    
            holder.addCallback(new SurfaceHolder.Callback() {  
  
                @Override  
                public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {  
                    Camera.Parameters parameters = mCamera.getParameters();  
                    //以下注释掉的是设置预览时的图像以及拍照的一些参数  
                    // parameters.setPictureFormat(PixelFormat.JPEG);  
                    // parameters.setPreviewSize(parameters.getPictureSize().width,  
                    // parameters.getPictureSize().height);  
                    // parameters.setFocusMode("auto");  
                    // parameters.setPictureSize(width, height);
                    mCamera.setParameters(parameters);  
                    mCamera.startPreview();  
                }
                
                //mCameraId 是当前使用的 CameraId, 一般前置为1， 后置为 0
                
                @Override  
                public void surfaceCreated(SurfaceHolder holder) {
                	mCamera = openCameraByFacing(Camera.CameraInfo.CAMERA_FACING_BACK);
                	//mCamera = openCameraByFacing(Camera.CameraInfo.CAMERA_FACING_FRONT);
                    //mCamera = Camera.open();    
                    try {  
                    	android.hardware.Camera.Parameters params = mCamera.getParameters();
                    	
                        //设置camera预览的角度，因为默认图片是倾斜90度的  
                        mCamera.setDisplayOrientation(90);  
                        //设置holder主要是用于surfaceView的图片的实时预览，以及获取图片等功能，可以理解为控制camera的操作..  
                        mCamera.setPreviewDisplay(holder);  
                    } catch (IOException e) {  
                        mCamera.release();  
                        mCamera = null;  
                        e.printStackTrace();  
                    }  
  
                }  
  
                @Override  
                public void surfaceDestroyed(SurfaceHolder holder) {  
                    //顾名思义可以看懂  
                    mCamera.stopPreview();  
                    mCamera.release();  
                    mCamera = null;  
                }  
            });  
//          holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);  
        }  
    }
}
