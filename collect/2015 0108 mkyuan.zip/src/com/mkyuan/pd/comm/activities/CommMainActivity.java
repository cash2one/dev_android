package com.mkyuan.pd.comm.activities;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import android.widget.Toast;

import com.mkyuan.GlobleConsts;
import com.mkyuan.R;
import com.mkyuan.RenMai;
import com.mkyuan.data.SharePreference2SDCard;
import com.mkyuan.libs.Log;
import com.mkyuan.md.contact.ContactsCPRunnable;
import com.mkyuan.md.remind.RenmaiRemind;
import com.mkyuan.md.update.AppUpdate;
import com.mkyuan.net.RenmaiClientTest;
import com.mkyuan.pd.AppManager;
import com.mkyuan.pd.BaseFragmentActivity;
import com.mkyuan.pd.comm.adapter.IconPagerAdapter;
import com.mkyuan.pd.comm.view.BaseFragment;
import com.mkyuan.pd.comm.view.ContactsFragment;
import com.mkyuan.pd.comm.view.IView;
import com.mkyuan.pd.comm.view.IconTabPageIndicator;
import com.mkyuan.pd.comm.view.IconTabPageIndicator.OnTabSelectedListener;
import com.mkyuan.pd.remark.view.RemarkFragment;
import com.mkyuan.testing.Test_libs_Log;


public class CommMainActivity extends BaseFragmentActivity implements IView, OnTabSelectedListener {
	
	//public static final int MESSAGE_IMPORT_CONTACTS_START = 10;
	//public static final int MESSAGE_IMPORT_CONTACTS_FINISH = 11;
	public static final int MESSAGE_UPDATE_TITLE = 12;
	
	// 更新下载完成 准备安装
	public static final int MESSAGE_APPUPDATE_DOWNLOAD_PREPARED = 13;
	public static final int MESSAGE_APPUPDATE_RUNINSTALL = 14;
	
	private SharedPreferences mCommPreferences;
	private BroadcastReceiver mReceiver;
	private ViewPager mViewPager;
	private IconTabPageIndicator mIndicator;
	private ProgressDialog mProgress;
	
	private ContactsFragment mContactsFragment;
	private RemarkFragment mRemarkFragment;
	
	private TextView mTitleTextView;
	
	private int mTitleList[] = new int [] {R.string.app_name, R.string.relation_contacts};
	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			/*/
			case MESSAGE_IMPORT_CONTACTS_START:
				if (mProgress == null) {
					mProgress = new ProgressDialog(CommMainActivity.this);
				}
				mProgress.setMessage("import start");
				mProgress.setCancelable(false);
				mProgress.setCanceledOnTouchOutside(false);
				mProgress.show();
				new Thread(new ContactsCPRunnable(CommMainActivity.this)).start();
				break;
			//*/	
			/*/	
			case MESSAGE_IMPORT_CONTACTS_FINISH:
				if (mProgress != null){
					mProgress.dismiss();
					mContactsFragment.refresh();
				}
				break;
            //*/
			case MESSAGE_UPDATE_TITLE:
				mTitleTextView.setText(mTitleList[msg.arg1]);
				break;
			case MESSAGE_APPUPDATE_DOWNLOAD_PREPARED:
				AppUpdate.showInstallUpdateConfirmDialog(CommMainActivity.this);
				break;
			case MESSAGE_APPUPDATE_RUNINSTALL:
				AppUpdate.runInstallUpdate(CommMainActivity.this);
				break;
			default:
				break;
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		AppManager.getAppManager().setMainActivity(this);
		setContentView(R.layout.activity_comm_main);
		initBroadCastReceiver();
		initViews();
		AppManager.mainInitApp(this);
//        mCommPreferences = SharePreference2SDCard.getSDPreferences(this, GlobleConsts.COMM_SD_SHAREPREFERENCES_NAME);
//        if (!mCommPreferences.getBoolean("imported", false)) {
//        	mHandler.sendEmptyMessage(MESSAGE_IMPORT_CONTACTS_START);
//        }		
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		unregisterReceiver(mReceiver);
        AppManager.getAppManager().setMainActivity(null);
		System.gc();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.main, menu);
		//return true;
		menu.add("menu");// 必须创建一项 
		return super.onCreateOptionsMenu(menu);
	}
	
	private PopupWindow mPopMenu = null;
	
	public void closePopMenu(){
		if (null != mPopMenu) {
	    	if (mPopMenu.isShowing()) {
   		        mPopMenu.dismiss();
   		        mPopMenu = null;
	    	} 
		}
	}
	
	// http://www.it165.net/pro/html/201403/10396.html
	private void initPopupMenuWindow(){
		if (null != mPopMenu)
			return;
		LayoutInflater mLayoutInflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		View popmenu_view = mLayoutInflater.inflate(R.layout.view_menu_main, null);
		/*第一个参数弹出显示view  后两个是窗口大小*/
		//mPopupMenu = new PopupWindow(sub_view, LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		mPopMenu = new PopupWindow(popmenu_view, LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		/*设置背景显示*/  
		//mPopupMenu.setBackgroundDrawable(getResources().getDrawable(R.drawable.bg_menu_popup));  
		/*设置 PopWindow 系统动画*/  
		//mPopMenu.setAnimationStyle(R.style.popTopInAnimationStyle);

		/*设置触摸外面时消失*/  
		mPopMenu.setOutsideTouchable(true);  //设置非PopupWindow区域可触摸  
		mPopMenu.setTouchable(true);  //设置PopupWindow可触摸 
		mPopMenu.setFocusable(false); //设置PopupWindow可获得焦点  
		
		//mPopMenu.update();
		
		/** 1.解决再次点击MENU键无反应问题   
	     *  2.sub_view是PopupWindow的子View 
	     */  
		mPopMenu.setOnDismissListener(new OnDismissListener() {
			@Override
			public void onDismiss() {
			}
	    });
		
		Button btnSetting = (Button) popmenu_view.findViewById(R.id.btnmainmenusetting);
		btnSetting.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				CommMainActivity.this.redirectToActivity(SettingActivity.class);
			}});

		Button btnExit = (Button) popmenu_view.findViewById(R.id.btnmainmenuexitapp);
		btnExit.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				AppManager.getAppManager().quitApplication();
			}});
		
	    //popmenu_view.setFocusableInTouchMode(true);
		popmenu_view.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				Log.d("CommMainActivity popview onTouch");
				closePopMenu();
				return false;
			}
		});
	    popmenu_view.setOnKeyListener(new OnKeyListener() {  
	        @Override  
	        public boolean onKey(View v, int keyCode, KeyEvent event) {  
	            if (mPopMenu.isShowing()) {
	            	if (keyCode == KeyEvent.KEYCODE_MENU) {
	            	    mPopMenu.dismiss();// 这里写明模拟menu的PopupWindow退出就行  
	                    return true;  
	            	}
	            	if (keyCode == KeyEvent.KEYCODE_BACK) {
	            	    mPopMenu.dismiss();// 这里写明模拟menu的PopupWindow退出就行  
	                    return true;  
	            	}
	            }  
	            return false;  
	        }  
	    });
	}	
	
	// BaseFragmentActivity 未起作用
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		Log.d("CommMainActivity onTouchEvent");
	    closePopMenu();
 	    return super.onTouchEvent(event);
	}

	@Override  
	public boolean onMenuOpened(int featureId, Menu menu) {
		//return true;
		//*/
		if (mPopMenu == null)
			initPopupMenuWindow();
		if(mPopMenu == null)
			return true;
		if(!mPopMenu.isShowing()){  
		     //最重要的一步：弹出显示   在指定的位置(parent)  最后两个参数 是相对于 x / y 轴的坐标  
		     //mPopMenu.showAtLocation(findViewById(R.id.action_button), Gravity.TOP, 0, 0);
		     mPopMenu.showAsDropDown(findViewById(R.id.action_button));
 		} else {
 			mPopMenu.dismiss();
 		}  		
		return false;// 返回为true 则显示系统menu
		//*/
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.action_settings:
			this.redirectToActivity(SettingActivity.class);
			break;
		case R.id.action_test_log:
			Test_libs_Log.test();
			break;
		case R.id.action_test_server:
			Log.d("test action_test_server");
			RenmaiClientTest.Test();
			break;
		case R.id.action_test_update:
			Log.d("test update");
			//AppUpdate.Test(this);
			//AppUpdate.checkUpdate();
			//RenmaiRemind.Test(this);
			//RemarkManager.Test();
			//ContactsManager.getInstance().Test(this);
			//redirectToActivity(UserLoginActivity.class);
			//TestThreadMessage();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	/*/	
	 @Override
	 public boolean onKeyDown(int keyCode, KeyEvent event) {
		 if (keyCode == KeyEvent.KEYCODE_MENU) {
			 
		 }
		return false;	 
	 }
	//*/ 
	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(getResources().getString(R.string.dialog_confirm_appexit));
		builder.setTitle(getResources().getString(R.string.dialog_title_hint));
		builder.create().show();
	}

	@Override
	public void initViews() {
		// TODO Auto-generated method stub
		mTitleTextView = (TextView) findViewById(R.id.header_title);
		mViewPager = (ViewPager) findViewById(R.id.view_pager);
        mIndicator = (IconTabPageIndicator) findViewById(R.id.indicator);
        List<BaseFragment> fragments = initFragments();
        FragmentAdapter adapter = new FragmentAdapter(fragments, getSupportFragmentManager());
        mViewPager.setAdapter(adapter);
        mIndicator.setOnTabSelectedListener(this);
        mIndicator.setViewPager(mViewPager);
        mIndicator.setVisibility(View.GONE);
        
        ImageView btnmenu = (ImageView)findViewById(R.id.action_button);
        btnmenu.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if (mPopMenu == null) {
					CommMainActivity.this.openOptionsMenu();
				} else {
					if (mPopMenu.isShowing()) {
						mPopMenu.dismiss();
					} else {
						CommMainActivity.this.openOptionsMenu();
					}
				}
				//Toast.makeText(CommMainActivity.this, "menu click", Toast.LENGTH_LONG).show();
			}});
	}

	/**
	 * 初始化广播接收者
	 */
	private void initBroadCastReceiver() {
		mReceiver = new BroadcastReceiver() {
			
			@Override
			public void onReceive(Context context, Intent intent) {
				// TODO Auto-generated method stub
				String action = intent.getAction();
				if (GlobleConsts.ACTION_CONTACTS_DATA_CHANGED.equals(action)) {
					//mContactsFragment.refresh();
				}
				if (GlobleConsts.ACTION_REMARKS_DATA_CHANGED.equals(action)) {
					mRemarkFragment.refresh();
				}
			}
		};
		
	   IntentFilter filter = new IntentFilter();
	   filter.addAction(GlobleConsts.ACTION_CONTACTS_DATA_CHANGED);
	   filter.addAction(GlobleConsts.ACTION_REMARKS_DATA_CHANGED);
	   registerReceiver(mReceiver, filter);
	}
	
	private List<BaseFragment> initFragments() {
		List<BaseFragment> fragments = new ArrayList<BaseFragment>();
		mRemarkFragment = new RemarkFragment();
		mRemarkFragment.setTitle(getResources().getString(R.string.main_tab_remark));
		mRemarkFragment.setIconId(R.drawable.tab_remark_selector);
		fragments.add(mRemarkFragment);
		//暂时隐藏通讯录窗口
		/*mContactsFragment = new ContactsFragment();
		mContactsFragment.setTitle(getResources().getString(R.string.main_tab_contact));
		mContactsFragment.setIconId(R.drawable.tab_contact_selector);
		fragments.add(mContactsFragment);*/
		return fragments;
	}
	
	class FragmentAdapter extends FragmentPagerAdapter implements IconPagerAdapter {
        private List<BaseFragment> mFragments;

        public FragmentAdapter(List<BaseFragment> fragments, FragmentManager fm) {
            super(fm);
            mFragments = fragments;
        }

        @Override
        public Fragment getItem(int i) {
            return mFragments.get(i);
        }

        public int getIconResId(int index) {
            return mFragments.get(index).getIconId();
        }

        @Override
        public int getCount() {
            return mFragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragments.get(position).getTitle();
        }
    }

	@Override
	public void onTabSelected(int position) {
		// TODO Auto-generated method stub
		//mTitleTextView.setText(mTitleList[position]);
		Message msg = new Message();
		msg.what = MESSAGE_UPDATE_TITLE;
		msg.arg1 = position;
		mHandler.sendMessageDelayed(msg, 250);
	}

	public void notifyUpdateRunInstall(){
		Message msg = new Message();
		msg.what = MESSAGE_APPUPDATE_RUNINSTALL;
		mHandler.sendMessage(msg);
	}
	
	public void notifyUpdateDownloadPrepared(String localfileurl){
		Message msg = new Message();
		msg.what = MESSAGE_APPUPDATE_DOWNLOAD_PREPARED;
		msg.obj = localfileurl;
		mHandler.sendMessage(msg);
	}
}
