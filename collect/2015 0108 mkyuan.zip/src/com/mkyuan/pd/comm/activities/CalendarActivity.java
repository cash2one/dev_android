package com.mkyuan.pd.comm.activities;

import java.util.ArrayList;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.mkyuan.libs.Log;
import com.mkyuan.pd.BaseActivity;
import com.mkyuan.pd.comm.view.ContactSelectItemView;
import com.mkyuan.widget.VerticalCalendar;
import com.mkyuan.R;

public class CalendarActivity extends BaseActivity  {
	
	BaseAdapter mCalendarListAdapter = null;
	
	// 自定义ScrollView
	//  ListView 体验各种纵向滑动的需求
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        //setContentView(R.layout.activity_calendar);
        mTestMyDraw = new TestMyDrawView(this);
        setContentView(mTestMyDraw);
        
        //VerticalCalendar lst = (VerticalCalendar) findViewById(R.id.lstCalendar);
        //mCalendarListAdapter = new CalendarListViewAdapter();
        //lst.setAdapter(mCalendarListAdapter);
        //lst.setSelection(5000);
        //lst.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_INSET);
	}
	
	/*
        <ListView
            android:id="@+id/lstCalendar"
            android:layout_height="match_parent"
            android:scrollbars="none"
            android:layout_width="match_parent">
        </ListView>
    */
	TestMyDrawView mTestMyDraw = null;
	private class TestMyDrawView extends View {

		public TestMyDrawView(Context context) {
			super(context);
		}

	    @Override
		protected void onLayout(boolean changed, int l, int t, int r, int b){
			super.onLayout(changed, l, t, r, b);
			Log.d("CalendarActivity ------- TestMyDrawView onLayout:" + getMeasuredWidth() + " x " + getMeasuredHeight());
			// 看来 onLayout 是可以用的
		}
		
	    int mDrawColor = 0xFFFF0000;
	    
		  @Override
		protected void onDraw(Canvas canvas) {
			Log.d("CalendarActivity ------- TestMyDrawView onDraw:" + getMeasuredWidth() + " x " + getMeasuredHeight());
		    super.onDraw(canvas);
		    Paint p = new Paint();
		    //p.setColor(Color.RED);
		    p.setColor(mDrawColor);		    
		    canvas.drawRect(0, 0, 25, 25, p);
		}		

	    @Override
	    public boolean dispatchTouchEvent(MotionEvent ev) {
	        boolean handled = false;
	        // 重绘请求
	        mDrawColor = mDrawColor + 100;
	        postInvalidate();
	        return handled;
	    }
	    
	    @Override
	    public boolean hasTransientState() {
	    	return false;
	    }
	    
	    @Override
	    public boolean dispatchUnhandledMove(View focused, int direction) {
	    	return false;
	    }

	    @Override
	    public void clearFocus() {
	    	
	    }
	    	   
	   @Override
	   public boolean hasFocus() {
		   return false;
	   }
	   
	   @Override
	   public boolean hasFocusable() {
		   return false;
	   }
	   
	  @Override
	  public void addFocusables(ArrayList<View> views, int direction, int focusableMode) {		  
	  }

	   @Override
	   public void dispatchWindowFocusChanged(boolean hasFocus) {		   
	   }
	   
	   @Override
	   public void addTouchables(ArrayList<View> views) {		   
	   }

	     @Override
	     public void dispatchDisplayHint(int hint) {		   
	     }

	    @Override
	    protected void dispatchVisibilityChanged(View changedView, int visibility) {
	        super.dispatchVisibilityChanged(changedView, visibility);
	    }

	    @Override
	    public void dispatchWindowVisibilityChanged(int visibility) {
	        super.dispatchWindowVisibilityChanged(visibility);
	    }

	    @Override
	    public void dispatchConfigurationChanged(Configuration newConfig) {
	        super.dispatchConfigurationChanged(newConfig);
	    }

	    @Override
	    public boolean dispatchDragEvent(DragEvent event) {
	    	return false;
	    }

	    @Override
	    public boolean dispatchKeyEventPreIme(KeyEvent event) {
	    	return false;
	    }
	    
	    @Override
	    public boolean dispatchKeyEvent(KeyEvent event) {
		    return false;
	    }

	    @Override
	    public boolean dispatchKeyShortcutEvent(KeyEvent event) {
	    	return false;
	    }

	    @Override
	    public boolean dispatchTrackballEvent(MotionEvent event) {
	    	return false;
	    }

	    @SuppressWarnings({"ConstantConditions"})
	    @Override
	    protected boolean dispatchHoverEvent(MotionEvent event) {
	    	return false;
	    }

	    @Override
	    protected boolean dispatchGenericPointerEvent(MotionEvent event) {
	    	return false;
	    }

	    @Override
	    protected boolean dispatchGenericFocusedEvent(MotionEvent event) {
	    	return false;
	    }
	}
	
	public class CalendarListViewAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return 10000;
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = null;
			if (convertView == null) {
				view = (LinearLayout) LayoutInflater.from(CalendarActivity.this).inflate(R.layout.calendar_cell_item, null);
			} else {
				view = convertView; 
			}			
			TextView txt = (TextView)view.findViewById(R.id.text_calendar_cell_date);
			if  (null != txt) {
			    txt.setText("" + position);
			}
			return view;
		}
	}	
}
