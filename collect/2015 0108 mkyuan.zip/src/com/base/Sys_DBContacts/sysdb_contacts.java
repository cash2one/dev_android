package com.base.Sys_DBContacts;

import java.util.HashMap;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDoneException;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.net.Uri.Builder;
import android.provider.Contacts;
import android.provider.ContactsContract;
import android.provider.Contacts.ContactMethodsColumns;

/*从Android 2.0 SDK开始有关联系人provider的类变成了ContactsContract，
 * 虽然老的android.provider.Contacts能用，但是在SDK中标记为为deprecated
 * 将被放弃不推荐的方法，而从Android 2.0及API Level为5开始新增了
 * android.provider.ContactsContract来代替原来的方法。
ContactsContract的子类ContactsContract.Contacts是一张表，
代表了所有联系人的统计信息。比如联系人ID(—ID),查询键（LOOKUP_KEY）,联系人的姓名(DISPLAY_NAME_PRIMARY),
头像的id([url=]PHOTO_ID[/url])以及群组的id等等
*/
public class sysdb_contacts {
	
	private Context mcontext; 
	sysdb_contacts(Context context){
		mcontext = context;
	}
	
	public void initContacts1(){
     	Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
		Cursor cursor = mcontext.getContentResolver().query(uri, new String[] {
				ContactsContract.CommonDataKinds.Phone._ID,
				ContactsContract.CommonDataKinds.Phone.DATA_VERSION, //???
				ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY, 
				//ContactsContract.CommonDataKinds.Email.DISPLAY_NAME,
				ContactsContract.CommonDataKinds.Phone.SORT_KEY_PRIMARY}, 
				null, 
				null, 
				ContactsContract.CommonDataKinds.Phone.SORT_KEY_PRIMARY
				);
		if (cursor.moveToFirst()) {
			do {
				String name = cursor.getString(0);
//				String sortKey = getSortKey(cursor.getString(1));
//				Contact contact = new Contact();
//				contact.setName(name);
//				contact.setSortKey(sortKey);
//				contacts.add(contact);
			} while (cursor.moveToNext());
		}
	}
	
	public void initContacts2(){

	      int nameIndex=-1;
	      String name;
	      String number;
          int columnIndex = -1;
	      
	      ContentResolver cr= mcontext.getContentResolver(); 

	      Cursor curContact = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null,null); 

	      while(curContact.moveToNext()){         
	         nameIndex=curContact.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME); 
	         name=curContact.getString(nameIndex); 
	         //得到电话号码 

	         number="";  //得到名字
	         columnIndex =curContact.getColumnIndex(ContactsContract.Contacts._ID);
			if ( columnIndex >= 0 ) {
		         String contactId = curContact.getString(columnIndex); // 获取联系人的ID号，在SQLite中的数据库ID
		         Cursor curphone = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,  
	        		     ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId, null, null);  
                 while (curphone.moveToNext()) {  
	              String strPhoneNumber = curphone.getString(curphone.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)); // 手机号码字段联系人可能不止一个  
	              number += strPhoneNumber+"\n";  
	           }  
	           curphone.close();
	         }	         
//	         contacts=new  HashMap<String,String>(); 
//	         //放入Map 
//	         contacts.put("name", name); 
//	         contacts.put("number", number); 
	         } 
	         curContact.close(); 
	}
	

	public void initContacts3(){

	      ContentResolver cr= mcontext.getContentResolver(); 
	      Cursor curContact = cr.query(Contacts.People.CONTENT_URI, null, null, null,null); 

	}
}
