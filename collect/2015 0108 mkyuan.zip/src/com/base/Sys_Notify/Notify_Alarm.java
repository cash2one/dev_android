package com.base.Sys_Notify;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

public class Notify_Alarm {

	// 在Android上常用的定时器有两种，一种是Java.util.Timer，一种就是系统的AlarmService
	// http://blog.sina.com.cn/s/blog_4b2e0e610100ylgv.html
	//一、采用Handler与线程的sleep(long )方法
	//二、采用Handler的postDelayed(Runnable, long) 方法
	//三、采用Handler与timer及TimerTask结合的方法。
    public void addTimer(){
    	
    }
    
    public void addTimer1(){
    	//一  采用Handle与线程的sleep(long )方法
    	// 1.定义一个Handler类，用于处理接受到的Message.
    	// 2.新建一个实现Runnable接口的线程类
    	// 3.在需要启动线程的地方加入下面语句：
    	// new Thread(new MyThread()).start();
    	// 4.启动线程后，线程每10s发送一次消息
      Handler handler = new Handler() {
    	 public void handleMessage(Message msg) {
            // 要做的事情
         	super.handleMessage(msg);
    	}
      };
    } 	
    

    public void addTimer2(){
    	//二、采用Handler的postDelayed(Runnable, long)
    	// 1. Handler handler=new Handler();
    	 Handler handler=new Handler();
    	 Runnable runnable=new Runnable(){
    	 @Override
    	 public void run() {
        	 //要做的事情
        	 //handler.postDelayed(this, 2000);
    	 }
    	 };
    	// 2.启动计时器：
    	// handler.postDelayed(runnable, 2000);//每两秒执行一次runnable
    	// 3.停止计时器：
    	// handler.removeCallbacks(runnable);
    }
    

    public void addTimer3(){
    	// 采用Handler与timer及TimerTask结合的方法
    	//1.定义定时器、定时器任务及Handler句柄
    	//private final Timer timer = new Timer();
    	//private TimerTask task;
    	// Handler handler = new Handler() {}
    	// 2.初始化计时器任务
    	TimerTask task = new TimerTask() {
    		@Override
    		public void run() {
    		// TODO Auto-generated method stub
    		Message message = new Message();
    		message.what = 1;
    		//handler.sendMessage(message);
    		}
    	};
    	//3.启动定时器
    	Timer timer = new Timer();
    	timer.schedule(task, 2000, 2000);
    }
    
    public void addJavaTimer(){
    	// 在onStart()创创建Timer，每5秒更新一次计数器，并启动
    	//Java.util.Timer
    	Timer mTimer = new Timer();          
        mTimer.schedule(new TimerTask() {              
            @Override  
            public void run() {   
            	//++mCount;   
                //mHandler.sendEmptyMessage(0);                  
            }   
        }, 5*1000, 5*1000);   
    }
    public static class alarmreceiver extends BroadcastReceiver{  
    	  
        @Override  
        public void onReceive(Context context, Intent intent) {  
            // TODO Auto-generated method stub  
            if(intent.getAction().equals("short")){  
                Toast.makeText(context, "short alarm", Toast.LENGTH_LONG).show();  
            }else{  
            	Toast.makeText(context, "repeating alarm", Toast.LENGTH_LONG).show();  
            }  
        }  
    }
        
    public void addTimerByAlarmService(Context context ){
    	// http://blog.csdn.net/wanglang3081/article/details/7898674
    	AlarmManager am = (AlarmManager)context.getSystemService(context.ALARM_SERVICE);
    	//开始时间  
        long firstTime = SystemClock.elapsedRealtime();  
        
        //mAlarmSender = PendingIntent.getService(AlarmService.this, 0, new Intent(AlarmService.this, AlarmService_Service.class), 0); 
        
    	 Intent intent =new Intent(context, alarmreceiver.class);  	    
    	 intent.setAction("short");  
    	PendingIntent sender=  PendingIntent.getBroadcast(context, 0, intent, 0);  
    	am.setRepeating(AlarmManager.ELAPSED_REALTIME, firstTime, 5*1000, sender);
        // 使用WAKEUP才能保证自己想要的定时器一直工作，但是肯定会引起耗电量的增加
    	am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firstTime, 5*1000, sender);
    	
    	//设定一个五秒后的时间  
        Calendar calendar=Calendar.getInstance();  
        calendar.setTimeInMillis(System.currentTimeMillis());  
        calendar.add(Calendar.SECOND, 5); 
    	am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), sender);  
    }
    /*http://www.cnblogs.com/shaocm/archive/2013/01/16/2862434.html
     * http://www.cnblogs.com/playing/archive/2011/03/24/1993583.html
    做惯了java，net，定时器就会想到timer，由于Android支持java开发所以可以使用java中的Timer。
    但Android提供了它特有的实现方式：android.os.Handler 中的 postXXX 和sendXXX 等方法，
    至于倒计时：android.os.CountDownTimer 使用起来更方便
    更多详细实现参考：http://www.cnblogs.com/playing/archive/2011/03/24/1993583.html
    以下是Hanler+Runnable  实现地图位置的实时更新时的部分代码 
    复制代码
    //创建一个Handler
    */
    public void addTimerTest()
    {
            final Handler handler = new Handler();            
            //创建一个Runnable
            Runnable task = new Runnable() {  
          
                public void run() {                 
                        handler.postDelayed(this, 30000);
                        //Log.d(tag, "延迟30秒执行线程");    
                        try {
                           //获取服务器上的位置信息 更新坐标
                            //HashMap<String,Integer> hashmap = new HashMap<String,Integer>();
                        	//List<APKGPSInfo> templist=com.comm.GPSDataHanler.GetGPSInfoList(user.getID(), 1, "", hashmap);//获取点集合                       
                        	//List<OverlayItem>  listitem=GetItemList(templist);    //获取点集合                            
                        	//OverItemT overitem = new OverItemT(marker,3,listitem);//生成覆盖物图层ItemizedOverlay
                        	//mMapView.getOverlays().clear();//清除覆盖物                      
                        	//mMapView.getOverlays().add(overitem); // 添加覆盖物 ItemizedOverlay实例到mMapView                        
                        	//mMapView.postInvalidate();//刷新地图界面 如何不执行该行 会出现位置无法自动更新 的问题
                          
                        } catch (Exception e) {                        
                            e.printStackTrace();
                        }            
                }  
            };  
            handler.post(task);//启动定时器
    //复制代码   
    }
    
    public class AlarmReceiver234 extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
        	// public class AlarmActivity extends Activity 
            //Intent i=new Intent(context, AlarmActivity.class);
            //i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        	 // context.startActivity(i);
        }
    }
    
    public void addAlarm(Context context)
    {
    	addAlarm2(context);
    }
    
    public void addAlarm1(Context context)
    {
       AlarmManager am = (AlarmManager)context.getSystemService(context.ALARM_SERVICE);
       long firstTime=SystemClock.elapsedRealtime();  
       //am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firstTime, 5*1000, sender);
    }
    
    /*
     * http://www.cnblogs.com/linjiqin/archive/2011/02/26/1966065.html 手机闹钟
     * <!-- android:process=":remote": 新开一个进程 -->
    	// 除了权限 还需要 一个  <receiver android:name=".AlarmReceiver" android:process=":remote"/>
     public class AlarmReceiver extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent i=new Intent(context, AlarmActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
      }
  }
     * */
    public void addAlarm2(Context context)
    {
    	// 除了权限 还需要 一个  <receiver android:name=".AlarmReceiver" android:process=":remote"/>
      Intent intent =new Intent(context, alarmreceiver.class);  
      intent.setAction("short");  
      PendingIntent sender= PendingIntent.getBroadcast(context, 0, intent, 0);  
    // http://blog.csdn.net/wanglang3081/article/details/7898578
    //mAlarmSender = PendingIntent.getService(AlarmService.this,0, new Intent(AlarmService.this, AlarmService_Service.class), 0);  
      //NotificationManager notifymgr = (NotificationManager)context.getSystemService(context.NOTIFICATION_SERVICE);  
      //Notification notification = new Notification(0,  "",  System.currentTimeMillis());
    
      //PendingIntent contentIntent = PendingIntent.getActivity(context, 0,  new Intent(context, alarmreceiver.class), 0);  
      //notification.setLatestEventInfo(context, "",  "", contentIntent);
    
    //notification.notify("2345", notification);      
    //设定一个五秒后的时间  
      //Calendar calendar=Calendar.getInstance();  
    //calendar.setTimeInMillis(System.currentTimeMillis());  
    //calendar.add(Calendar.SECOND, 5);  
      
      AlarmManager alarm=(AlarmManager)context.getSystemService(context.ALARM_SERVICE);  
      //alarm.set(AlarmManager.RTC_WAKEUP,  calendar.getTimeInMillis(), sender);
      long firstime=SystemClock.elapsedRealtime();  
      //alarm.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firstime, 5*1000, sender);
      alarm.setRepeating(AlarmManager.ELAPSED_REALTIME, firstime, 5*1000, sender);
      //或者以下面方式简化  
      alarm.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+5*1000, sender);  
      Toast.makeText(context, "五秒后alarm开启", Toast.LENGTH_LONG).show();  
    	
    }
}
