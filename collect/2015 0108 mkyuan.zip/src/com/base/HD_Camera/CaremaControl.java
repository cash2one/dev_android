package com.base.HD_Camera;

/*//
 * http://blog.csdn.net/wwj_748/article/details/8927784
  * <uses-permission android:name="android.permission.CAMERA" />  
//*/
import android.hardware.Camera;  
import android.hardware.Camera.PictureCallback;  
import android.os.Bundle;

public class CaremaControl {
	
	private Camera camera;  
    private Camera.Parameters parameters = null;  
    
  public void launchCarema(){
	// 拍照  
      camera.takePicture(null, null, new MyPictureCallback());  
  }
  
  private final class MyPictureCallback implements PictureCallback {
	@Override
	public void onPictureTaken(byte[] data, Camera camera) {
		// TODO Auto-generated method stub
		try {
		/*//
        bundle = new Bundle();  
        bundle.putByteArray("bytes", data); //将图片字节数据保存在bundle当中，实现数据交换  
        saveToSDCard(data); // 保存图片到sd卡中  
        Toast.makeText(getApplicationContext(), R.string.success, Toast.LENGTH_SHORT).show();
        //*/
        camera.startPreview(); // 拍完照后，重新开始预览  
    } catch (Exception e) {  
        e.printStackTrace();  
    }  
	}  
  }
}
