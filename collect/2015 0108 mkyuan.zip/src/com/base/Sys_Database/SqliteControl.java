package com.base.Sys_Database;

import java.io.File;

import android.database.Cursor;  
import android.database.sqlite.SQLiteDatabase;  
import android.database.sqlite.SQLiteOpenHelper;

public class SqliteControl {
	
	 private SQLiteDatabase sqlitedb;
	 private SQLiteOpenHelper  myOpenHelper;
	 
  public void testSaveSqliteToSDCard(){
	//[1]--如果是在默认的路径下创建数据库，那么实例化sqlitedb的操作如下  
     // sqlitedb = myOpenHelper.getWritableDatabase(); //实例化数据库  
        
      //[2]--如果是在SD卡中创建数据库，那么实例化sqlitedb的操作如下
	  File file;
	  String filePath = "";
      //sqlitedb = SQLiteDatabase.openOrCreateDatabase(file, null);
	  try {
	      sqlitedb = SQLiteDatabase.openOrCreateDatabase(filePath, null);
	  } catch (Exception e){
		  
	  } finally {
		  sqlitedb.close();
	  };
  }
}
