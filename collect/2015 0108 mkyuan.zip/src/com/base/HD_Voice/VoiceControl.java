package com.base.HD_Voice;

public class VoiceControl {

}
