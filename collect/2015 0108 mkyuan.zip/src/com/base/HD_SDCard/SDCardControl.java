package com.base.HD_SDCard;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import android.content.Context;
import android.os.Environment;

public class SDCardControl {
	/*//
	  <!-- 在SDCard中创建与删除文件权限 -->
      <uses-permission android:name="android.permission.MOUNT_UNMOUNT_FILESYSTEMS"/>
      <!-- 往SDCard写入数据权限 -->
     <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
     （注意通过getExternalStorageDirectory方法获取SDCard的文件路径）
     写入数据前判断sdcard是否存在于手机上，是否有写保护
     if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
     
     接着我们在使用SDcard进行读写的时候 会用到Environment类下面的几个静态方法  
   1: getDataDirectory()  获取到Androi中的data数据目录
   2:getDownloadCacheDirectory()  获取到下载的缓存目录
   3:getExternalStorageDirectory()  获取到外部存储的目录 一般指SDcard
   4:getExternalStorageState() 获取外部设置的当前状态 一般指SDcard, 
         android系统中对于外部设置的状态，我们比较常用的应该是 MEDIA_MOUNTED（SDcard存在并且可以进行读写）  MEDIA_MOUNTED_READ_ONLY (SDcard存在，只可以进行读操作)  当然还有其他的一些状态，可以在文档中进行查找到  
    5:getRootDirectory()  获取到Android Root路径
   6:isExternalStorageEmulated() 返回Boolean值判断外部设置是否有效
   7:isExternalStorageRemovable()  返回Boolean值，判断外部设置是否可以移除
	//*/
   public void WriteFile(){
	   
   }
   
   /**
   * 读取文件的内容
   * @param filename 文件名称
   * @return
   * @throws Exception
   //*/
   public String readFile(Context context, String filename) throws Exception
   {
   //获得输入流
   FileInputStream inStream = context.openFileInput(filename);
   //new一个缓冲区
   byte[] buffer = new byte[1024];
   int len = 0;
   //使用ByteArrayOutputStream类来处理输出流
   ByteArrayOutputStream outStream = new ByteArrayOutputStream();
   while( (len = inStream.read(buffer))!= -1)
   {
   //写入数据
   outStream.write(buffer, 0, len);
   }
   //得到文件的二进制数据
   byte[] data = outStream.toByteArray();
   //关闭流
   outStream.close();
   inStream.close();
   return new String(data);
   }
   
   
   /**
   * 以默认私有方式保存文件内容至SDCard中
   * @param filename
   * @param content
   * @throws Exception
   //*/
   public void saveToSDCard(String filename, String content) throws Exception
   {
   //通过getExternalStorageDirectory方法获取SDCard的文件路径
   File file = new File(Environment.getExternalStorageDirectory(), filename);
   //获取输出流
   FileOutputStream outStream = new FileOutputStream(file);
   outStream.write(content.getBytes());
   outStream.close();
   }
   
   /**
   * 以默认私有方式保存文件内容，存放在手机存储空间中
   * @param filename
   * @param content
   * @throws Exception
   //*/
   public void save(Context context, String filename, String content) throws Exception
   {
   //
   FileOutputStream outStream = context.openFileOutput(filename, Context.MODE_PRIVATE);
   outStream.write(content.getBytes());
   outStream.close();
   }
   
   /**
   * 以追加的方式保存文件内容
   * @param filename 文件名称
   * @param content 文件内容
   * @throws Exception
   //*/
   public void saveAppend(Context context, String filename, String content) throws Exception
   {
   FileOutputStream outStream = context.openFileOutput(filename, Context.MODE_APPEND);
   outStream.write(content.getBytes());
   outStream.close();
   }   
   
   /**
   * 以允许其他应用从该文件中读取内容的方式保存文件(Context.MODE_WORLD_READABLE)
   * @param filename 文件名称
   * @param content 文件内容
   * @throws Exception
   */
   public void saveReadable(Context context, String filename, String content) throws Exception
   {
   FileOutputStream outStream = context.openFileOutput(filename, Context.MODE_WORLD_READABLE);
   outStream.write(content.getBytes());
   outStream.close();
   }
   /**
   * 以允许其他应用往该文件写入内容的方式保存文件
   * @param filename 文件名称
   * @param content 文件内容
   * @throws Exception
   */
   public void saveWriteable(Context context, String filename, String content) throws Exception
   {
   FileOutputStream outStream = context.openFileOutput(filename, Context.MODE_WORLD_WRITEABLE);
   outStream.write(content.getBytes());
   outStream.close();
   }
   /**
   * 以允许其他应用对该文件读和写的方式保存文件(MODE_WORLD_READABLE与MODE_WORLD_WRITEABLE)
   * @param filename 文件名称
   * @param content 文件内容
   * @throws Exception
   */
   public void saveRW(Context context, String filename, String content) throws Exception
   {
   FileOutputStream outStream = context.openFileOutput(filename,
   Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE);
   //Context.MODE_WORLD_READABLE(1) + Context.MODE_WORLD_WRITEABLE(2),其实可用3替代
   outStream.write(content.getBytes());
   outStream.close();
   }
}
