package com.base.Sys_Security;

import java.lang.reflect.Method;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;     
import android.os.Handler;     
import android.os.Message; 
import android.os.RemoteException;
import android.telephony.PhoneStateListener;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
//import com.android.internal.telephony.ITelephony; 

public class PhoneControl {
	/*
    // 拦截电话
	// 拦截短信
	//  <uses-permission android:name="android.permission.READ_PHONE_STATE" />       
     <uses-permission android:name="android.permission.CALL_PHONE" />       
     <uses-permission android:name="android.permission.MODIFY_PHONE_STATE" />  	 
	//*/
	 private final static int OP_REGISTER = 100;     
	 private final static int OP_CANCEL = 200;     
	      
	 private final static String BLOCKED_NUMBER = "1892501xxxx";//要拦截的号码     
	 //占线时转移，这里13800000000是空号，所以会提示所拨的号码为空号     
	    private final String ENABLE_SERVICE = "tel:**67*13800000000%23";     
	    //占线时转移     
	    private final String DISABLE_SERVICE = "tel:%23%2367%23";     
	    
	 private IncomingCallReceiver mReceiver;     
	    //private ITelephony iTelephony;     
	    private AudioManager mAudioManager;     
	    
	    public void beginListen(Context context){
	    	//打开监听电话功能     
	        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);     
	        tm.listen(new TeleListener(),  PhoneStateListener.LISTEN_CALL_STATE); 
	        
	        IntentFilter mIntentFilter = new IntentFilter();   
	        //拦截电话   
	        mIntentFilter.addAction("android.intent.action.PHONE_STATE");   
	        //拦截短信   
	        mIntentFilter.addAction("android.provider.Telephony.SMS_RECEIVED");
	        
	        mReceiver = new IncomingCallReceiver();   
	      //注册BroadcastReceiver   
	        context.registerReceiver(mReceiver, mIntentFilter);    
	        mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);   
	        //利用反射获取隐藏的endcall方法   
	        TelephonyManager mTelephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
	        
	        try {   
	            Method getITelephonyMethod = TelephonyManager.class.getDeclaredMethod("getITelephony", (Class[]) null);   
	            getITelephonyMethod.setAccessible(true);   
	           // mITelephony = (ITelephony) getITelephonyMethod.invoke(mTelephonyManager, (Object[]) null);   
	        } catch (Exception e) {   
	            e.printStackTrace();   
	        }   
	    }
	    class TeleListener extends PhoneStateListener {     
	        @Override    
	        public void onCallStateChanged(int state, String incomingNumber) {     
	            super.onCallStateChanged(state, incomingNumber);     
	            switch (state) {     
	            case TelephonyManager.CALL_STATE_IDLE: {     
	                break;     
	            }     
	            case TelephonyManager.CALL_STATE_OFFHOOK: {     
	                break;     
	            }     
	            case TelephonyManager.CALL_STATE_RINGING: {     
	                try {     
	                    //iTelephony.endCall();                         
	                } catch (Exception e1) {     
	                    // TODO Auto-generated catch block     
	                    e1.printStackTrace();     
	                }                     
	                break;     
	            }     
	            default:     
	                break;     
	            }     
	        }     
	    }

		  public final static SmsMessage[] getMessagesFromIntent(Intent intent) {   
		        Object[] messages = (Object[]) intent.getSerializableExtra("pdus");   
		        byte[][] pduObjs = new byte[messages.length][];   
		        for (int i = 0; i < messages.length; i++) {   
		            pduObjs[i] = (byte[]) messages[i];   
		        }   
		           
		        byte[][] pdus = new byte[pduObjs.length][];   
		        int pduCount = pdus.length;   
		        SmsMessage[] msgs = new SmsMessage[pduCount];   
		           
		        for (int i = 0; i < pduCount; i++) {   
		            pdus[i] = pduObjs[i];   
		            msgs[i] = SmsMessage.createFromPdu(pdus[i]);   
		        }   
		           
		        return msgs;   
		    }   

		  private Handler mHandler = new Handler() {   
		        public void handleMessage(Message response) {   
		            int what = response.what;              
		            switch(what) {   
		                case OP_REGISTER:{   
		                    Intent i = new Intent(Intent.ACTION_CALL);   
		                    i.setData(Uri.parse(ENABLE_SERVICE));   
		                    //startActivity(i);   
		                    break;   
		                }   
		                case OP_CANCEL:{   
		                    Intent i = new Intent(Intent.ACTION_CALL);   
		                    i.setData(Uri.parse(DISABLE_SERVICE));   
		                    //startActivity(i);   
		                    break;   
		                }   
		            }   
		        }   
		    };   
		    
	    private class IncomingCallReceiver extends BroadcastReceiver{     
	    	  @Override    
	    	  public void onReceive(Context context, Intent intent) {
	    		  
	    		  String action = intent.getAction();   
	    		  if("android.intent.action.PHONE_STATE".equals(action)){//拦截电话   
	    			  
	    		  }
	    		  if("android.provider.Telephony.SMS_RECEIVED".equals(action)){//拦截短信   
	                  SmsMessage sms = getMessagesFromIntent(intent)[0];   
	                  String number = sms.getOriginatingAddress();   
	    		  }
	    	   String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);     
	    	   String number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);     
	    	             
	    	         if(state.equalsIgnoreCase(TelephonyManager.EXTRA_STATE_RINGING)){//电话正在响铃               
	    	          if(number.equals(BLOCKED_NUMBER)){//拦截指定的电话号码     
	    	           //先静音处理     
	    	           mAudioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);     
	    	           try {     
	    	            //挂断电话     
	    	      //iTelephony.endCall();     
	    	     //} catch (RemoteException e) {     
	    	     } catch (Exception e) {
	    	      e.printStackTrace();     
	    	     }     
	    	          
	    	     //再恢复正常铃声     
	    	                 mAudioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);     
	    	          }     
	    	         }     
	    	  }     
	    }
}
