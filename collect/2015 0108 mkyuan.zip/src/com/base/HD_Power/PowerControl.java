package com.base.HD_Power;

public class PowerControl {

}
