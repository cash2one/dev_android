package com.base.HD_RomMobile;

import android.content.Context;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.os.*;

public class sys_device {
	
	// http://blog.csdn.net/dinglin_87/article/details/7489926
   public String getDeviceID(Context context){
	   return "";
   }
   
   public String getAndroid_id(Context context){
   	return  Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);
  }
   
   public String getMacAddress(Context context){
	   return "";
  }
   
   public  String getSerialNumber(Context context){
	   // android.os.Build.SERIAL
	   return "";
   }
   public  String getSimSerialNumber(Context context){
	   // //获取手机SIM卡的序列号
	   TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
	   if (tm != null) {
		   context.getSystemService(context.TELEPHONY_SERVICE);
		   return tm.getSimSerialNumber();
	   } else {
		   return "";
	   }
   }
   
   public String getDeviceInfo(Context context){
	   // 手机型号
	   String info = "";
	   info = Build.MODEL; // MT15i
	   info = Build.MANUFACTURER; // Sony Ericsson HUAWEI	   
	   return info;
   }
   
   public String getPhoneNo(Context context){
	   /*//
	   // 手机号 139XXXX XXXX 一般情况获取不到
	   // 以上做法有可能获取sim卡号，但是现在最起码在电信手机卡上获取不到
	   //  (有些手机号无法获取，是因为运营商在SIM中没有写入手机号)
	   // 发短信 获取手机号
	   //*/
	   TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
	   if (tm != null) {
		   context.getSystemService(context.TELEPHONY_SERVICE);
		   // 没装 sim 卡返回 NULL
		   return tm.getLine1Number(); 
	   } else {
		   return "";
	   }
   }

   public String getPhoneNoBySMS(Context context){
	   return "";
   }
   public String getUUID(Context context){
	   //  Installtion ID : UUID
	   // 有另外一种方式解决，就是使用UUID，该方法无需访问设备的资源，也跟设备类型无关。
	   // 这种方式是通过在程序安装后第一次运行后生成一个ID实现的，但该方式跟设备唯一标识不一样
	   // 它会因为不同的应用程序而产生不同的ID，而不是设备唯一ID
	   return "";   
	}   

   public String getIMSI(Context context){
	    // 得到用户Id
	   TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
	   if (tm != null) {
		   context.getSystemService(context.TELEPHONY_SERVICE);
		   return tm.getSubscriberId();
	   } else {
		   return "";
	   }
   }
   
   public String getIMEI(Context context){
	   // android.os.SystemProperties的标签被打上@hide了，
	   // 所以sdk中并不会存在。如果需要使用，需要有android的source code支持
	   //return android.os.SystemProperties.get(android.telephony.TelephonyProperties.PROPERTY_IMSI); ;
	   //TelephonyManager.getDeviceId();
	   // 需要权限 ???
	   //<!--允许读取电话状态SIM的权限-->
	   //<uses-permission android:name="android.permission.READ_PHONE_STATE" />
	   TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
	   //String imei = "";
	   if (tm != null) {
		   context.getSystemService(context.TELEPHONY_SERVICE);
		   //String imsi = tm.getSubscriberId();
		   // //获取智能设备唯一编号
		   return tm.getDeviceId();
	   } else {
		   return "";
	   }
   }
}
