package com.base.Sys_App;

import java.util.ArrayList;
import java.util.List;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

public class AppMgr {
	
	// Android中 一个应用启动另外一个应用一般有2种情况，被启动应用的包名已知和未知两种情况
  public void launchOtherAppFunction(Context context){
	    /**启动另外应用的代码，其中被启动的应用的包名为org.hy，
	    //应用的入口为org.hy.Test222Activity，此方法的2个应用的AndroidManifest.xml文件都不需要修改**/   
	    Intent intent = new Intent();   
	    intent.setComponent(new ComponentName("org.hy","org.hy.Test222Activity"));   
	    intent.setAction(Intent.ACTION_VIEW);   
	    context.startActivity(intent);   
  }
  
  public void launchOtherAppFuntion2(Context context){
	    /**启动另外应用的代码，其中被启动应用的action为org.hy.test222(自己随便定义)，
	     //此方法的被启动的应用的AndroidManifest.xml要做修改**/   
	    Intent intent = new Intent();   
	    intent.setAction("org.hy.test222");   
	    context.startActivity(intent);   
  }
  
  /**获得手机内应用的包名，返回一个List集合**/   
  public List<PackageInfo> getAllApps(Context context) {     
          List<PackageInfo> apps = new ArrayList<PackageInfo>();     
          PackageManager pm = context.getPackageManager();     
          //获取手机内所有应用     
          List<PackageInfo> paklist = pm.getInstalledPackages(0);     
          for (int i = 0; i < paklist.size(); i++) {     
              PackageInfo pak = (PackageInfo) paklist.get(i);     
              //判断是否为非系统预装的应用  (大于0为系统预装应用，小于等于0为非系统应用)   
              if ((pak.applicationInfo.flags & pak.applicationInfo.FLAG_SYSTEM) <= 0) {     
                  apps.add(pak);     
              }     
          }     
          return apps;     
  }   
  
  // 获得包名后，就可以通过获得要启动的包名启动应用了
  public void launchApp(Context context) {   
      PackageManager packageManager = context.getPackageManager();   
      List<PackageInfo> packages = getAllApps(context);   
      PackageInfo pa = null;   
      for(int i=0;i<packages.size();i++){   
          pa = packages.get(i);   
          //获得应用名   
          String appLabel = packageManager.getApplicationLabel(pa.applicationInfo).toString();   
          //获得包名   
          String appPackage = pa.packageName;   
          //Log.d(""+i, appLabel+"  "+appPackage);   
      }   
      Intent intent = packageManager.getLaunchIntentForPackage("jp.co.johospace.jorte");//"jp.co.johospace.jorte"就是我们获得要启动应用的包名   
      context.startActivity(intent);   
  }   
}
