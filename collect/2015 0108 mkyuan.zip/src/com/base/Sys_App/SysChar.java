package com.base.Sys_App;

import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Set;

public class SysChar {

	// 如何获取系统支持的所有CharsetName
	public String getAllSysCharset(){
		String result = "";
        Set names=Charset.availableCharsets().keySet();
        for (Iterator iter = names.iterator(); iter.hasNext();) {
            String charsetName = (String) iter.next();
            if(Charset.isSupported(charsetName)){
            	result = result + "\n" + charsetName;
           }
       }
        return result;
	}
}
