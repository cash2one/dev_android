package com.app;

public class BaseCore {

	/* 单一实例 */
	private static BaseCore mBaseCoreInstance;
	protected BaseCore(){
		mBaseCoreInstance = this;		
	}
	public static BaseCore getBaseCore(){
		return mBaseCoreInstance;
	}
}
