package com.app.clock;

import com.uiwidget.BaseActivity;

public class ActivityCalendar extends com.uiwidget.BaseActivity {

}
