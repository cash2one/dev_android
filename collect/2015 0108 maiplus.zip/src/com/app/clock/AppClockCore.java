package com.app.clock;

public class AppClockCore extends com.app.BaseCore {

	private static AppClockCore mAppCoreInstance;
	private AppClockCore(){}
	public static AppClockCore getCore(){
		if (null == mAppCoreInstance){
			mAppCoreInstance=new AppClockCore();
		}
		return mAppCoreInstance;
	}
}
