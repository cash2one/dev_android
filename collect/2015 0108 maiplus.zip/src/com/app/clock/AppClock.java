package com.app.clock;

public class AppClock extends com.app.BaseApp {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
