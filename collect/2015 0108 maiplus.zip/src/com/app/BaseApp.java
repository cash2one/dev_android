package com.app;

public class BaseApp  extends android.app.Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
