package com.base;

public class Sys_Root {
	
    private final static int kSystemRootStateUnknow = -1;  
    private final static int kSystemRootStateDisable = 0;  
    private final static int kSystemRootStateEnable = 1;  
    private static int systemRootState = kSystemRootStateUnknow;  
    
	public static boolean isRootSystem() {  
        if (systemRootState == kSystemRootStateEnable) {  
            return true;  
        } else if (systemRootState == kSystemRootStateDisable) {  
            return false;  
        }  
        java.io.File f = null;  
        final String kSuSearchPaths[] = { 
        		"/system/bin/", 
        		"/system/xbin/",  
                "/system/sbin/", 
                "/sbin/", 
                "/vendor/bin/" 
                };  
        try {  
            for (int i = 0; i < kSuSearchPaths.length; i++) {  
                f = new java.io.File(kSuSearchPaths[i] + "su");  
                if (f != null && f.exists()) {  
                    systemRootState = kSystemRootStateEnable;  
                    return true;  
                }  
            }  
        } catch (Exception e) {  
        }  
        systemRootState = kSystemRootStateDisable;  
        return false;  
    }
	//判断机器 Android是否已经root，即是否获取root权限     
	protected static int execRootCmdSilent(String paramString) {
        try {
            Process localProcess = Runtime.getRuntime().exec("su");
            Object localObject = localProcess.getOutputStream();
            java.io.DataOutputStream localDataOutputStream = new java.io.DataOutputStream((java.io.OutputStream) localObject);
            String str = String.valueOf(paramString);
            localObject = str + "\n";
            localDataOutputStream.writeBytes((String) localObject);
            localDataOutputStream.flush();
            localDataOutputStream.writeBytes("exit\n");
            localDataOutputStream.flush();
            localProcess.waitFor();
            int result = localProcess.exitValue();
            return (Integer) result;
        } catch (Exception localException) {
            localException.printStackTrace();
            return -1;
        }
    }
	
	protected static boolean haveRoot()    
	{    
	    int i = execRootCmdSilent("echo test"); //通过执行测试命令来检测     
	    if (i != -1)  return true;    
	    return false;    
	}    
	  
	// 会弹框
	public synchronized boolean getRootAhth()    
	{    
	    Process process = null;    
	    java.io.DataOutputStream os = null;    
	    try    
	    {    
	        process = Runtime.getRuntime().exec("su");    
	        os = new java.io.DataOutputStream(process.getOutputStream());    
	        os.writeBytes("exit\n");    
	        os.flush();    
	        int exitValue = process.waitFor();    
	        if (exitValue == 0)    
	        {    
	            return true;    
	        } else    
	        {    
	            return false;    
	        }    
	    } catch (Exception e)    
	    {    
	        //Log.d("*** DEBUG ***", "Unexpected error - Here is what I know: " + e.getMessage());    
	        return false;    
	    } finally    
	    {    
	        try    
	        {    
	            if (os != null)    
	            {    
	                os.close();    
	            }    
	            process.destroy();    
	        } catch (Exception e)    
	        {    
	            e.printStackTrace();    
	        }    
	    }    
	}    	
}
