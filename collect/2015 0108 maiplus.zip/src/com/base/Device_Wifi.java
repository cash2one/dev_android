package com.base;

import java.util.List;

import android.app.Application;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

public class Device_Wifi {
	//android.net.wifi
	
	private void test(Application app){
		WifiConfiguration cfg = null;
		WifiInfo info = null;
		android.net.wifi.WifiManager mgr = null;
		android.net.wifi.ScanResult scan = null;
		info.getBSSID();// 获取BSSID
		//info.getDetailedStateOf();// 获取客户端的连通性
		info.getHiddenSSID();// 获得SSID 是否被隐藏
		info.getIpAddress();// 获取IP 地址
		info.getLinkSpeed();// 获得连接的速度
		info.getMacAddress();// 获得Mac 地址
		info.getRssi();// 获得802.11n 网络的信号
		info.getSSID();// 获得SSID
		//info.getSupplicanState();// 返回具体客户端状态的信息
		/*
		  获取WIFI网卡的状态
		　　WIFI网卡的状态是由一系列的整形常量来表示的。
		　　1.WIFI_STATE_DISABLED : WIFI网卡不可用（1）
		　　2.WIFI_STATE_DISABLING : WIFI网卡正在关闭（0）
		　　3.WIFI_STATE_ENABLED : WIFI网卡可用（3）
		　　4.WIFI_STATE_ENABLING : WIFI网正在打开（2） （WIFI启动需要一段时间）
		　　5.WIFI_STATE_UNKNOWN  : 未知网卡状态
		*/
		
		WifiManager.WifiLock lock = null;
		
		 //取得WifiManager对象  
        mgr = (WifiManager) app.getSystemService(app.WIFI_SERVICE);  
        //取得WifiInfo对象  
        info = mgr.getConnectionInfo(); 
        
        if(!mgr.isWifiEnabled()){  
        	mgr.setWifiEnabled(true);  
        }  
	}
	//锁定wifiLock  
    public void acquireWifiLock(){  
		WifiManager.WifiLock lock = null;
		lock.acquire();  
    }  
    //解锁wifiLock  
    public void releaseWifiLock(){  
		WifiManager.WifiLock lock = null;
        //判断是否锁定  
        if(lock.isHeld()){  
        	lock.acquire();  
        }  
    }
    
    //创建一个wifiLock  
    public void createWifiLock(){  
		WifiManager.WifiLock lock = null;
		WifiManager mgr = null;  
		lock = mgr.createWifiLock("test");  
    }
    
    public void startScan(){  
		WifiManager mgr = null;  
		mgr.startScan();  
        //得到扫描结果  
		List<ScanResult> mWifiList=mgr.getScanResults();  
        //得到配置好的网络连接  
        List<WifiConfiguration>mWifiConfigurations=mgr.getConfiguredNetworks();
        
        //连接配置好指定ID的网络  
        mgr.enableNetwork(mWifiConfigurations.get(0).networkId, true); 
    }  
    //添加一个网络并连接  
    public void addNetWork(WifiConfiguration configuration){  
		WifiManager mgr = null;  
        int wcgId=mgr.addNetwork(configuration);  
        mgr.enableNetwork(wcgId, true);  
    }  
    //断开指定ID的网络  
    public void disConnectionWifi(int netId){  
		WifiManager mgr = null;  
		mgr.disableNetwork(netId);  
		mgr.disconnect();  
    }  
}
