package com.base;

import android.content.Context;
import android.util.AttributeSet;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class Device_FlashLight {
/* android手机用闪光灯做成手电筒的应用很多，但是有的不能用。
    后来发现是除了把 camera device的 flashmode设置成torch外还要打开预览*/
	
	public class FlashLightSurface extends SurfaceView implements SurfaceHolder.Callback{  
		/*/
	    //*/
	    public FlashLightSurface(Context context) {
			//super(context);
			this(context, null);
		}
	    
		public FlashLightSurface(Context context, AttributeSet attrs) {
			//super(context, attrs);
			this(context, attrs, 0);
		}
		
		public FlashLightSurface(Context context, AttributeSet attrs, int defStyle) {
			super(context, attrs, defStyle);
			mSurfaceHolder = this.getHolder();  
			mSurfaceHolder.addCallback(this);  
			mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);  
		}

		private SurfaceHolder mSurfaceHolder = null;  
	    private android.hardware.Camera mCameraDevice = null;
	    private android.hardware.Camera.Parameters mCameraParameters = null;  
		
		@Override
		public void surfaceCreated(SurfaceHolder holder) { 
			try {  
			    mCameraDevice = Camera.open();  
			    mCameraDevice.setPreviewDisplay(mSurfaceHolder);  
            } catch (Exception e) {  
        	    if  (null != mCameraDevice) {
        		    mCameraDevice.release();	
        	    } 
                mCameraDevice = null;  
            }  
		}
		
		@Override
		public void surfaceDestroyed(SurfaceHolder holder) { 
			if (null == mCameraDevice) 
				return;  
			mCameraDevice.stopPreview();  
			mCameraDevice.release();  
			mCameraDevice = null;  
		}  
		
		@Override
		public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
			mCameraParameters = mCameraDevice.getParameters();  
            if(mCameraParameters != null)  
            	mCameraParameters.setPictureFormat(PixelFormat.JPEG);  
            mCameraParameters.setPreviewSize(320, 480);  
            mCameraParameters.setPictureSize(320, 480);  
            mCameraDevice.setParameters(mCameraParameters);  
            mCameraDevice.startPreview();  
		}		

		/** 
	     * 设置手电筒的开关状态 
	     * @param on ： true则打开，false则关闭 
	     */  
		public void setFlashlightSwitch(boolean on){  
	        if(mCameraDevice == null) 
	        	return;  
	        if(mCameraParameters == null){  
	        	mCameraParameters = mCameraDevice.getParameters();  
	        }  
	        if(on){  
	        	//mCameraParameters.setFlashMode(Contants.FLASH_MODE_TORCH);  
	        }else{  
	        	//mCameraParameters.setFlashMode(Contants.FLASH_MODE_OFF);  
	        }  
	        mCameraDevice.setParameters(mCameraParameters);  
	    }  
	}
}
