package com.base;

import java.lang.reflect.Field;  
import java.lang.reflect.Method;  

//import com.android.internal.telephony.ITelephony;
// 调用TelephonyManager的隐藏API是先参考
// Framework的/base/telephony/java/com/android/internal/telephony/ITelephony.aidl，
// 然后自己实现一个ITelephony.aidl，最后在TelephonyManager中通过反射机制实例化自定义
// 的ITelephony，实例化之后就可以调用ITelephony里面的函数了

public class Sys_Telephony {
	
	//<uses-permission android:name="android.permission.CALL_PHONE" />
	//<uses-permission android:name="android.permission.MODIFY_PHONE_STATE" />  
	
	private CallStateListener mCallStateListener;	
	private android.telephony.TelephonyManager  mTelephonyMgr;
	
    private void test(android.app.Application app) {
    	android.telephony.TelephonyManager  telmgr= (android.telephony.TelephonyManager) app.getSystemService(app.TELEPHONY_SERVICE);
    	//telmgr.
    }
    
    public class CallStateListener extends android.telephony.PhoneStateListener {
    	@Override  
        public void onCallStateChanged(int state, String incomingNumber) {
    		doOnCallStateChanged(state, incomingNumber);
    		super.onCallStateChanged(state, incomingNumber); 
    	}
    	
    	private void doOnCallStateChanged (int state, String incomingNumber) {
    		if (android.telephony.TelephonyManager.CALL_STATE_IDLE == state) {
    			//挂断
    		}
    		if (android.telephony.TelephonyManager.CALL_STATE_OFFHOOK == state) {
    			//接听
    		}
    		if (android.telephony.TelephonyManager.CALL_STATE_RINGING == state) {
    			//来电
    			//需要<uses-permission android:name="android.permission.MODIFY_PHONE_STATE" />
    			//PhoneUtils.getITelephony(telMgr).silenceRinger();//静铃  
    			//PhoneUtils.getITelephony(telMgr).answerRingingCall();//自动接听  
    			//PhoneUtils.getITelephony(telMgr).endCall();//挂断  
    			//PhoneUtils.getITelephony(telMgr).cancelMissedCallsNotification();//取消未接显示
    			// 数据连接的开关
    			//PhoneUtils.getITelephony(telMgr).enableDataConnectivity();  
    		}
    	}
    	
    }
    
}
