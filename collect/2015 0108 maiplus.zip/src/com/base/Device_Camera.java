package com.base;

import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.util.AttributeSet;
import android.view.SurfaceHolder;  
import android.view.SurfaceView; 

public class Device_Camera {
	
    public class CameraView extends SurfaceView {
    	
		public CameraView(Context context) {
			this(context, null);
		}
		
		public CameraView(Context context, AttributeSet attrs) {
			this(context, attrs, 0);
		}

	    private android.hardware.Camera mCamera = null;  
        private SurfaceHolder mSurfaceHolder = null;  

		public CameraView(Context context, AttributeSet attrs, int defStyle) {
			super(context, attrs, defStyle);
			
			mSurfaceHolder = this.getHolder();    
			mSurfaceHolder.addCallback(new CameraSurfaceHolderCallback() {  
                @Override  
                public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {  
                    Camera.Parameters parameters = mCamera.getParameters();  
                    // parameters.setPictureFormat(PixelFormat.JPEG);  
                    // parameters.setPreviewSize(parameters.getPictureSize().width,  
                    // parameters.getPictureSize().height);  
                    // parameters.setFocusMode("auto");  
                    // parameters.setPictureSize(width, height);
                    mCamera.setParameters(parameters);  
                    mCamera.startPreview();  
                }
                
                @Override  
                public void surfaceCreated(SurfaceHolder holder) {
                	Activity activity = null;
            	    //mCamera = openCameraByFacing(Camera.CameraInfo.CAMERA_FACING_BACK);
                    try {  
                    	android.hardware.Camera.Parameters params = mCamera.getParameters();
                        mCamera.setDisplayOrientation(90);  
                        mCamera.setPreviewDisplay(holder);  
                    } catch (IOException e) {  
                        mCamera.release();  
                        mCamera = null;  
                        e.printStackTrace();  
                    }  
                }

                @Override  
                public void surfaceDestroyed(SurfaceHolder holder) {
                	if (null != mCamera) {
                        mCamera.stopPreview();  
                        mCamera.release();  
                        mCamera = null;                  	
                	}
                }
			}
			);
		}

		public class CameraSurfaceHolderCallback implements SurfaceHolder.Callback {

			@Override
			public void surfaceCreated(SurfaceHolder holder) {
			}

			@Override
			public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
			}

			@Override
			public void surfaceDestroyed(SurfaceHolder holder) {
			}
		}

        private android.hardware.Camera openCameraByFacing(int facing) {
        	//android.hardware.Camera
            CameraInfo cameraInfo = new CameraInfo();
            int cameraCount = Camera.getNumberOfCameras();
            for(int i = 0; i < cameraCount; i++ ) {
            	Camera.getCameraInfo(i, cameraInfo);
            	if (facing == cameraInfo.facing) { 
            		android.hardware.Camera camera = Camera.open(i);
                    try {
                    	camera.setPreviewDisplay(this.mSurfaceHolder);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    camera.startPreview();
                    return camera;
            	}
            }
            return null;
        }
                
    }
}
