package com.base;

import android.app.Application;
import android.telephony.TelephonyManager;

public class Device_SimCard {
	

	public void readSIMCard(android.app.Application app) {
		TelephonyManager tm = (TelephonyManager)app.getSystemService(app.TELEPHONY_SERVICE);//取得相关系统服务
		StringBuffer sb = new StringBuffer();
		//getSimState()取得sim的状态 有下面6中状态
		switch(tm.getSimState()){ 
		    case TelephonyManager.SIM_STATE_ABSENT :sb.append("无卡");break; 
		    case TelephonyManager.SIM_STATE_UNKNOWN :sb.append("未知状态");break;
		    case TelephonyManager.SIM_STATE_NETWORK_LOCKED :sb.append("需要NetworkPIN解锁");break;
		    case TelephonyManager.SIM_STATE_PIN_REQUIRED :sb.append("需要PIN解锁");break;
		    case TelephonyManager.SIM_STATE_PUK_REQUIRED :sb.append("需要PUK解锁");break;
		    case TelephonyManager.SIM_STATE_READY :sb.append("良好");break;
		}
		
		if(tm.getSimSerialNumber()!=null){
			sb.append("@" + tm.getSimSerialNumber().toString());
		}
		if (tm.getSimOperator().equals("")){
		sb.append("@无法取得供货商代码");
		}else{
		sb.append("@" + tm.getSimOperator().toString());
		}

		if(tm.getSimOperatorName().equals("")){
		sb.append("@无法取得供货商");
		}else{
		sb.append("@" + tm.getSimOperatorName().toString());
		}

		if(tm.getSimCountryIso().equals("")){
		sb.append("@无法取得国籍");
		}else{
		sb.append("@" + tm.getSimCountryIso().toString());
		}if (tm.getNetworkOperator().equals("")) {
			sb.append("@无法取得网络运营商");
		} else {
		sb.append("@" + tm.getNetworkOperator());
		}
		if (tm.getNetworkOperatorName().equals("")) {
		sb.append("@无法取得网络运营商名称");
		} else {
		sb.append("@" + tm.getNetworkOperatorName());
		}
		if (tm.getNetworkType() == 0) {
		sb.append("@无法取得网络类型");
		} else {
		sb.append("@" + tm.getNetworkType());
		}
	}
}
