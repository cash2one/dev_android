package com.base;

import java.io.File;

import android.os.Environment;

public class Device_SDCard {
// SD卡路径问题以及如何获取SDCard 内存
	// private String folder = "/sdcard/DCIM/Camera/"（SD卡上拍照程序的图片存储路径）; //写死绝对路径，不赞成使用
	
	//方法二： 
	public String getSDPath(){ 
	       //判断sd卡是否存在 
		
		// 获取 Android 数据目录
		// Environment.getDataDirectory();
		
		// 获取 Android 下载/缓存内容目录
		// Environment.getDownloadCacheDirectory
		
		// 取一个高端的公用的外部存储器目录来摆放某些类型的文件
		//Environment.getExternalStoragePublicDirectory(String type);
		
		// 获取外部存储设备的当前状态
		//Environment.getExternalStorageState();
		
		// 获取 Android 的根目录
		//Environment.getRootDirectory();
		
		//android.os.StatFs
		
	       if  (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))   
	       {                               
	    	   // 获取外部存储目录即 SDCard 
		       File sdDir = Environment.getExternalStorageDirectory();
		       return sdDir.toString(); 
	      }
	       return null;
	}
	
	// 1、讲述 Environment 类 
	// MEDIA_BAD_REMOVAL  表明SDCard 被卸载前己被移除
	// MEDIA_CHECKING 表明对象正在磁盘检查
	// MEDIA_MOUNTED 是否存在并具有读/写权限 
	// MEDIA_MOUNTED_READ_ONLY 
	// MEDIA_NOFS 
	// MEDIA_REMOVED  不存在 SDCard 返回 
	// MEDIA_SHARED     SDCard 未安装 ，并通过 USB 大容量存储共享 返回
	// MEDIA_UNMOUNTABLE   SDCard 不可被安装 如果 SDCard 是存在但不可以被安装 MEDIA_UNMOUNTED 
}
