package com.base;

import android.app.Application;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorManager;

public class Device_MotionSensors {

	// http://blog.csdn.net/weborn/article/details/6977366
	// 三自由度陀螺仪就是一个可以识别设备相对于地面，绕x、y、z轴转动角度的感应器(自己的理解，不够严谨)。
	// 智能手机，平板电脑有了它，可以实现很多好玩的应用，比如说指南针等。
	// 我们可以用一个磁场感应器(magnetic sensor)，来实现陀螺仪
	
	// http://blog.chinaunix.net/uid-26997997-id-3485501.html
    // Android4.0系统内置对传感器的支持达13种，它们分别是：
	//     1. 加速度传感器 (accelerometer)、
	//     2. 磁力传感器(magnetic field)、
	//     3. 方向传感器(orientation)、
	//     4. 陀螺仪(gyroscope)、
	//     5. 环境光照传感器(light)、
	//     6. 压力传感器(pressure)、 
	//     7. 温度传感器(temperature)和
	//     8. 距离传感器(proximity)
	
	private android.hardware.SensorManager mSensorManager;
	private android.hardware.Sensor mSensor;
	
	private void test(Application app) {
		mSensorManager = (SensorManager) app.getSystemService(app.SENSOR_SERVICE);
		// 加速度传感器测量设备的加速度，包括重力加速度
		// 使用加速度计
		mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		// 重力传感器
		mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
		// 陀螺仪
		mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
		// 线性加速计 
		mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
		// 旋转向量传感器
		mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
	}

	/*
	 * Android 平台支持的运动传感器
传感器	传感器事件数据	说明	测量单位
TYPE_ACCELEROMETER	
                                            SensorEvent.values[0]	沿 x 轴的加速度（包括重力）。	m/s2
                                            SensorEvent.values[1]	沿 y 轴的加速度（包括重力）。
                                            SensorEvent.values[2]	沿 z 轴的加速度（包括重力）。
TYPE_GRAVITY	                
                                            SensorEvent.values[0]	沿 x 轴的重力加速度。	m/s2
                                            SensorEvent.values[1]	沿 y 轴的重力加速度。
                                            SensorEvent.values[2]	沿 z 轴的重力加速度。
TYPE_GYROSCOPE	       
                                            SensorEvent.values[0]	围绕 x 轴的旋转角速度。	rad/s
                                            SensorEvent.values[1]	围绕 y 轴的旋转角速度。
                                            SensorEvent.values[2]	围绕 z 轴的旋转角速度。
TYPE_LINEAR_ACCELERATION	
                                            SensorEvent.values[0]]	沿 x 轴的加速度（不包括重力）。	m/s2
                                            SensorEvent.values[1]	沿 y 轴的加速度（不包括重力）。
                                            SensorEvent.values[2]	沿 z 轴的加速度（不包括重力）。
TYPE_ROTATION_VECTOR	
                                            SensorEvent.values[0]]	旋转向量沿 x 轴的部分（x * sin(θ/2)）。	无无
                                            SensorEvent.values[1]	旋转向量沿 y 轴的部分（y * sin(θ/2)）。
                                            SensorEvent.values[2]]	旋转向量沿 z 轴的部分（z * sin(θ/2)）。
                                            SensorEvent.values[3]]	旋转向量的数值部分（(cos(θ/2)）1。
		*/
	public void onSensorChanged(android.hardware.SensorEvent event){
		  // 在本例中，alpha 由 t / (t + dT)计算得来，
		  // 其中 t 是低通滤波器的时间常数，dT 是事件报送频率
          /*		  
          final float alpha = 0.8;
		  // 用低通滤波器分离出重力加速度
		  gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
		  gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
		  gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];
		  // 用高通滤波器剔除重力干扰
		  linear_acceleration[0] = event.values[0] - gravity[0];
		  linear_acceleration[1] = event.values[1] - gravity[1];
		  linear_acceleration[2] = event.values[2] - gravity[2];
		  */
	}
}
