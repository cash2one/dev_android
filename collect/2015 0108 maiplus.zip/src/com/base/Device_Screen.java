package com.base;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

public class Device_Screen {
	
	private void getResolution(Activity activity) {
		Display display = activity.getWindowManager().getDefaultDisplay();
		DisplayMetrics displayMetrics = new DisplayMetrics();
		display.getMetrics(displayMetrics);
		float density = displayMetrics.density; //得到密度
		float width = displayMetrics.widthPixels;//得到宽度
		float height = displayMetrics.heightPixels;//得到高度
	}
	
	public void switchFullScreen(Activity activity) {
		//在onCreat方法中setContentView（）之前插入
		// 这种方法在启动activity时会闪现状态栏之后再全屏
		activity.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);//取消标题栏
		//全屏
		activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		//<activity android:theme="@android:style/Theme.NoTitleBar.Fullscreen" />只在当前Activity内显示全屏
		//<application  android:theme="@android:style/Theme.NoTitleBar.Fullscreen"  />为整个应用配置全屏显示
		
		WindowManager.LayoutParams attrs = activity.getWindow().getAttributes();
		//取消全屏设置
		attrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN); 
		activity.getWindow().setAttributes(attrs);  
		activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		
		//设置全屏
		attrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN; 
		activity.getWindow().setAttributes(attrs); 
		activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS); 
	}
}
