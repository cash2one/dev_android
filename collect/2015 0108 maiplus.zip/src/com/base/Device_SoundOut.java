package com.base;

import java.io.IOException;

import android.app.Application;
import android.media.MediaPlayer;
import android.net.Uri;

public class Device_SoundOut {
	
    private void test(Application app) {
    	 //创建MediaPlayer对象,将raw文件夹下的lovefool.mp3  
    	Uri uri = null;
    	MediaPlayer mp = android.media.MediaPlayer.create(app, uri);
    	if (null != mp)  
        {  
         mp.stop();
         String fileurl = null;
         try {
        	 //  若使用URL 来播放在线媒体文件,该文件应该要能支持pragressive 下载
			mp.setDataSource(fileurl);
		} catch (IllegalArgumentException e1) {
			// 所用的文件当下并不存在
			e1.printStackTrace();
		} catch (SecurityException e1) {
			e1.printStackTrace();
		} catch (IllegalStateException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} 
         try {
			mp.prepare();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}  
         mp.start();  
        }      
    	
    	 /* 当MediaPlayer.OnCompletionLister会运行的Listener */ 
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
			@Override
			public void onCompletion(MediaPlayer mp) {
				try {
					mp.release();
				} catch (Exception e) {
					
				}				
			}
          }   
       );
        /* 当MediaPlayer.OnErrorListener会运行的Listener */ 
        mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
			@Override
			public boolean onError(MediaPlayer mp, int what, int extra) { 
				try {           
	              /*发生错误时也解除资源与MediaPlayer的赋值*/ 
	              mp.release();  
				} catch (Exception e) {
					
				}
				return false;
			} }
        );
    }
}
