package com.base;

public class SysDB_Contact {
	
	// <uses-permission android:name="android.permission.READ_CONTACTS" />
	
    private void test(android.app.Application app) {
    	android.net.Uri uri = android.provider.ContactsContract.Data.CONTENT_URI;
    	StringBuilder where = new StringBuilder();
    	android.database.Cursor cursor_contact = app.getContentResolver().query(
    			uri, 
    			null, 
    			where.toString(), 
    			null, 
    			android.provider.ContactsContract.Data.RAW_CONTACT_ID
    			);
    	if (null != cursor_contact) {
    		try {
    	    	for (cursor_contact.moveToFirst();!cursor_contact.isAfterLast();cursor_contact.moveToNext()){
    	    		int raw_contact_id = cursor_contact.getInt(cursor_contact.getColumnIndex(android.provider.ContactsContract.Data.RAW_CONTACT_ID));
    	    	}    
    		} catch (Exception e) {
    		}
    	}
    	
        android.database.Cursor cursor_contact2 = app.getContentResolver().query(android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);     // 获取手机联系人 
        //  deprecated 已被官方弃用
    	//android.net.Uri uri2 = android.provider.Contacts.CONTENT_URI;
    }
}
