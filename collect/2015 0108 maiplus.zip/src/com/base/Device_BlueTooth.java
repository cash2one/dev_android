package com.base;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;

public class Device_BlueTooth {
	
	// http://www.open-open.com/lib/view/open1335146166780.html
	
	// 1. 使用蓝牙的响应权限
	//<uses-permission android:name="android.permission.BLUETOOTH" /> 
    //<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
	
	private void test(Activity activity) {
		
		// 2. 配置本机蓝牙模块
		android.bluetooth.BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
		
		//直接打开系统的蓝牙设置面板 
		Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE); 
		activity.startActivityForResult(intent, 0x1); 
		//直接打开蓝牙 
		adapter.enable(); 
		//关闭蓝牙 
		adapter.disable(); 
		//打开本机的蓝牙发现功能（默认打开120秒，可以将时间最多延长至300秒） 
		//discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
		//设置持续时间（最多300秒）Intent discoveryIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);

		// 3.搜索蓝牙设备
		// 使用BluetoothAdapter的startDiscovery()方法来搜索蓝牙设备
		// 异步方法，调用后会立即返回。该方法会进行对其他蓝牙设备的搜索，该过程会持续12秒
		//请求Discovery后，系统开始搜索蓝牙设备，在这个过程中，系统会发送以下三个广播：
		//ACTION_DISCOVERY_START：开始搜索
		//ACTION_DISCOVERY_FINISHED：搜索结束
		//ACTION_FOUND：找到设备，这个Intent中包含两个extra fields：EXTRA_DEVICE和EXTRA_CLASS，分别包含BluetooDevice和BluetoothClass。
		//我们可以自己注册相应的BroadcastReceiver来接收响应的广播，以便实现某些功能
		
		BroadcastReceiver mReceiver = new BroadcastReceiver() { 
		    public void onReceive(Context context, Intent intent) { 
		        String action = intent.getAction(); 
		        // 发现设备 
		        if (BluetoothDevice.ACTION_FOUND.equals(action)) { 
		            // 从Intent中获取设备对象 
		            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); 
		            // 将设备名称和地址放入array adapter，以便在ListView中显示 
		            //mArrayAdapter.add(device.getName() + "\n" + device.getAddress()); 
		        } 
		    } 
		}; 
		// 注册BroadcastReceiver 
		IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND); 
		// 不要忘了之后解除绑定
		activity.registerReceiver(mReceiver, filter);
		//activity.unregisterReceiver(mReceiver);
		
		// 4. 蓝牙Socket通信

        // 如果打算建议两个蓝牙设备之间的连接，则必须实现服务器端与客户端的机制。当两个设备在同一个RFCOMM channel下
		// 分别拥有一个连接的BluetoothSocket，这两个设备才可以说是建立了连接。
        // 服务器设备与客户端设备获取BluetoothSocket的途径是不同的。服务器设备是通过accepted一个incoming connection来获取的
		// 而客户端设备则是通过打开一个到服务器的RFCOMM channel来获取的
	}
	
	private class BlueToothServer {
		android.bluetooth.BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		// 通过调用BluetoothAdapter的listenUsingRfcommWithServiceRecord(String, UUID)方法
		// 来获取BluetoothServerSocket（UUID用于客户端与服务器端之间的配对）
		
		// 调用BluetoothServerSocket的accept()方法监听连接请求，如果收到请求，则返回一个BluetoothSocket实例（此方法为block方法，应置于新线程中）
		private class AcceptThread extends Thread {
			private String name;
        	private UUID uuid;
			private BluetoothServerSocket mmServerSocket;
			 public AcceptThread() {
			        // Use a temporary object that is later assigned to mmServerSocket,
			        // because mmServerSocket is final
			        BluetoothServerSocket tmp = null;
			        try {
			            // MY_UUID is the app's UUID string, also used by the client code
			            tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord(name, uuid);
			        } catch (IOException e) { }
			        mmServerSocket = tmp;
			    }
			 
			    public void run() {
			        BluetoothSocket socket = null;
			        // Keep listening until exception occurs or a socket is returned
			        while (true) {
			            try {
			                socket = mmServerSocket.accept();
			            } catch (IOException e) {
			                break;
			            }
			            // If a connection was accepted
			            if (socket != null) {
			                // Do work to manage the connection (in a separate thread)
			                //manageConnectedSocket(socket);
			                try {
								mmServerSocket.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			                break;
			            }
			        }
			    }
			 
			    /** Will cancel the listening socket, and cause the thread to finish */
			    public void cancel() {
			        try {
			            mmServerSocket.close();
			        } catch (IOException e) { }
			    }			
		}
	} // end class BlueToothServer 
	

	private class BlueToothClient {
		
		android.bluetooth.BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		
		private class ConnectThread extends Thread { 
	        private final BluetoothSocket mmSocket; 
	        private final BluetoothDevice mmDevice; 
        	private UUID uuid;
	       
	        public ConnectThread(BluetoothDevice device) { 
	            // Use a temporary object that is later assigned to mmSocket, 
	            // because mmSocket is final 
	            BluetoothSocket tmp = null; 
	            mmDevice = device; 
	       
	            // Get a BluetoothSocket to connect with the given BluetoothDevice 
	            try { 
	                // MY_UUID is the app's UUID string, also used by the server code 
	                tmp = device.createRfcommSocketToServiceRecord(uuid); 
	            } catch (IOException e) { } 
	            mmSocket = tmp; 
	        } 
	       
	        public void run() { 
	            // Cancel discovery because it will slow down the connection 
	            mBluetoothAdapter.cancelDiscovery(); 
	       
	            try { 
	                // Connect the device through the socket. This will block 
	                // until it succeeds or throws an exception 
	                mmSocket.connect(); 
	            } catch (IOException connectException) { 
	                // Unable to connect; close the socket and get out 
	                try { 
	                    mmSocket.close(); 
	                } catch (IOException closeException) { } 
	                return; 
	            } 
	       
	            // Do work to manage the connection (in a separate thread) 
	            //manageConnectedSocket(mmSocket); 
	        } 
	       
	        /** Will cancel an in-progress connection, and close the socket */ 
	        public void cancel() { 
	            try { 
	                mmSocket.close(); 
	            } catch (IOException e) { } 
	        } 
	    }
		
		private class ConnectedThread extends Thread { 
	        private final BluetoothSocket mmSocket; 
	        private final InputStream mmInStream; 
	        private final OutputStream mmOutStream; 
	       
	        public ConnectedThread(BluetoothSocket socket) { 
	            mmSocket = socket; 
	            InputStream tmpIn = null; 
	            OutputStream tmpOut = null; 
	       
	            // Get the input and output streams, using temp objects because 
	            // member streams are final 
	            try { 
	                tmpIn = socket.getInputStream(); 
	                tmpOut = socket.getOutputStream(); 
	            } catch (IOException e) { } 
	       
	            mmInStream = tmpIn; 
	            mmOutStream = tmpOut; 
	        } 
	       
	        private android.os.Handler mHandler;
	        private int MESSAGE_READ;
	        
	        public void run() { 
	            byte[] buffer = new byte[1024];  // buffer store for the stream 
	            int bytes; // bytes returned from read() 
	            // Keep listening to the InputStream until an exception occurs 
	            while (true) { 
	                try { 
	                    // Read from the InputStream 
	                    bytes = mmInStream.read(buffer); 
	                    // Send the obtained bytes to the UI Activity 
	                    mHandler.obtainMessage(MESSAGE_READ, bytes, -1, buffer).sendToTarget(); 
	                } catch (IOException e) { 
	                    break; 
	                } 
	            } 
	        } 
	       
	        /* Call this from the main Activity to send data to the remote device */ 
	        public void write(byte[] bytes) { 
	            try { 
	                mmOutStream.write(bytes); 
	            } catch (IOException e) { } 
	        } 
	       
	        /* Call this from the main Activity to shutdown the connection */ 
	        public void cancel() { 
	            try { 
	                mmSocket.close(); 
	            } catch (IOException e) { } 
	        } 
	    } 		
	} // end class BlueToothClient
}
