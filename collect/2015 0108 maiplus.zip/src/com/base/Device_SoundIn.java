package com.base;

import java.io.IOException;

import android.media.MediaRecorder;

public class Device_SoundIn {
	
    private void test() {
    	android.media.MediaRecorder recorder = new MediaRecorder();  
    	 recorder.setAudioSource(MediaRecorder.AudioSource.MIC);  
    	 recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);  
    	 recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    	 String PATH_NAME = null;
    	 recorder.setOutputFile(PATH_NAME);  
    	 try {
			recorder.prepare();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}  
    	 recorder.start();   // Recording is now started  
    	 recorder.stop();  
    	 recorder.reset();   // You can reuse the object by going back to setAudioSource() step  
    	 recorder.release(); // Now the object cannot be reused 
    }
    
    private void stopSoundIn() {
    	android.media.MediaRecorder recorder = new MediaRecorder();  
    	recorder.stop();  
        recorder.release();  
        recorder = null;  
    }
}
