package com.base;

public class SysDB_Calendar {
	
	private void test(android.app.Application app) {
		android.database.Cursor cursor = app.getContentResolver().query(
				android.provider.CalendarContract.CONTENT_URI, 
				null, null, null, null);
		//android.provider.Telephony.
	}
}
