package com.base;

import android.app.Application;
import android.os.Vibrator;

public class Device_Vibration {
	 //<uses-permission android:name="android.permission.VIBRATE" />
	
	Vibrator mVibrator = null;
	
	private void test(Application app) {
		/* 
         * 想设置震动大小可以通过改变pattern来设定，如果开启时间太短，震动效果可能感觉不到 
         * */  
        mVibrator = (android.os.Vibrator) app.getSystemService(app.VIBRATOR_SERVICE);  
        long [] pattern = {100,400,100,400};   // 停止 开启 停止 开启   
        mVibrator.vibrate(pattern, 2);           //重复两次上面的pattern 如果只想震动一次，index设为-1   
	}
	
	private void doStop(){
		mVibrator.cancel();
	}
}
