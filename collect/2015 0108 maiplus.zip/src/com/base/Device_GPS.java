package com.base;

import java.util.ArrayList;
import java.util.Iterator;

import android.app.Activity;
import android.location.Criteria;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;

public class Device_GPS {
	
	// http://bbs.51cto.com/thread-955194-1.html
	private void Test(android.app.Application app){
		android.location.LocationManager locmgr = (LocationManager) app.getSystemService(app.LOCATION_SERVICE);
		if (null != locmgr) {
			android.location.Location location= locmgr.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER);

			//LocationListener，位置监听，监听位置变化，监听设备开关与状态
			android.location.LocationListener locListener=new android.location.LocationListener() {

				@Override
				public void onLocationChanged(Location location) {
					//Log.i(TAG, "时间："+location.getTime()); 
					//Log.i(TAG, "经度："+location.getLongitude()); 
	                //Log.i(TAG, "纬度："+location.getLatitude()); 
	                //Log.i(TAG, "海拔："+location.getAltitude()); 
				}

				@Override
				public void onStatusChanged(String provider, int status, Bundle extras) {
					 switch (status) {
			            //GPS状态为可见时
			            case android.location.LocationProvider.AVAILABLE:
			                //Log.i(TAG, "当前GPS状态为可见状态");
			                break;
			            //GPS状态为服务区外时
			            case LocationProvider.OUT_OF_SERVICE:
			            	//Log.i(TAG, "当前GPS状态为服务区外状态");
			                break;
			            //GPS状态为暂停服务时
			            case LocationProvider.TEMPORARILY_UNAVAILABLE:
			            	//Log.i(TAG, "当前GPS状态为暂停服务状态");
			                break;
			        }
				}

				@Override
				public void onProviderEnabled(String provider) {
					// GPS开启时触发
				}

				@Override
				public void onProviderDisabled(String provider) {
					// GPS禁用时触发
				}
			 };
			 
			android.location.GpsStatus.Listener gpsStatusListener = new GpsStatus.Listener() {
				@Override
				public void onGpsStatusChanged(int event) { 
					switch (event) {
	                     //第一次定位
	                    case GpsStatus.GPS_EVENT_FIRST_FIX:
	                        break;
	                    //卫星状态改变
	                    case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
	                		android.location.LocationManager locmgr = null;
	                    	 GpsStatus gpsStatus=locmgr.getGpsStatus(null);
	                         //获取卫星颗数的默认最大值
	                         int maxSatellites = gpsStatus.getMaxSatellites();
	                         //创建一个迭代器保存所有卫星 
	                         java.util.Iterator<android.location.GpsSatellite> iters = gpsStatus.getSatellites().iterator();
	                         int count = 0;     
	                         while (iters.hasNext() && count <= maxSatellites) {     
	                             GpsSatellite s = iters.next();     
	                             count++;     
	                         }   
	                	    break;
	                	//定位启动
	                    case GpsStatus.GPS_EVENT_STARTED:
	                        break;
	                    //定位结束
	                    case GpsStatus.GPS_EVENT_STOPPED:
	                        break;
				    } // end switch (event)
				}
			};
			//绑定监听状态
    		locmgr.addGpsStatusListener(gpsStatusListener); 
    		//绑定监听，有4个参数    
            //参数1，设备：有GPS_PROVIDER和NETWORK_PROVIDER两种
            //参数2，位置信息更新周期，单位毫秒    
            //参数3，位置变化最小距离：当位置距离变化超过此值时，将更新位置信息    
            //参数4，监听    
            //备注：参数2和3，如果参数3不为0，则以参数3为准；参数3为0，则通过时间来定时更新；两者为0，则随时刷新   
    		
    		// 1秒更新一次，或最小位移变化超过1米更新一次；
            //注意：此处更新准确度非常低，推荐在service里面启动一个Thread，在run中sleep(10000);然后执行handler.sendMessage(),更新位置
    		locmgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locListener);
		};		
	}
	
	private void getGPSPosition() {
		android.location.LocationManager locmgr = null;
		  //为获取地理位置信息时设置查询条件
		android.app.Application app = null;
		android.app.Activity activity = null;
        String bestProvider = locmgr.getBestProvider(getCriteria(), true);
        //获取位置信息
        //如果不设置查询要求，getLastKnownLocation方法传人的参数为LocationManager.GPS_PROVIDER
        Location location= locmgr.getLastKnownLocation(bestProvider); 
	}
	   
	
	/* 返回查询条件 */
    private Criteria getCriteria(){
    	android.location.Criteria criteria=new android.location.Criteria();
        //设置定位精确度 Criteria.ACCURACY_COARSE比较粗略，Criteria.ACCURACY_FINE则比较精细 
        criteria.setAccuracy(Criteria.ACCURACY_FINE);    
        //设置是否要求速度
        criteria.setSpeedRequired(false);
        // 设置是否允许运营商收费  
        criteria.setCostAllowed(false);
        //设置是否需要方位信息
        criteria.setBearingRequired(false);
        //设置是否需要海拔信息
        criteria.setAltitudeRequired(false);
        // 设置对电源的需求  
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        return criteria;
    }
    
	private void getGPSStatus() {
		android.location.LocationManager locmgr = null;
		//实例化    
		GpsStatus gpsStatus = locmgr.getGpsStatus(null); // 获取当前状态    
		//获取默认最大卫星数    
		int maxSatellites = gpsStatus.getMaxSatellites();     
		//获取第一次定位时间（启动到第一次定位）    
		int costTime=gpsStatus.getTimeToFirstFix();   
		//获取卫星    
		Iterable<GpsSatellite> iterable=gpsStatus.getSatellites();   
		//一般再次转换成Iterator    
		Iterator<GpsSatellite> itrator=iterable.iterator();		
	}
	
	private void getGpsSatellite(){
		// GpsSatellite，定位卫星，包含卫星的方位、高度、伪随机噪声码、信噪比等信息
		//获取卫星    
		GpsStatus gpsStatus = null;    
		Iterable<GpsSatellite> iterable=gpsStatus.getSatellites();   
		//再次转换成Iterator    
		Iterator<GpsSatellite> itrator=iterable.iterator();   
		//通过遍历重新整理为ArrayList    
		java.util.ArrayList<GpsSatellite> satelliteList=new java.util.ArrayList<GpsSatellite>();    
		int count=0;   
		int maxSatellites=gpsStatus.getMaxSatellites();   
		while (itrator.hasNext() && count <= maxSatellites) {     
		    GpsSatellite satellite = itrator.next();     
		    satelliteList.add(satellite);     
		    count++;   
		}    
		System.out.println("总共搜索到"+count+"颗卫星");   
		//输出卫星信息    
		for(int i=0;i<satelliteList.size();i++){   
		    //卫星的方位角，浮点型数据    
		    System.out.println(satelliteList.get(i).getAzimuth());   
		    //卫星的高度，浮点型数据    
		    System.out.println(satelliteList.get(i).getElevation());   
		    //卫星的伪随机噪声码，整形数据    
		    System.out.println(satelliteList.get(i).getPrn());   
		    //卫星的信噪比，浮点型数据    
		    System.out.println(satelliteList.get(i).getSnr());   
		    //卫星是否有年历表，布尔型数据    
		    System.out.println(satelliteList.get(i).hasAlmanac());   
		    //卫星是否有星历表，布尔型数据    
		    System.out.println(satelliteList.get(i).hasEphemeris());   
		    //卫星是否被用于近期的GPS修正计算    
		    System.out.println(satelliteList.get(i).hasAlmanac());   
		}
	}
}
