package com.base;

public class SysDB_CallLog {
    // 访问android平台的通话记录
	private void test(android.app.Application app) {
		android.database.Cursor cursor = app.getContentResolver().query(
				android.provider.CallLog.Calls.CONTENT_URI, null, null, null, 
				android.provider.CallLog.Calls.DEFAULT_SORT_ORDER);
		//SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
		//	    android.R.layout.simple_list_item_1, 
		//	    cursor,
		//	    new String[] { CallLog.Calls.NUMBER },
		//	    new int[] { android.R.id.text1 });		
	}
}
