package com.base;

public class Sys_Timer {
    //  Android三种实现定时器的方法
	// 1 Handler+Thread
	//    Thread.sleep(1000); 
	// 2 Handler类自带的postDelyed
	// 3 Handler+Timer+TimerTask
	//     java.util.Timer
	//     java.util.TimerTask
	//    Timer timer = new Timer();
	//    TimerTask task = new TimerTask()   
	//    timer.schedule(task, 1000, 1000); // 1s后执行task,经过1s再次执行
	
	// Android中获取系统时间有多种方法，可分为Java中Calendar类获取，java.util.date类实现，还有android中Time实现
	// long time=System.currentTimeMillis();//long now = android.os.SystemClock.uptimeMillis();  
	// Date d1=new Date(time);
	// SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
	// String t1=format.format(d1); 
	
	// Calendar calendar = Calendar.getInstance();  
	//     calendar.get(Calendar.YEAR)
	//     int day = calendar.get(Calendar.DAY_OF_WEEK);
	
	// Time t=new Time();   // or Time t=new Time("GMT+8"); 加上Time Zone资料
	// t.setToNow(); // 取得系统时间
	// t.year+"年 "+(t.month+1)+"月 "+t.monthDay+"日 "+t.hour+"h "+t.minute+"m "+t.second; 
}
