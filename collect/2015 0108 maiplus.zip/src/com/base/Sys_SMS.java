package com.base;

public class Sys_SMS {
	//<uses-permission android:name="android.permission.READ_SMS" />  
    //<uses-permission android:name="android.permission.RECEIVE_SMS" />
	
	private void SendSMS(android.app.Application app) {
		
		// 1) 发送文本信息		
		//创建sentIntent参数
        // =======================================
		String SEND_SMS_ACTION = "SENT_SMS_ACTION";
		android.content.Intent sentIntent = new android.content.Intent(SEND_SMS_ACTION);
		android.app.PendingIntent sentPendingIntent = android.app.PendingIntent.getBroadcast(app.getApplicationContext(), 0, sentIntent, 0);
		android.content.BroadcastReceiver sendreceiver = new android.content.BroadcastReceiver(){
				@Override
				public void onReceive(android.content.Context context, android.content.Intent intent) {
					switch (getResultCode()) {
					    case android.app.Activity.RESULT_OK:
					    	break;
					    //case RESULT_ERROR_GENERIC_FAILURE:
					    	//	break;
				    }
				}
		   };
	    app.registerReceiver(sendreceiver, new android.content.IntentFilter(SEND_SMS_ACTION));		
        // =======================================
        //创建deliveredIntent参数
		String DELIVERED_SMS_ACTION = "DELIVERED_SMS_ACTION";
		android.content.Intent deliverIntent = new android.content.Intent(DELIVERED_SMS_ACTION);
        android.app.PendingIntent deliverPendingIntent = android.app.PendingIntent.getBroadcast(app.getApplicationContext(), 0, deliverIntent, 0);
		android.content.BroadcastReceiver deliverreceiver = new android.content.BroadcastReceiver(){
			@Override
			public void onReceive(android.content.Context context, android.content.Intent intent) {
				switch (getResultCode()) {
				    case android.app.Activity.RESULT_OK:
				    	break;
				    //case RESULT_ERROR_GENERIC_FAILURE:
				    	//	break;
			    }
			}
	    };
        app.registerReceiver(deliverreceiver, new android.content.IntentFilter(DELIVERED_SMS_ACTION));		
        // =======================================
    //4)保证不超过最大的SMS信息大小
    // SMS的大小一般被限制为160个字符，比它大的信息会被分割为多个小的部分。SMS Manager的divideMeaasge方法可
    // 以接收一个字符串作为输入，并把他分割到一个消息的ArrayList中，每一个消息都比允许的最大长度小。使用sendMultipartTextMessage可以发送消息数组
		String destinationAddress = null;
		String scAddress = null;
		String text = null;

		// 发送SMS以及监控它的发送过程是否成功
		android.telephony.SmsManager  smsmgr = android.telephony.SmsManager.getDefault();
		smsmgr.sendTextMessage(
				destinationAddress, // 接收方的手机号码 
				scAddress, // 发送方的手机号码
				text, // 信息内容
				sentPendingIntent, // 发送是否成功的回执，会在消息发送成功或者失败后触发
				deliverPendingIntent // 接收是否成功的回执，当目标接收人收到你的信息后触发
				);//注册广播器
		String msg = null;
		java.util.ArrayList<String> messageArray = smsmgr.divideMessage(msg);
		java.util.ArrayList<android.app.PendingIntent> sentIntents = new java.util.ArrayList<android.app.PendingIntent>();
		for(int i = 0; i < messageArray.size(); i ++) {
            sentIntents.add(sentPendingIntent);
            smsmgr.sendMultipartTextMessage(destinationAddress,null, messageArray, sentIntents, null);
        }
	}
	
	private void receiveSMS(android.app.Application app) {
		final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED"; // 动作串的Intent Filter
		android.content.IntentFilter filter = new android.content.IntentFilter(SMS_RECEIVED );
		//android.content.BroadcastReceiver receiver = new IncomingSMSReceiver();
	}
	
	// <uses-permission android:name="android.permission.READ_SMS" />
	private void readSMS(android.app.Application app) {
		
		// 偶然发现了Android源码中的一个类MmsSmsDatabaseHelper.java，原来android将所有的短信信息都存入了mmssms.db中。 公开的SDK中没有这个类
		// packages/providers/TelephonyProvider/src/com/android/providers/telephony/MmsSmsDatabaseHelper.java
		
        //_id => 短消息序号 如100  
		//thread_id => 对话的序号 如100  
		//address => 发件人地址，手机号.如+8613811810000  
		//person => 发件人，返回一个数字就是联系人列表里的序号，陌生人为null  
		//date => 日期  long型。如1256539465022  
		//protocol => 协议 0 SMS_RPOTO, 1 MMS_PROTO   
		//read => 是否阅读 0未读， 1已读   
		//status => 状态 -1接收，0 complete, 64 pending, 128 failed   
		//type => 类型 1是接收到的，2是已发出   
		//body => 短消息内容   
		//service_center => 短信服务中心号码编号。如+8613800755500  
        final String SMS_URI_ALL = "content://sms/";  // 所有短信
        final String SMS_URI_INBOX = "content://sms/inbox";  // 收件箱
        final String SMS_URI_SEND = "content://sms/sent";   // 已发送
        final String SMS_URI_DRAFT = "content://sms/draft";  // 草稿
        final String SMS_URI_OUTBOX = "content://sms/outbox";  // 发件箱
        final String SMS_URI_FAILED = "content://sms/failed";  // 发送失败
        final String SMS_URI_QUEUED = "content://sms/queued";  // 待发送列表
        android.net.Uri uri = android.net.Uri.parse(SMS_URI_ALL);  
        String[] projection = new String[] { "_id", "address", "person", "body", "date", "type" };  
        android.database.Cursor cur = app.getContentResolver().query(uri, projection, null, null, "date desc");      // 获取手机内部短信
        if (cur.moveToFirst()) { 
        	 int index_Address = cur.getColumnIndex("address");  
             int index_Person = cur.getColumnIndex("person");  
             int index_Body = cur.getColumnIndex("body");  
             int index_Date = cur.getColumnIndex("date");  
             int index_Type = cur.getColumnIndex("type");  
        }
	}
}
